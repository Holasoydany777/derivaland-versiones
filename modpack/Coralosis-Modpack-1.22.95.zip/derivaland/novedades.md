# Coralosis 1.22.95

## Teaser Tráiler 2 (versión 1.1.0)
- Más largo (88 s), sin el casino ni el boss del final, sin parpadeos, con skins nuevas mucho más detalladas y música nueva.
- Se sigue lanzando con `/teasertrailer2 accion` en un mundo de un jugador; si el pueblo era de la versión anterior, se vuelve a montar solo.

# Coralosis 1.22.94

## Teaser Tráiler 2 (para grabarlo)
- Nuevo mod **Derivaland: Teaser Tráiler 2**. Solo funciona en un mundo de un jugador: `/teasertrailer2 accion` monta el pueblo en una dimensión aparte y reproduce el teaser entero (cámara, vecinos, textos, logo y música). En el servidor no hace nada.

# Coralosis 1.22.93

## La ruleta de la gema
- Lo que dice la ruleta (la novedad que ha salido) ya **no se queda en medio de la pantalla** debajo de la gema: allí solo queda la gema con su nombre.
- El texto sale en el **recuadro de arriba a la derecha** en cuanto cae el resultado y **se quita solo a los ~10 segundos** (antes se quedaba 3 minutos).

## Fuera Distant Horizons
- Se quita del modpack: gastaba demasiados FPS y lo lejano se veía mal. El botón «Calidad» de Opciones sigue (ahora ajusta solo Minecraft y los shaders).

# Coralosis 1.22.92

## Créditos finales
- Al acabar la cinemática del final, en el negro, salen **los créditos de Derivaland Remake** (el vídeo, 1:33, con su música) a pantalla completa para todos los que la estén viendo. Mientras duran nadie se mueve ni recibe daño; al terminar, cada uno vuelve a donde estaba.
- El vídeo va dentro del mod y lo pone el mismo ffmpeg que usan los carteles con vídeo (se prepara solo durante la cinemática). Si algún PC no puede ponerlo, salen igual los mismos créditos dibujados por el juego, con la misma música.
- `/coralosis creditos [jugadores]` los pone sueltos (se quitan con Esc o con `/coralosis creditos parar`).

# Coralosis 1.22.91

## Botón «Calidad» (más FPS en PCs flojos)
- **Botón nuevo «Calidad»** en Opciones (abajo a la izquierda). Cada pulsación cambia entre Ligera, Media, Alta y Manual, y ajusta de golpe Minecraft y los shaders:
  - **Ligera** (PCs justos): 6 chunks, sin shaders, hojas opacas, menos partículas y sin nubes.
  - **Media:** 8 chunks, con los shaders de Derivaland.
  - **Alta:** 12 chunks, con shaders, nubes bonitas y texturas más finas.
  - **Manual:** no toca nada; mandan tus propios ajustes.
- **La primera vez se elige sola** según tu PC (gráfica integrada, núcleos y memoria) y sale un aviso con la que ha puesto.
- Arreglado: el modpack ya traía ajustes ligeros, pero Minecraft los pisaba al arrancar con su preajuste «Bonito» (16 chunks y un filtrado de texturas caro). Ahora se respetan.

## Catacumbas de Bajamar
- **Escaleras de caracol nuevas** en las tres bajadas: mucho más anchas (3,5 bloques de escalón alrededor de un pilar central), de medio bloque en medio bloque y con rellano arriba, al nivel del suelo del faro.
- **Al santuario se entra por delante:** el túnel de las catacumbas llega ahora al arco de entrada, de cara a Bajamar, y no por la parte de atrás.

## El Farero, con diseño propio
- El minijefe de la antesala ya no es un ahogado con otro nombre: es **el antiguo farero**, ahogado y comido por el coral. Lleva impermeable y sombrero de hule amarillo, barba con algas, el **farol encendido** en una mano y el otro brazo convertido en una garra de coral.
- Ataques nuevos: un **golpe con el farol** que quema y empuja, un **haz de luz** que barre la sala girando (daña, ciega y ralentiza si te pilla a la vista) y, cuando le queda poca vida, **llama a los Derivas**. Tiene su propia barra de minijefe y sigue soltando la llave del santuario.
- Huevo del Farero y comando `/coralosis mob farero`.

# Coralosis 1.22.90

## Bajamar derrotado, cubierto de coral
- El cuerpo de Bajamar que se queda en el santuario (y el de la cinemática del final) sale siempre con la skin de coral de su última fase y sus ramas de coral, aunque muriera antes de llegar a ella (por ejemplo con un /kill de prueba). También los cuerpos que ya estuvieran en el mundo.

# Coralosis 1.22.89

## Los tres mobs nuevos ya están en el juego
- **Raíz Madre:** un árbol de coral enorme clavado en el suelo (no se mueve, ni se le puede empujar). Golpea con el tronco todo lo que tenga delante y lo lanza por los aires, y cuando te alejas un poco suelta un **pulso** desde el corazón que hace daño y empuja en un círculo de 7 bloques. Alrededor de ella van saliendo **infectados** cada pocos segundos (zombis, esqueletos, arañas y momias). Mucha vida y armadura. Suelta el **corazón del mar**, esquirlas y un núcleo de coral.
- **Deriva:** ahogados que flotan, con la ropa de lo que eran: marinero, pescadora, viajero, capitán, buzo, novia, granjero y niño (más pequeño). Su **corriente** te arrastra hacia ellos y **te quita el aire aunque estés en tierra** (si se te acaba, te ahogas). Sueltan perlas de mar y a veces un núcleo de coral.
- **Coralina:** coral vivo que **se disfraza de otro mob** (en el juego se ve igual que el de verdad, con unas grietas rosas que casi no se notan; hasta la mirilla dice su nombre y su vida). Si te acercas a 3 bloques o la golpeas, da unos tirones, se le abre la cáscara y sale lo que es: una masa de brazos de coral con la cara partida en dos, que se te echa encima. Desde que sale, el **tótem de coral corrupto** ya no se fabrica: lo suelta ella.
- **Salen solos solo desde que se saca su novedad** en la ruleta:
  - `raiz_madre`: de vez en cuando brota una Raíz Madre en tierra firme, lejos de las demás (se queda para siempre).
  - `deriva_playas`: de noche, Derivas sueltos en la orilla de las playas.
  - `deriva`: de noche, grupos de 3 a 5 en las costas y en los pueblos.
  - `deriva_tormenta`: con lluvia también de día, y en grupos de 5 a 8.
  - `coralina`: 1 de cada 25 animales que aparecen es una Coralina disfrazada de ese animal.
  - `coralina_total`: además, alguno de los monstruos que aparecen y de los aldeanos de los pueblos nuevos.
- **Huevos** de los tres en la pestaña del mod (el de la Coralina sale disfrazada de un animal al azar).
- **Comandos:** `/coralosis mob raiz_madre`, `/coralosis mob deriva [variante | grupo [n]]`, `/coralosis mob coralina [mob | revelada]` (por ejemplo `/coralosis mob coralina minecraft:villager`) y `/coralosis mob probar` (intenta sacar ahora, alrededor de ti, lo que saldría solo, y dice dónde o por qué no).

## La Luna del Ojo: música y cierre
- Mientras el ojo está en el cielo suena una **música de ambiente oscura**, bajita pero que se oye (la del juego se calla esa noche).
- **Al acabar la noche, otra animación:** las venas de coral se retraen hacia la luna, el ojo parpadea nervioso y se cierra con un golpe sordo, las grietas se curan y vuelve la luna de siempre, con su propia música.

## Minimapa 1.5.0
- Los letreros de los waypoints y de las muertes **de lejos son mucho más pequeños** (solo el icono y la distancia); el letrero completo sale solo de cerca o si lo miras. De las muertes viejas, de lejos, ya no sale letrero.
- **Elegir qué waypoints se ven sin borrarlos:** botón «Qué se ve» en el mapa grande (tecla M). Cada uno se puede ocultar o volver a ver, y hay botones para verlos todos, ocultarlos todos o quitar las muertes viejas. Los ocultos no salen en el minimapa ni en el mundo, y en el mapa grande salen apagados.

## Mazmorras de tótems arregladas
- **Barco Varado:** el casco ya es estanco (antes se podía entrar nadando por debajo y por la proa sin pasar la reja); el camarote del capitán tiene paredes y techo de verdad (antes no tenía y se cogía el botín sin llave); la escotilla de la cubierta tiene una jaula de reja que solo cuenta los nidos de la cubierta; escalas de cuerda por fuera del casco para volver a subir si te caes por la borda; la proa descansa sobre un banco de roca.
- **Capilla de los Ahogados:** la reja de detrás del altar llega hasta el techo (le faltaban 3 bloques por arriba) y la escala del pozo sale al rellano (antes no se podía volver a subir).
- **Cripta de los Pescadores:** el pozo con la reja ya no tiene caminos del laberinto por detrás, la reja tapa el hueco entero, la escala llega de abajo arriba y el relicario es una sala grande con su puerta (antes un cofre estaba en la puerta). El foso de pinchos tiene una escala para salir.
- **Cueva de Coral:** todos los túneles tienen escalones y se vuelven a subir andando desde cualquier sitio (sin perlas ni tridente); la reja tapa el túnel entero y la puerta del relicario está en el túnel que entra a la geoda, que ya se puede abrir.
- **Cuevas de Tinta (Kraken):** 6 nidos en los rellanos de la zona de los puentes, que no tenía ninguno.
- Las rejas ahora cuentan solo los nidos de su planta y todos sus bloques dicen lo mismo.
- **Ojo:** las mazmorras que ya estén puestas se quedan con el plano viejo: hay que ponerlas otra vez (`/coralosis dungeon <tipo> en <x y z>`, y `/coralosis dungeon olvidar <id>` la vieja).

# Coralosis 1.22.88

## La Luna del Ojo: venas por todo el cielo, niebla y recuadro de avisos
- **Las venas de coral envuelven todo el cielo:** salen de la luna mientras se agrieta y, cuando se abre el ojo, siguen creciendo hasta cubrir el cielo entero (unos 25 segundos). No paran en toda la noche: laten, ondulan despacio y por ellas corren pulsos de luz que salen del ojo.
- **Niebla de la Luna del Ojo:** desde que se abre el ojo hay una niebla rojo oscuro, no muy espesa (se ve hasta unos 80 bloques), con esporas rojas y ceniza flotando y algún ruido lejano de vez en cuando.
- **Se ve con los shaders de Derivaland:** el ojo, la luna agrietada y las venas ya salen también con los shaders puestos (y siguen la inclinación que el pack le da al camino del sol y la luna).
- **Recuadro de avisos arriba a la derecha:** lo que anuncia la gema (eventos coral, dificultad, recompensas...) se queda 3 minutos en un recuadro arriba a la derecha, del color que salió en la ruleta. Si hay varios, se apilan (los 3 últimos), y se colocan debajo de los iconos de efectos.
- Los textos de la ruleta de la Luna del Ojo ya no hablan del timón.

# Coralosis 1.22.87

## La Luna del Ojo: animación nueva y todas las noches tras el Kraken
- **Cada vez que sale, la luna se abre:** la luna cambia por una luna pálida con el párpado cerrado; late un corazón cada vez más deprisa y el cielo se va poniendo rojo; la luna se agrieta tres veces (con temblor y crujido) y de ella salen venas de coral que se extienden por el cielo; tiembla todo y **el ojo se abre de golpe**: destello, onda expansiva, pantalla roja, rugido y el título.
- **El ojo está vivo:** mira a su alrededor, parpadea de vez en cuando y, **si te quedas mirándolo, te mira a ti** (la pupila se centra y se estrecha y suena un latido). Al amanecer el párpado se cierra, las venas se apagan y vuelve la luna de siempre.
- **Cómo va a más:** antes del Guardián, solo cuando un admin lanza el evento coral. Al caer el Guardián, la noche siguiente sale sola la ruleta («La Luna del Ojo volverá») y vuelve cada luna llena. **Al caer el Kraken, igual: sale la ruleta («El ojo ya no se cierra») y desde entonces es Luna del Ojo todas las noches, sin excepción: ya no se duerme nunca.**
- **El comando del evento ahora va con los demás:** `/coralosis evento coral luna_ojo` (y `luna_ojo parar` / `luna_ojo estado`).

# Coralosis 1.22.86

## La Luna del Ojo: primero evento coral, para siempre tras el Guardián
- **Antes del Guardián es un evento coral:** la lanza un admin para una sola noche con `/coralosis luna_del_ojo esta_noche` (sale la ruleta roja). Esa noche la luna abre un ojo, no se puede dormir y los monstruos van reforzados; al amanecer se acaba.
- **Al vencer al Guardián se queda para siempre:** al atardecer de la noche siguiente sale sola la ruleta roja avisándolo, esa misma noche ya es Luna del Ojo y desde entonces lo es **cada luna llena** (cada 8 días de juego, unas 2 h 40 min reales; unas 3 por sesión de 8 h). Esas noches no se puede saltar la noche durmiendo.
- Ya no se saca a mano con `/coralosis novedad luna_del_ojo`: sale sola tras el Guardián. `/coralosis luna_del_ojo parar` la quita por una noche y `estado` dice en qué punto está.

# Coralosis 1.22.85

## Dos cambios para siempre: la Luna del Ojo y los mineros
- **La Luna del Ojo (evento coral):** un admin la saca en la ruleta con `/coralosis novedad luna_del_ojo` (sale roja, como un evento coral, y no pide jefe ni semana: se saca cuando queráis). Desde ese momento es para siempre: **cada noche de luna llena la luna abre un ojo enorme**, el cielo y la niebla se tiñen de rojo sangre y sale el aviso «LA LUNA DEL OJO — Esta noche no se duerme». La misma noche en que sale en la ruleta ya es Luna del Ojo, aunque no toque luna llena.
  - **No se puede dormir:** la cama dice que la luna os está mirando, y quien ya estuviera dormido se despierta. La noche no se salta.
  - **Monstruos mucho más fuertes:** vida y daño x2,5, un 35 % más rápidos, más armadura, casi no se dejan empujar, las flechas de los esqueletos y las explosiones de los creepers hacen el doble, y los zombis rompen puertas.
  - **Más listos:** os huelen desde mucho más lejos y van a por vosotros aunque no os vean.
  - **Muchos más:** salen grupos extra alrededor de cada jugador (hasta 70 cerca de cada uno).
  - Al amanecer el ojo se cierra y los que queden vivos vuelven a ser normales.
  - Para admins: `/coralosis luna_del_ojo esta_noche` la fuerza esta noche, `parar` la quita esta noche y `estado` dice cómo está. Fuerza, velocidad y número de monstruos se ajustan en `[luna_del_ojo]` del coralosis.toml.
- **Los mineros (cambio de dificultad, para el final):** `/coralosis novedad mineros` (pide el Kraken vencido y la semana 4). Desde entonces, unos pocos zombis y esqueletos (un 6 %) salen con un pico en la mano. Os huelen aunque estéis encerrados y, si no pueden llegar hasta vosotros, **rompen las paredes y suelos que les estorban**: con sus grietas y su ruido, más despacio cuanto más duro es el bloque (madera y piedra, unos 3-4 segundos cada bloque). Lo que rompen cae como objeto. No rompen cofres ni nada con contenido, ni obsidiana, ni nada dentro de una zona protegida, ni nada si `mobGriefing` está apagado. La probabilidad se cambia en `[mineros]`.

# Coralosis 1.22.84

## El final de temporada: el ojo del timón se abre
- **El ojo del timón despierta en el logo del final:** al hacer que se abriera en la intro, el logo pasó a llevar el párpado cerrado, y en el final se quedaba dormido. Ahora, cuando aparece DERIVALAND al final de la temporada, el ojo da un respingo y se abre con su destello, su onda y su sonido, igual que en la intro.

# Coralosis 1.22.83

## El final de temporada, con fotografía de cine y personajes más vivos
- **La misma fotografía de la intro:** resplandor, bruma de polvo en el santuario, sombras en los rincones, viñeta y grano, y un color para cada momento: el santuario cansado tras la batalla, la sala vacía y fría, el ojo que lo tiñe todo de rosa y brilla cada vez más (con un golpe de aberración en cada chispazo) y la sombra en la pared, oscura y dura.
- **Enfoque de cine:** en los primeros planos del ojo, la cámara lo enfoca a él y desenfoca el fondo; cuando el grupo se va, los enfoca a ellos y al final el foco salta al ojo.
- **Gestos que se enlazan:** al cambiar de gesto ya no saltan de una postura a otra; pasan poco a poco (también al levantarse del suelo o al dejar de jadear).
- **Gestos de después de la batalla rehechos:** respiran hondo (cogen aire deprisa y lo sueltan despacio), el de rodillas levanta la cabeza a ratos para mirar el cuerpo, el que jadea se endereza y se pasa la mano por la frente, el choque de manos tiene su impulso y su ¡plas!, el que bebe da tragos y se limpia la boca, el que cojea se hunde al pisar con la pierna mala, y el que ayuda a levantarse tira echándose atrás.
- **Más vida en el grupo:** cada uno mira a su alrededor y a los demás; tras chocar la mano, dos se abrazan; uno ayuda a levantarse al que estaba con la cabeza entre las manos; otro avisa de que se van; y se marchan por parejas, arrancando poco a poco, girando sin brusquedad y con el cuerpo meciéndose al andar.

# Coralosis 1.22.82

## La intro: sin varas tiradas y nadie en los tejados
- **Ni una vara del End tirada por la cubierta:** el agua del hundimiento rompía las guirnaldas de luces del crucero y las dejaba como objetos sueltos; además se quedaban en el mundo y salían otra vez en la cubierta la vez siguiente. Ahora, mientras dura la cinemática, junto al barco (en el puerto y en alta mar) no aparece ningún objeto suelto, y los que quedaban de otras veces se quitan solos.
- **Nadie en los tejados al final:** el sitio de la orilla de uno de los náufragos caía bajo el alero de una casa del puerto y acababa sentado encima del tejado. Ahora cada uno se despierta y se mueve por arena al aire libre, a la altura de la playa.

# Coralosis 1.22.81

## La intro: arreglos del crucero y del despertar
- **Nadie flota por fuera del barco:** al atardecer en alta mar, los que miraban el mar estaban un bloque por fuera de la barandilla del lateral (ahí no hay pasillo) y parecían a punto de caerse. Ahora están apoyados en la barandilla de cristal de la cubierta de arriba, por dentro.
- **Nadie nada en el aire:** en la primera persona de la tormenta, los que se tiraban por la borda podían quedarse congelados a media caída (y luego nadando en el aire). Era un fallo del arreglo de los cortes cuando a alguien le tocaban dos saltos de sitio seguidos; ahora la caída se ve entera hasta el agua.
- **La misma mañana en la playa y en el pueblo:** al girarse hacia Puerto Deriva la luz pasaba de golpe del amanecer dorado a un día gris y frío. Ahora el pueblo tiene la misma luz dorada del sol recién salido, y el amanecer empieza un poco más tarde para que el pueblo no esté a oscuras.

# Coralosis 1.22.80

## La intro: más color y sin saltos en los cortes
- **Nadie se teletransporta al cambiar de plano:** la cámara cortaba uno o dos fotogramas antes de que llegaran del servidor los sitios nuevos de los personajes, y se les veía en el plano nuevo donde estaban en el anterior antes de saltar. Ahora el servidor marca cada movimiento con su instante, la cámara nunca va por delante de lo que ya ha llegado y cada salto de sitio (y su gesto nuevo) se hace justo en el fotograma del corte.
- **Mucho más color:** más contraste y saturación, sombras teñidas de azul y luces doradas mucho más marcadas, más resplandor y rayos de sol más fuertes.
- **Sombras en los rincones:** oclusión ambiental en pantalla; las esquinas, los rincones y el suelo junto a los pies de la gente se oscurecen, como con shaders.

# Coralosis 1.22.79

## La intro, con fotografía de cine
- **Un procesado de imagen propio, como un pack de shaders (solo durante la cinemática):** resplandor en las luces, los farolillos y los fuegos; rayos de sol que se cuelan entre el barco, las casas y la gente; bruma en la lejanía que da profundidad; desenfoque del fondo con enfoque automático en lo que mira la cámara; viñeta, un poco de aberración en los bordes y grano de película.
- **Cada parte tiene su color:** la feria dorada, el mar al mediodía, la tarde que se dora en alta mar, la fiesta, la noche azul, la tormenta fría y apagada, el agua verde y turbia, el despertar blanco y blando, la playa al atardecer y el puerto nublado.
- **Cámara en mano:** la cámara respira un poco, como si alguien la llevara al hombro; más en la fiesta y mucho más en la tormenta.
- No hace falta instalar nada: va dentro del mod y se quita solo al acabar la cinemática.

# Coralosis 1.22.78

## La intro: nadie atraviesa el suelo
- **Arreglados los saltos de celebración:** entre salto y salto la gente se hundía en el suelo (hasta el pecho o la cabeza) y volvía a salir, una y otra vez. Pasaba en la celebración del boleto, en las victorias de la feria y en la fiesta de noche del crucero. Ahora, entre salto y salto, se quedan con los pies en el suelo.

# Coralosis 1.22.77

## La intro: el barco ya no se duplica
- **Arreglado de verdad el barco gemelo del puerto:** al empezar la cinemática se limpiaba lo que quedó del crucero de alta mar de la vez anterior y, sin querer, se olvidaba también el barco atracado; al zarpar no sabía qué tenía que quitar y se quedaba una copia idéntica en el muelle. Pasaba a partir de la segunda vez que se veía la intro.
- **El coral del logo cruje:** su sonido ahora son crujidos (chasquidos secos que se van espesando, crujidos largos como de algo que se tensa, un crac con cada trozo grande y un rumor grave por debajo).

# Coralosis 1.22.76

## La intro, pulida
- **Fuera el barco fantasma:** al salir del puerto ya no se queda un segundo crucero quieto en el muelle (el cliente se quedaba con el barco viejo dibujado tras el corte; ahora se le vuelve a mandar).
- **Sin teletransportes al cambiar de plano:** cuando cambia la toma, cada uno ya está en su sitio (antes se les veía deslizarse hasta él), y cuando se juntan para abrazarse o chocar la mano van andando el uno hacia el otro (el de la pesca, corriendo).
- **El logo:** el coral crece con un sonido nuevo (una nota de cristal por cada trozo, subiendo, con burbujas) y, cuando termina, **el ojo del timón despierta**: estaba cerrado, da un respingo y se abre de golpe con un destello, una onda rosa y su propio sonido; la pupila se cierra en una raya y se queda brillando.

# Coralosis 1.22.75

## La intro, a su ritmo y con más vida
- **Ni tan larga ni acelerada: 1 min 47 s.** Cada plano dura lo que tiene que durar (de 3 a 7 segundos), las cámaras van a su velocidad de siempre y en el montaje de la feria cada premio tiene su plano de más de 2 segundos.
- **La gente se relaciona:** en la feria, el que gana lo celebra y choca la mano con su amigo (el de la pesca viene corriendo desde la caseta); en la ruleta dos se abrazan y otros dos chocan; en el escenario hay abrazos y choques de mano.
- **En el crucero:** al atardecer, apoyados en la barandilla y dos parejas con el brazo por los hombros; en la fiesta, una conga da vueltas a la pista (con su patada cada cuatro tiempos, al compás de la música) mientras otros bailan en medio; de noche, abrazados mirando los fuegos y señalándolos; el de la proa se gira, da un paso atrás y señala el rayo.
- **En la tormenta:** hay gente agarrada a la barandilla, a uno lo tira el rayo del mástil y otro corre a levantarlo.
- **Gestos con más chicha:** antes de celebrar se encogen un instante y sueltan los brazos de golpe; el cuerpo entero acompaña (se agachan, se echan atrás, mueven las caderas al bailar) y los gestos van más pausados.
- La cámara del martillo sube con el disco hasta la campana y vuelve a bajar a los ganadores.
- Música de la intro rehecha a la nueva duración.

# Coralosis 1.22.74

## La cinemática de la intro, más corta y más natural
- **Dura la mitad: 1 min 17 s (antes 2 min 41 s).** Pasa todo lo mismo, pero cada escena dura lo justo y se pasa de una a otra con cortes, como en una película: fuera los carteles en negro (los «Hace unas semanas...» y «Una semana después...» salen ahora pequeños abajo, sobre la imagen), fuera los 8 segundos de negro con latidos y el despertar va a trozos, abriendo y cerrando los ojos.
- **El montaje de la feria, sin pantalla partida:** un plano por cada premio, uno detrás de otro (martillo, dardos, tiro al blanco, pesca, carrusel y la ruleta).
- **Animaciones más naturales:** nadie se balancea como un péndulo ni hace lo mismo a la vez que otro. Cada uno celebra a su manera (aplaude, levanta el puño, los brazos en V), salta unas cuantas veces cuando le toca y no a la vez que los demás, mira a su alrededor a ratos, respira y carga el peso de una pierna a otra. Al andar, las piernas van al paso (ya no patinan), y en la tormenta la gente corre de verdad, algunos tapándose la cabeza. En la fiesta, cada uno baila con su paso al compás de la música.
- Música de la intro rehecha a la nueva duración.

# Coralosis 1.22.73

## La cinemática del final: el grupo, armado hasta arriba
- **Todos van equipados con cosas del mod:** armadura de coral purificado, de percebes y de netherita con percebes; espadas y tridentes de coral purificado, tridentes de esquirla, hachas y espadas de percebes, arcos de coral, escudos de coral y de percebes, y tótems de coral en la otra mano.
- **Más animaciones tras la pelea:** uno en guardia con el escudo, otro de rodillas recuperando el aliento, otro jadeando, uno comiendo algas purificadas, dos que chocan el puño, uno que alza el tridente, el que se apoya el arma al hombro... Al irse, uno ayuda a levantarse al que estaba sentado, otro se lleva al que cojea, y el último se queda vigilando en la puerta antes de salir.
- **Música nueva del final:** más tranquila y más «de deriva» al principio, un tramo de tensión que corta en seco con el negro, y un tema luminoso para el «Gracias por participar».

# Coralosis 1.22.72

## La cinemática del final, pulida
- **El ojo ya no late como un corazón:** brilla cada vez más, con un zumbido que sube y chispazos de energía a destiempo.
- **De la criatura solo se ve la sombra:** fuera el plano de la silueta y fuera el ojo dentro de la sombra. Al final, la sombra gira la cabeza hacia la cámara y corte a negro.
- **Sin «Continuará» ni «Temporada 2»:** acaba con el logo y **«Gracias por participar»**, y luego unos segundos de negro y silencio para poner los créditos finales.
- Dura 1 min 23 s.

# Coralosis 1.22.71

## La cinemática del final de la temporada
- **Nuevo comando para admins: `/coralosis cinematica final`** (o con jugadores concretos). Se lanza cuando Bajamar ya está derrotado: busca su cuerpo y su santuario solo (si no lo encuentra: `/coralosis cinematica final en <centro del santuario>`). Dura 1 min 28 s y al acabar cada uno vuelve a donde estaba. Se corta con `/coralosis cinematica parar`.
- **Qué pasa:** tras la batalla estáis todos agotados alrededor del cuerpo de Bajamar. El ojo rosa se le sale del pecho y rueda por el suelo. Os levantáis y os vais del santuario (uno se gira a mirar un momento). La sala se queda vacía... y el ojo empieza a latir, cada vez más fuerte, hasta que se eleva y el coral se le va pegando. Un destello, y en la pared crece la sombra de algo enorme, con cuernos de coral y el ojo rosa en la cabeza. Ruge. Al final solo se ve su silueta negra en la niebla rosa, girándose hacia ti... **Continuará. Temporada 2.**
- La amalgama no se ve nunca de verdad: solo su sombra y su silueta.
- Música propia para el final (con el tema de la serie en menor) y sus sonidos.
- Los personajes usan las skins del reparto de las cinemáticas.

# Coralosis 1.22.70

## La cinemática de la intro, pulida
- **En primera persona ya no se ve todo transparente:** la cámara va pegada a la cubierta del barco que se hunde (antes se metía dentro de los bloques). Ves a la gente, la chimenea, la cubierta inclinada, corres a la barandilla, te asomas y ves el agua abajo antes de saltar.
- **El hundimiento ya no parece un bug:** el crucero se inclina de proa como una sola pieza, a tirones, en vez de deshacerse en escalones. Las barandillas de cristal siguen enteras al inclinarse y no quedan restos flotando de cinemáticas anteriores.
- **La piscina tiene agua** (ya no nadan en el aire).
- **Movimientos más fluidos:** al cambiar de plano nadie aparece de golpe delante de la cámara; la gente entra andando desde fuera de la pantalla (el embarque, la tormenta, la cubierta en primera persona).
- **El despertar en la playa:** nadie se levanta de golpe. Unos se incorporan despacio y se ponen de pie, otros se quedan sentados con la cabeza entre las manos o tosiendo, alguno gatea, otro anda mareado, uno se estira, y hay quien va a ayudar al que sigue sin moverse. Tú te incorporas y miras a tu alrededor antes de levantarte.
- **Música nueva** con más ritmo en cada parte: la feria, el viaje, la fiesta en la cubierta, la tormenta (con latidos en primera persona) y el despertar.

# Coralosis 1.22.69

## La cinemática de la intro, nueva versión
- **La feria del puerto:** ya no se gana todo en la ruleta. Junto a la costa hay un parque de atracciones con noria, dardos, tiro al blanco, martillo de fuerza, pesca de patitos, carrusel y la Gran Ruleta.
- **Pantalla partida:** se ven varias atracciones a la vez (2, 3 o 4 paneles) que van cambiando entre sí; en cada una alguien acaba ganando su **boleto dorado** (el globo de oro, las tres dianas, la campana del martillo, el patito de oro, la sortija del carrusel y la rueda).
- **La salida del puerto:** el embarque por el muelle y el crucero zarpando de verdad, alejándose bloque a bloque hasta salir a mar abierto.
- **Alta mar:** el crucero navega solo en mitad del océano, sin nada alrededor (el juego busca un sitio con solo agua lejos del decorado).
- **La tormenta, mucho más bestia:** rayos sin parar (varios caen en el barco), olas que barren la cubierta, el viento se lleva barriles, tumbonas y sombrillas, fuego en la cubierta y la chimenea revienta.
- **En primera persona:** ves cómo se hunde el barco bajo tus pies, corres a la barandilla, miras abajo... y saltas al agua.
- **El despertar:** en la nueva playa junto al muelle de Puerto Deriva. Al alejarse la cámara sale el **logo de Derivaland Remake**, limpio, y le va creciendo el coral con su sonido.
- Nuevo objeto: **Boleto dorado**.
- Puerto Deriva tiene ahora una playa de arena al norte del muelle (al volver a poner el pueblo).
- **Para los admins:** hay que volver a poner el decorado (`/coralosis cinematica preparar en <x y z>`): tarda un poco más porque busca el sitio de alta mar.

# Coralosis 1.22.68

- Cinemática de la intro: el plano de la rueda del sorteo ya no tiene un farolillo delante.

# Coralosis 1.22.67

## La cinemática de la intro
- La que se ve nada más empezar Derivaland, unos 2 minutos y medio:
  1. **El sorteo:** el puerto en fiesta, la rueda gira y cae en el premio, el público lo celebra y sale el boleto dorado del crucero.
  2. **El crucero:** el «Deriva» al atardecer, todos bailando en la pista que se ilumina, fuegos artificiales de noche y alguien solo en la proa mientras se ve un relámpago a lo lejos.
  3. **La tormenta:** rayos, el barco se balancea, un rayo revienta la chimenea y el barco se hunde de proa.
  4. **Cerramos los ojos:** bajo el agua, parpadeos, todo negro y latidos.
  5. **El despertar:** tumbados en la arena de Puerto Deriva, se abren los ojos, todos se levantan entre los restos del barco y aparece el pueblo con el título.
- Los personajes son actores con skin propia: cuando estén las skins de todos, se cambian sin tocar nada más.
- Se ve con bandas de cine y su música. Con los shaders de Derivaland puestos se ve con sus sombras, rayos de sol y brillo.
- **Para los admins:**
  - `/coralosis cinematica preparar en <x y z>` pone el decorado (mejor en medio del mar);
  - `/coralosis cinematica intro` la pone a todos;
  - `/coralosis cinematica parar` la corta.
- Minimapa 1.4.1: los rayos y letreros de los waypoints no salen cuando la cámara no es la tuya (en las cinemáticas).

# Coralosis 1.22.66

## El faro y las catacumbas de Bajamar
- El faro del islote de Puerto Deriva ahora tiene una **linterna** de verdad. Apagada no prende con nada: «La mecha está empapada».
- Se enciende con el **Aceite de faro purificado**: algas purificadas, coral purificado, una perla de mar y una botella. Su receta va en la novedad «El faro», que no se puede sacar hasta que caiga el Kraken.
- Al encenderlo:
  - el faro vuelve a dar luz y su haz gira sobre la bahía;
  - sale en la ruleta y tiembla la pantalla de todos;
  - se oye a Bajamar desde abajo;
  - el suelo del faro se hunde y aparece una escalera de caracol que baja por la roca.
- **Las catacumbas**, de arriba abajo:
  - la escalera del islote;
  - el osario de los ahogados, con nichos de huesos, criptas y una parte inundada;
  - las tres salas del eco: el barco roto del Capitán, la poza del Guardián y la tinta del Kraken. Cada reja se abre al limpiar sus nidos;
  - la antesala, llena de velas encendidas, donde espera **el Farero**, que suelta la llave de la puerta del santuario.
- Detrás de la puerta, el santuario de Bajamar.

# Coralosis 1.22.65

## Puerto Deriva, el pueblo de la costa
- Un admin lo pone con `/coralosis pueblo en <x y z>`: esas coordenadas son el suelo de la plaza. Mejor en una costa con el mar al este y con y = nivel del mar + 2 (65 en un mundo normal), así su agua cae justo a la altura del mar.
- Trae su propio terreno (unos 160 × 140 bloques) y deja la zona con el bioma del jardín pálido: hierba gris, agua turbia y el cielo apagado.
- **Abandonado y con mal rollo:**
  - 5 casas en pie donde vivir (la taberna, la lonja, la casa del médico, la del alcalde y la de la plaza), pero sucias: telarañas, ventanas tapiadas o rotas, puertas abiertas, la cena aún servida.
  - 15 casas en ruinas, sin tejado y con las paredes caídas; dos quemadas.
  - La iglesia, que hacía de ayuntamiento, con el tejado hundido, el coral subiendo por detrás del altar y velas que alguien sigue encendiendo.
  - El cementerio con tumbas abiertas desde dentro y flores de ojo que se abren de noche.
  - El pozo con coral dentro, el muelle con un trozo hundido, barcas hundidas en la bahía y la pasarela rota hasta el islote del faro, que está apagado.
  - Huertos muertos con espantapájaros, árboles secos con musgo colgando y el coral corrupto subiendo desde la orilla (ojo: pisarlo infecta).
- Carteles con los avisos de los que vivían allí y cofres con sus diarios.

# Coralosis 1.22.64

## Cada mazmorra de tótems con su propio plano
- **Capilla de los Ahogados:** una iglesia de verdad.
  - Arriba, nártex, nave larga con bancos y columnas, cuatro capillas laterales y el ábside con el altar.
  - Detrás del altar, la reja y la bajada a la cripta. Abajo, salón inundado con tumbas, el osario con calaveras, la sala del guardián y el relicario.
- **Cripta de los Pescadores:** catacumbas en laberinto, con pasillos estrechos, nichos y cámaras con sarcófagos.
  - Abajo, otro laberinto con la cámara central del nido especial.
  - El relicario está al fondo.
- **Cueva de Coral:** grutas a distintas alturas unidas por túneles que bajan.
  - Abajo, un gran lago con islotes.
  - El relicario es una **geoda de amatista**.
- **Barco Varado:** un barco entero dentro de una cueva marina, con cubierta, cubierta de cañones y camarotes, y la bodega inundada.
  - La llave está abajo del todo.
  - El relicario es el **camarote del capitán**, arriba en la popa: hay que volver a subir con la llave.

## Guardianes propios
Ninguno es el minijefe de las mazmorras de los jefes:

| Mazmorra | Guardián |
|---|---|
| Capilla | Chamán de coral |
| Cripta | nido especial |
| Cueva | **Pulpo Abisal**, un pulpo enorme con mucha vida, nuevo |
| Barco | Rey Cangrejo |

## Tótems también en las mazmorras de los jefes
- En pecios, fosa y cuevas, el **cofre grande trae 2 o 3 tótems de la inmortalidad** y los normales tienen un 15 % de traer uno.
- En la del **Kraken** (las Cuevas de Tinta), además, tótems de coral: el cofre grande tiene un 60 % de traer uno **corrupto** y un 35 % de traer uno **purificado**, y los cofres normales tienen un 10 % de traer uno corrupto.

## Ojo
- **Todos con el modpack 1.22.64** (cambia Coralosis). Las mazmorras de tótems que ya estuvieran puestas se quedan con el plano viejo: hay que ponerlas otra vez.

# Coralosis 1.22.63

## Mazmorras de tótems (nuevas)
Cuatro mazmorras nuevas, cada una con su aspecto:
- **La Capilla de los Ahogados:** piedra vieja y musgo, bancos mirando a un altar con velas, campana y vidrieras. Abajo, la cripta inundada. Su guardián es el **Chamán de coral**.
- **La Cripta de los Pescadores:** pizarra, nichos con calaveras, sarcófagos, telarañas y un foso con pinchos bajo tablas podridas. Su guardián es un **nido especial**.
- **La Cueva de Coral:** una cueva natural de coral y prismarina, con liquen que brilla, charcas y algas. Su guardiana es la **Reina Medusa**.
- **El Barco Varado:** la cubierta con mástil, velas y cañones fantasma, y abajo la bodega inundada con la carga. Su guardián es el **Rey Cangrejo**.

**Recorrido (igual en las cuatro, pero la cripta y la cueva van en espejo):**
1. **Arriba:** entrada, cruce y dos salas, todas con cofres y nidos. Para bajar hay una reja que no se abre hasta acabar con los nidos de arriba.
2. **Abajo:** un salón con nidos y cofres grandes, una sala lateral con más botín y la sala del **guardián**.
3. El guardián suelta la **Llave del relicario**, que abre la **Puerta del relicario**. Es una puerta y una llave nuevas, distintas de la de coral, para que no se mezclen.
4. Detrás está el **relicario**: el cofre con lo mejor y los tótems.

**Comandos:**
- **Poner:** `/coralosis dungeon capilla|cripta|cueva_coral|barco en <x y z>`.
- **Reabastecer (solo a mano):** `/coralosis dungeon reabastecer`. Sale en la ruleta. Los cofres se llenan, vuelven el guardián y los nidos, y se cierran la puerta y la reja.
- **Tótems:** en cada reabastecimiento se reparten **entre 8 y 12 tótems de la inmortalidad en total** entre todos los relicarios. Se cambia con `/coralosis dungeon totems <mín> <máx>`.
- **Al ponerla**, cada mazmorra trae ya 2 o 3 tótems.

Las de antes (pecios, fosa, cuevas) no se reabastecen y ya no traen tótems.

## Tótems de coral
- El corrupto y el purificado salen ahora **después del Guardián**, para tenerlos contra el Kraken y Bajamar (`/coralosis novedad recetas_totems`).

## Ojo
- **Todos con el modpack 1.22.63** (cambia Coralosis).

# Coralosis 1.22.62

## La marca del coral, en grande
Cuando cae el Capitán, a **todos** los del servidor (estén donde estén) les sale la marca del coral a pantalla completa:
1. La pantalla se oscurece y suenan tres latidos. Con cada uno la marca se ve más y el coral crece desde las esquinas.
2. Llega un fogonazo y la marca queda grabada, con brasas que suben.
3. Sale «LA MARCA DEL CORAL» y debajo lo que significa: cada muerte os quitará vida para siempre.

El mensaje sigue saliendo también en el chat.

## Mazmorras que se reabastecen
- Un admin pone las mazmorras donde quiera con coordenadas: `/coralosis dungeon pecios|fosa|cuevas en <x y z> [profundidad]`. La escalera empieza en esas coordenadas. La forma de antes (donde está el jugador) también sirve.
- Todas quedan apuntadas y **se reabastecen solas**:
  - los cofres se vacían y se llenan con botín nuevo;
  - vuelven los nidos y el minijefe que falten;
  - las puertas y las rejas se cierran otra vez.

  Cuando pasa, **sale en la ruleta de la gema** para todos.
- **Los cofres grandes pueden traer un tótem de la inmortalidad** (30 %).
- **Cuándo se reabastecen:** por defecto, al empezar cada sesión (2 minutos después de `/coralosis sesion empezar`, para que dé tiempo a entrar). Se cambia con `/coralosis dungeon reabastecer cada sesion|nunca|<horas>`.
- **A mano:** `/coralosis dungeon reabastecer [id]`.
- `/coralosis dungeon lista` enseña las mazmorras y cuándo se reabastecieron. `/coralosis dungeon olvidar <id>` deja de reabastecer una sin borrarla.
- Si hay alguien dentro, esa mazmorra espera a que se quede vacía.

## Tótems de coral
- El **corrupto** y el **purificado** salen juntos en la ruleta, en un solo grupo (`recetas_totems`), después del Kraken.
- La máquina ya no convierte el tótem corrupto en purificado hasta que ese grupo ha salido.

## Ojo
- **Todos con el modpack 1.22.62** (cambia Coralosis).

# Coralosis 1.22.61

## Las novedades de la temporada salen en la ruleta de la gema
Ya no se aplica nada de golpe. Cada novedad está guardada en un calendario oculto y **no cuenta en el juego hasta que un admin la saca**. Entonces sale la gema girando, cae en su color y enseña la novedad a todos:
- **violeta:** dificultad;
- **turquesa:** recetas nuevas;
- **coral:** aparece algo.

**Para los admins:**
- `/coralosis novedad`: la lista entera. Lo que ya ha salido, lo que se puede sacar (con un botón **[sacar]**) y lo que falta para lo demás.
- `/coralosis novedad <id>`: la saca en la ruleta.
- `/coralosis novedad quitar <id>`: la deshace sin ruleta, por si se sacó por error.

Los jugadores ven con `/coralosis novedades` lo que ya ha salido. Lo demás aparece como «???».

**El juego no deja adelantarse:** cada novedad tiene su requisito, que es un jefe vencido y/o una semana. Si no se cumple, el comando dice qué falta y no la saca. Por ejemplo, el tótem corrupto en la semana 1 no se puede sacar.

**Qué hay en el calendario:**
- **Fases de la infección** (temprana, intermedia, avanzada): al vencer a un jefe, la infección ya no sube sola, sube cuando sale su fase.
- **Semana difícil** (desde la semana 3): sin regeneración, monstruos de día y muchos más de noche, y la carne infecta.
- **«El oro ya no cura»** (desde la semana 4).
- **Grupos de recetas:** percebes, netherita de percebes, purificación, sabias, tridentes, coral purificado, lo del final y el tótem corrupto.
- **Los mobs nuevos:** salen en la lista, pero no se pueden sacar hasta que estén metidos en el mod.

## Recetas: hace falta el jefe Y que salgan en la ruleta
- Las recetas que van con un jefe **no se ven ni se pueden fabricar** hasta que se cumplen las dos cosas. Si el jefe ya cayó pero aún no han salido, en la G pone «Su jefe ya cayó: falta que la gema la anuncie».
- Antes se podían fabricar aunque salieran bloqueadas en la G; ahora la mesa no da el resultado.
- `/coralosis receta <id> desbloquear` también sale en la ruleta, y no deja si su jefe sigue vivo.
- El **corazón purificado** pasa a ir con el Guardián, porque lo necesitan las sabias, que también son suyas.
- El **corazón del mar** tendrá receta más cara (4 diamantes, 4 caparazones de nautilo y 1 bloque de lapislázuli) cuando llegue la Raíz Madre. Hasta entonces, la de siempre.

Los mundos que ya estaban empezados no pierden nada: lo que ya habían alcanzado se da por anunciado.

## Ojo
- **Todos con el modpack 1.22.61** (cambia Coralosis).

# Coralosis 1.22.60

## Crupieres y camareros del casino, más detallados
Ahora tienen el mismo tipo de cuerpo que los Deriva, pero vivos:
- **Pelo en 3D** según el peinado: corto, largo, coleta con lazo, rizado, rapado o peinado hacia atrás. Los que tienen bigote lo llevan en 3D.
- **Brazos más finos con codo:** brazo, antebrazo y mano con dedos. Al repartir cartas, coger fichas o preparar cócteles doblan el codo y estiran el brazo de verdad.
- **Ropa en 3D:** cuello de camisa, pajarita, chaleco con puntas y cinturón con hebilla (crupieres), delantal largo (camareros), liga roja en la manga, gemelos y zapatos.

Los que ya estaban puestos en el mundo se cambian solos por los nuevos al cargar la zona.

## Ojo
- **Todos con el modpack 1.22.60** (cambia el casino).

# Coralosis 1.22.59

## Skins de coral para los mobs que no tenían
Los mobs que salían de los nidos de las peleas contra jefes con su skin normal ya tienen su versión infectada, igual que los zombis:
- **Esqueletos:** glacial, del pantano y wither.
- **Araña de las cuevas.**
- **Aldeano zombi.**
- **Illagers:** saqueador, vindicador e invocador (y los **vex** que invoca).
- **Piglin bruto** y **lepisma.**

En cada fase (temprana, intermedia y avanzada) el coral les cubre más el cuerpo, les brillan los ojos y les salen ramas de coral en 3D. Sin infectar se ven normales.

## Ojo
- **Todos con el modpack 1.22.59** (cambia Coralosis).

# Coralosis 1.22.58

## Zonas protegidas (`/zona`, solo admins)
Para que en ciertas zonas no se pueda romper, construir, etc.

**Cómo se crea una:**
1. `/zona varita`: te da un hacha de oro. **Clic izquierdo** en un bloque = esquina 1, **clic derecho** = esquina 2. También se puede con `/zona pos1` y `/zona pos2`, donde estés.
2. `/zona crear <nombre> [modo]`. Modos:
   - **total**: ni romper ni poner (es el que va si no pones ninguno);
   - **solo_romper**: se puede destruir el terreno, pero no poner bloques;
   - **solo_poner**: se pueden poner bloques, pero no quitar;
   - **libre**.
3. Listo. Con `/zona <nombre>` ves sus reglas y las cambias pulsando en [permitir] o [prohibir].

**Reglas de cada zona** (`/zona <nombre> regla <regla> <si|no>`):
- **romper:** romper bloques, pisotear cultivos y romper armaduras, cuadros y marcos.
- **poner:** poner bloques, cubos de agua o lava, mecheros, harina de hueso, azadas y hachas sobre bloques…
- **usar:** puertas, cofres, botones, palancas…
- **explosiones:** que rompan bloques.
- **fuego:** si no, se apaga solo en cuanto aparece.
- **pvp:** pelear entre jugadores.

Al crearla, «usar» y «pvp» vienen permitidos y lo demás prohibido.

**Más comandos:**
- `/zona <nombre> altura_completa`: la zona va del fondo del mundo hasta el cielo.
- `/zona ver`: enseña el borde con partículas (rojo: total, naranja: a medias, verde: libre).
- `/zona lista` y `/zona aqui`: todas las zonas, y en cuál estás.
- `/zona <nombre> prioridad <n>`: si dos zonas se pisan, manda la de más prioridad.
- `/zona <nombre> redefinir` y `/zona borrar <nombre>`.
- **`/zona ignorar`:** para ti. Te saltas las zonas y puedes construir dentro; ponlo otra vez para volver.
- Toda la ayuda en `/help zonas`.

Las zonas se guardan con el mundo. A quien intenta algo prohibido le sale un aviso: «Zona protegida «nombre»: aquí no se puede romper».

## Ojo
- **Todos con el modpack 1.22.58** (cambia Coralosis).

# Coralosis 1.22.57

## Bosses: ataques en área
Ya no van solo a por un jugador: cada boss tiene ataques que pillan a todo el grupo.
- **El Capitán:**
  - **Tormenta de tridentes:** caen varios encima de cada jugador y muchos más por toda la arena, en tres tandas. Hay que salir de los círculos.
  - **Chorros de agua** a tres jugadores a la vez.
  - **Remolinos** debajo de varios jugadores.
  - **Pinchos** en línea al objetivo y en anillo debajo de los demás.
  - **Salto** con una onda grande al caer.
- **Guardián del Abismo:**
  - El **rayo** apunta también a otros jugadores (1 más al principio, 2 más después).
  - Las **burbujas** van a todos.
  - Al acabar la **embestida** levanta una ola alrededor.
  - Las **estalactitas** caen ya desde la segunda fase.
- **Kraken:**
  - **Golpes y barridos de tentáculo** a varios jugadores a la vez.
  - Las **bolas de coral**, una para cada jugador en cada tanda.
  - La **embestida** acaba con una onda y pinchos alrededor.
- **Capitán Bajamar:**
  - **Rayo doble** que barre en abanico cruzándose.
  - **Tridentes y pinchos** hacia cada jugador.
  - El **puñetazo** revienta el suelo alrededor.
  - Caen **más orbes** por toda la sala.

## Muerte de Bajamar
- Su **cuerpo se queda en el suelo**, tal y como cae en la animación.
- Del cuerpo sale **la Gema del coral**, que se puede coger.
- A su lado cae el **Ojo de Bajamar**, rosa y brillante. **No se puede coger**: es para la cinemática del final de la temporada 1.

## Mensajes de muerte al estilo Deriva
- Todos los mensajes de muerte se han reescrito: «se quedó sin aire y ahora es uno más del fondo», «se dio contra el suelo: no había agua para amortiguar», «cayó ante… y se lo llevó la corriente»…
- Salen en el chat y en la gema que se rompe al morir.

## Ojo
- **Todos con el modpack 1.22.57** (cambia Coralosis).

# Coralosis 1.22.56

## Solo con fichas
- En el casino **ya solo se juega con fichas**: todas las máquinas, mesas y juegos cobran y pagan en fichas. Hay que pasar por la **máquina de cambio** (DerivaCoins → fichas) antes de jugar.
- Las **tragaperras de DerivaEconomía** también van con fichas cuando está el casino (tirada rápida, menú de jugar y premios por defecto).
- La barra de cócteles sigue cobrando en DerivaCoins.

## La casa siempre gana
- En el **panel de premios** (mayúsculas + clic derecho en una máquina, o `/casino premios`) hay un interruptor nuevo: **«La casa siempre gana»** con su **ventaja mínima** (en %).
- Activado (viene así, con un 1 %): ningún juego puede devolver de media más del 99 % de lo apostado. Si un admin pone premios demasiado generosos, se bajan solos lo justo, y avisa en el chat.
- Vale para todos los juegos del casino y para las tragaperras de DerivaEconomía (si sus premios en fichas dan de más, se bajan las probabilidades al tirar).
- Con un 1 % no cambia ningún premio de fábrica. Subidlo (por ejemplo a 5 %) si queréis que la casa gane más.

## Música nueva del casino
- Dos temas nuevos hechos para el casino, más tranquilos y con más ritmo: **«Casino»** (swing con saxo, vibráfono, bajo caminante y metales) y **«Azar»** (bossa lounge para la barra).
- El Gran Casino los pone en bucle al levantarlo. También salen en «Pistas de Derivaland» de cualquier altavoz.

## Volumen de la música para cada uno
- En el chat de voz, pestaña **Sonido**, hay un deslizador nuevo: **Música**. Baja (o sube hasta el 100 %) **solo para ti** la música y los vídeos de altavoces y carteles. Si el altavoz está al 100 % y lo pones al 50 %, tú lo oyes a la mitad y los demás igual que antes.

## Gran Casino
- **Escaleras nuevas:** escalera doble de mármol en el atrio, una a cada lado pegada a las columnas doradas, que sube hacia la entrada y llega al puente de la primera planta. Las del vestíbulo se quitaron.
- La cabeza del creeper ya no se cae: el verde que era arena ahora es lana.

## Ojo
- **Todos con el modpack 1.22.56** (cambian el casino, DerivaEconomía y DerivaMedia).
- Para ver el Gran Casino nuevo: `/casino2 destruir` y `/casino2 construir`.

# Coralosis 1.22.55

## Panel de premios para los admins
- **Mayúsculas + clic derecho** en cualquier máquina o mesa (siendo admin), o **`/casino premios`** junto a ella, abre su panel.
- Se puede cambiar **el premio y la probabilidad de cada cosa**: los números de la rueda, cada tortuga y cada caballo, los premios del rasca, del cofre y del empuja-monedas, los del pachinko por fuerza, la tabla del keno, los del póker, la ruleta, los dados…
- En minas, mayor o menor, crash, pociones y la torre se elige el **porcentaje que devuelven** de media.
- El panel calcula al momento **cuánto devuelve** cada apuesta. Hay un botón para volver a los premios **de fábrica**.
- Se guarda para todo el servidor.

## Casino Tower (juego nuevo)
- Torre de castillo de 4 bloques de alto con **8 pisos de puertas**. En cada piso eliges una puerta: tesoro y subes (el premio crece) o trampa y lo pierdes todo.
- **Cobra cuando quieras.** 4 niveles: fácil (4 puertas, 1 trampa), medio, difícil y experto (3 puertas, 2 trampas).
- En la máquina se ven las puertas abrirse: esmeralda las buenas y TNT las trampas.

## Máquina de cambio y fichas
- Bloque nuevo, la **máquina de cambio**: cambia DerivaCoins por **fichas del casino** y fichas por DerivaCoins, 1 a 1.
- Con fichas se juega en todo el casino. Si apuestas con fichas, cobras en fichas.

## Tragaperras
- En el casino solo quedan las tragaperras de **DerivaEconomía**, ahora **en 3D de verdad**: puerta con un arrecife pintado, bandeja cromada, consola con botones que brillan, marco cromado con cristal, tira de luces, letrero TRAGAPERRAS que se enciende al jugar, corales arriba y palanca.
- Las 7 tragaperras temáticas del casino siguen en el mod (por si acaso), pero ya no salen en la pestaña.

## Arreglos y mejoras de los juegos
- **Pachinko y plinko:** bolas pequeñas que caen botando de clavo en clavo. En el pachinko se ilumina el bolsillo donde entra y pone lo que paga.
- **Ruleta:** la bola es pequeña y acaba justo dentro de su casilla, también en la rueda de la pantalla.
- **Keno:** tus números se ven en el panel con marco dorado y, al acabar, los aciertos en verde y los que salieron en azul. En el tablero grande del fondo también salen tus números. Bolas pequeñas (y el bingo igual).
- **Crash:** si cobras, el cohete **sigue subiendo** hasta donde tenía que explotar en esa ronda. El botón de cobrar ya funciona con el ratón (antes solo con espacio).
- **Las explicaciones ya no se salen del recuadro verde.**
- **Cartas:** a mitad de partida, **Escape esconde el panel** para ver la mesa (las cartas, el cohete, la torre…). Otro Escape o un clic lo vuelve a sacar. Para salir, el botón «Hecho».
- Ya no sale «Nada esta vez» a mitad de partida (al repartir, en cada puerta…), solo al acabar.

## Barras y Gran Casino
- **Gran Casino (`/casino2`):**
  - Escaleras rehechas, con escalones bien puestos, muro y barandilla.
  - En vez del dino, una **cabeza de creeper gigante** encima de la gran barra del centro.
  - **Música en todo el casino** con los altavoces de DerivaMedia. El principal está en la **cabina del DJ** del escenario: ahí los admins pueden cambiar la música.
- **DerivaMedia 1.6.3:** los cables entre altavoces de más de 12 bloques ya no se dibujan (antes cruzaban todo el casino).

## Ojo
- **Todos con el modpack 1.22.55** (cambian el casino, DerivaEconomía y DerivaMedia).
- Para ver el Gran Casino nuevo hay que volver a levantarlo: `/casino2 destruir` y `/casino2 construir`.

# Coralosis 1.22.54

## Barras de cócteles nuevas
- **La barra de cócteles** ahora tiene frente de cuero capitoné granate con botones dorados, encimera de mármol negro con vetas de oro, columnitas doradas, luz bajo el canto y reposapiés de latón.
  - Encima lleva la carta en su atril, un frutero con limas, limones y cerezas, un vaso de pajitas y una campanita.
  - Por detrás, el camarero tiene su balda con vasos y un raíl de botellas.
- **Botellero nuevo**: fondo de espejo ahumado con celosía dorada, baldas de cristal con luz, columnas doradas y botellas de formas distintas (altas, cuadradas y redondas).
- **Bloque nuevo: tramo de barra.** Es igual que la barra pero sin servicio, para alargarla (en la pestaña Casino).
- Las barras que ya estaban puestas cambian solas de aspecto.

## El Gran Casino: `/casino2 construir`
Un casino nuevo entero, hecho para los juegos a tamaño real. El de `/casino construir` sigue como estaba.
- **Por fuera:** 73 bloques de ancho, dos torres art déco escalonadas con aguja, el letrero CASINO en la corona y DERIVALAND en neón, marquesina de entrada con bombillas y alfombra roja, y plaza con dos fuentes, palmeras y farolas.
- **Planta baja:**
  - Vestíbulo a doble altura con la fuente del dino y una gran lámpara.
  - **Bar del vestíbulo**, la caja y dos escaleras de mármol.
  - Atrio a doble altura con bóveda de cristal y oro, y en el centro **la gran barra cuadrada con 8 camareros** bajo una araña enorme.
  - Tragaperras (4 islas con marquesina), mesas de cartas y dados, carreras, craps, ruletas, recreativas y un **escenario** a doble altura con butacas.
- **Primera planta:** concursos (plinko, minas, crash, keno, bingo y 2 ruedas), **bar VIP** con 4 camareros, sala de altas apuestas, balcón sobre el escenario y lounge.
- Hay 46 juegos (algunos repetidos) y 34 tragaperras de siempre.
- **`/casino2 destruir`** lo quita y deja el terreno como estaba, aunque se haya reiniciado el servidor. Si se levantan varios, quita el último.

## Ojo
- **Todos con el modpack 1.22.54.**
- El Gran Casino es grande (unos 73 x 106 bloques y 48 de alto): conviene levantarlo en un sitio llano.

# Coralosis 1.22.53

## El casino, a tamaño real
Todos los juegos del casino están **hechos de nuevo como serían en la vida real**: ya no van metidos en una máquina tragaperras, y son lo bastante grandes como para que las cartas, las fichas y los dibujos se vean bien (antes se juntaban en algunas mesas de cartas).
- **Mesas de cartas en forma de media luna** con tapete de verdad, borde acolchado, bandeja de fichas y zapato: blackjack, Texas hold'em, baccarat (más larga), guerra, dragón y tigre, y mayor o menor (con un atril grande donde el crupier pone la carta).
- **Mesas de dados y de azar**: sic bo (con su campana de cristal), dados, craps (mesa enorme con paredes), cofres del tesoro y cara o cruz (con la moneda gigante en su soporte).
- **Ruleta de verdad**: el cilindro en una punta y el paño con los 37 números a lo largo.
- **Carreras** de caballos y de tortugas en pistas largas con sus calles, salida y meta.
- **La rueda de la fortuna** gigante, de 4 bloques de alto, con su mesa de apuestas.
- **Tableros de concurso de pie**: plinko con clavos dorados, minas con casillas iluminadas y crash con pantalla de cielo estrellado y la rampa del cohete.
- **Keno y bingo**: puesto con mostrador, el tablero de números al fondo y el crupier en medio (el bingo con su bombo de alambre).
- **Recreativas de verdad**: máquina de gancho con urna de cristal, empuja monedas, machaca topos, pachinko japonés, la torre, rasca y gana (quiosco), lotería (bombo de cristal) y pociones (mesa de alquimista con armario de botellas y caldero).
- **Las 7 tragaperras y el vídeo póker**, ahora de 2 bloques de alto con mueble, puerta pintada, rodillos tras el cristal, botones que brillan, palanca y letrero luminoso que se enciende al jugar.
- Cada juego ocupa lo que necesita (de 1x1x2 a 5x3) y el crupier se pone en su sitio, detrás o al lado.

## Casino nuevo con `/casino construir`
- **Distribución rehecha** para los juegos nuevos:
  - Planta baja: las mesas de cartas y dados en filas a un lado, y al otro la isla de tragaperras, las tragaperras de siempre y las recreativas contra la pared.
  - Primera planta: ruleta, craps, caballos y tortugas, y detrás la rueda, keno, bingo, plinko, minas y crash.
- Hay **2 mesas más** de blackjack y Texas hold'em.

## Ojo
- **Todos con el modpack 1.22.53.**
- Los juegos ya colocados del casino viejo **hay que quitarlos y volver a ponerlos** (ahora ocupan más). Lo más fácil: volver a levantar el casino con `/casino construir`.

# Coralosis 1.22.52

## El casino cobra vida: crupieres, camareros y cócteles
- **Crupieres en 3D** detrás de las 12 mesas (blackjack, ruleta, dados, baccarat, Texas, sic bo, guerra, dragón y tigre, craps, caballos, tortugas y cofres). Son **6 distintos**, con chaleco, pajarita y ligas en las mangas, y se mueven de verdad:
  - Reparten las cartas desde el zapato y les dan la vuelta.
  - Agitan los dados en la mano y los tiran.
  - Giran la ruleta, lanzan la bola, levantan la mano en el «no va más» y señalan el número.
  - Dan la salida de las carreras con una bandera a cuadros.
  - Presentan los cofres y señalan el que eliges.
  - **Aplauden** cuando ganas (y saltan con los brazos arriba si es un premio gordo) o se encogen de hombros si pierdes.
  - Te saludan con la mano cuando te acercas. Entre partida y partida miran alrededor, se colocan la pajarita y ordenan fichas.
- **Barra de cócteles** con **camarero en 3D** (hay 2 distintos): eliges un cóctel en la carta y lo prepara delante de ti.
  - Se da la vuelta, coge las botellas del botellero y las sirve en la coctelera.
  - Echa hielo, agita la coctelera, sirve en el vaso, le pone el adorno y te lo desliza por la barra.
  - Todo con sonidos y salpicaduras.
- **10 cócteles**, cada uno con su vaso, su color, su adorno y un efecto al beberlo:
  - Mojito (velocidad), Piña colada (regeneración), Margarita (prisa minera), Blue Lagoon (respirar bajo el agua y gracia del delfín), Tequila Sunrise (resistencia al fuego).
  - Cosmopolitan (suerte), Daiquiri de fresa (absorción), Coral Deriva (el especial de la casa: poder del mar), Dino Verde (el cóctel de DinoFino: supersalto), Noche Dorada (visión nocturna).
  - Cuestan 5–8 DerivaCoins (gratis en creativo).
- El edificio del casino trae ahora **2 barras**: una en el vestíbulo y otra arriba, con botelleros llenos de botellas.
- Bloques nuevos en la pestaña Casino: **barra de cócteles** y **botellero**.

## Animaciones mejoradas en todos los juegos
- Al ganar, **saltan monedas** del juego y caen al suelo, hay fuegos artificiales y suena una fanfarria. Con un premio de x10 o más sale **¡¡GRAN PREMIO!!** con tótem y cohetes.
- Las cartas vuelan en arco girando y suenan al caer; los dados suenan al botar y las fichas al apilarse.
- Los rodillos de las tragaperras hacen tic-tac al girar y un golpe al pararse. La bola de la ruleta suena mientras corre y va frenando.

## Arreglado
- Las cartas, los símbolos, los cofres y demás piezas de las animaciones se veían **girados del revés** (Minecraft gira 180° esos objetos al dibujarlos). Ahora salen como deben.
- Los caballos y las tortugas seguían corriendo de espaldas en la 1.22.51. Ya corren hacia la meta.

## Ojo
- **Todos con el modpack 1.22.52.**
- Para ver las barras nuevas hay que volver a levantar el casino con `/casino construir`. En las mesas de antes, el crupier aparece la primera vez que alguien las usa (si hay sitio detrás).

# Coralosis 1.22.51

## El casino, reimaginado de arriba abajo
- **Edificio nuevo entero** con `/casino construir`, estilo art déco de Las Vegas: **41 de ancho, 2 plantas y una plaza delante**.
- **Fachada**: piedra color crema con paneles art déco de sol naciente, columnas doradas con neón, cornisas doradas, vidrieras de colores y una gran banda negra con **DERIVALAND** en neón azul.
- **Cartel CASINO gigante** sobre el tejado (letras de 7 de alto en neón dorado), con marco de bombillas, soportes, una corona escalonada y focos apuntando al cielo.
- **Pórtico** con 4 columnas y marquesina de bombillas sobre la entrada, y **plaza** de mármol con alfombra roja, farolas, dos fuentes iluminadas, palmeras y setos.
- **Planta baja**:
  - Vestíbulo de mármol a doble altura.
  - **4 islas de tragaperras** con marquesinas de luces y neón.
  - **2 fosos de mesas** con cordón dorado y lámparas de araña.
  - **Rotonda** con 8 columnas, fuente y la **estatua del dino** subiendo hasta la **cúpula de cristal dorado**.
  - La caja con el letrero **JACKPOT**.
  - Techo artesonado con plafones de luz.
- **Primera planta**:
  - Balcón sobre el vestíbulo.
  - Pasarela de mármol hasta la rotonda.
  - Ruleta, craps, caballos y tortugas sobre moqueta de estrellas.
  - **BAR**, zona **VIP** con sofás y tragaperras.
  - Escenario **SHOW** con telón de terciopelo.
  - Palmeras en maceta.
  - Techo artesonado y lámparas de araña.
- **8 bloques de decoración nuevos** (pestaña Casino): piedra crema, fachada art déco, cornisa dorada, techo artesonado, vidriera dorada, moqueta de estrellas, papel pintado art déco y plafón de luz.

## Arreglado
- En la carrera de caballos y la de tortugas los animales iban de espaldas.

## Ojo
- **Todos con el modpack 1.22.51, también el servidor.**
- `/casino construir` ahora ocupa **41 de ancho, desde 1 bloque delante del admin hasta 61 hacia dentro y 35 de alto**: **borra lo que haya** (y rellena huecos debajo). `/casino deshacer` lo quita.

# Coralosis 1.22.50

## El casino, mucho más completo por dentro y por fuera
- **Plaza de entrada**: suelo de mármol, alfombra roja con barandillas doradas hasta la calle, dos fuentes iluminadas, palmeras, farolas doradas y jardín.
- **Fachada**: ventanas iluminadas con marco de neón, remate dorado con bombillas encima del cartel CASINO, focos apuntando al cielo y tiras de neón en los laterales.
- **Planta baja**: columnas doradas con anillo de neón alrededor del atrio, fuente en el centro, **estatua gigante del dino de DinoFino** al fondo del atrio, sofás y mesitas en la entrada, plantas y luces entre las máquinas y el letrero **JACKPOT** en neón sobre la caja.
- **Primera planta**: pared del bar con el letrero **BAR** y farolillos, letrero **VIP** y cordón dorado en la zona VIP, **escenario** con tocadiscos, focos y telón de bombillas, taburetes mirando al atrio y mesitas con lámparas.

## Ojo
- **Todos con el modpack 1.22.50, también el servidor.**
- `/casino construir` ocupa ahora también 14 bloques por delante (la plaza): **borra lo que haya**. `/casino deshacer` lo quita.

# Coralosis 1.22.49

## Casino de verdad: 2 plantas y luces por todas partes
- **Edificio nuevo** con `/casino construir`: casino de **2 plantas** (35 x 41).
  - **Fachada** con el gran cartel **CASINO** en neón dorado rodeado de bombillas, marquesina con luces, columnas doradas y alfombra roja en la entrada.
  - **Planta baja**: las 24 máquinas en las paredes, 8 mesas, lámparas de araña, pasillo de mármol y la caja al fondo.
  - **Atrio a doble altura** en el centro con barandilla dorada, claraboya y grandes lámparas de araña.
  - **Escaleras** a los dos lados del fondo hasta la **primera planta**: ruleta, craps, caballos, carrera de tortugas, **bar** con taburetes y **zona VIP** con tragaperras.
- **16 bloques de decoración nuevos** con texturas propias (pestaña Casino del creativo): moqueta de casino y moqueta real, mármol blanco y negro, pared de terciopelo, panel dorado, columna dorada, neones rojo, dorado, azul y rosa, bombillas que parpadean, lámpara de araña, barandilla dorada, taburete y barra de bar.

## Arreglado
- El vídeo póker, mayor o menor, bingo y rasca y gana salían con partes sin textura (morado y negro).

## Ojo
- **Todos con el modpack 1.22.49, también el servidor.**
- `/casino construir` ocupa 35 x 41 y 17 de alto (y 4 bloques por delante para la entrada): **borra lo que haya**. `/casino deshacer` lo quita.

# Coralosis 1.22.48

## Casino 3.0: 36 juegos, a tamaño de jugador y en 3D
- **Máquinas de 2 bloques de alto** (como un jugador) con vitrina de cristal y letrero luminoso, y **mesas de 2 x 1 y 2 x 2** con su tapete.
- **Animaciones en 3D en el mundo** que ve todo el que esté cerca: cartas que se reparten y se dan la vuelta, dados que ruedan, rodillos girando, la bola de la ruleta, el gancho, caballos y tortugas corriendo, el cohete del crash, la torre…
- **27 juegos nuevos:**
  - **Tragaperras:** Derivaland, Coral, Frutas, Dino, Pirata, Cangrejos y Kraken (cada una con sus símbolos y premios).
  - **Cartas y dados:** baccarat, Texas contra la banca, sic bo, mayor o menor, guerra de cartas, dragón y tigre y craps.
  - **Números:** keno y bingo.
  - **Arcade:** gancho de peluches (¡si lo pillas, el peluche es tuyo!), empuja-monedas, machaca topos, pachinko, torre de bloques y carrera de caballos.
  - **Rápidos:** rasca y gana, crash (cobra antes de que explote el cohete), cofre del tesoro, ruleta de pociones y **lotería diaria** (sorteo todos los días a las 21:00).
- Las pantallas de juego van en un panel abajo para que se vea la máquina mientras juegas.
- **Edificio nuevo:** `/casino construir` levanta un casino de 35 x 41 con los 36 juegos dentro.
- Las mesas de 1 bloque de antes siguen ahí, pero conviene quitarlas y ponerlas de nuevo.

## Ojo
- **Todos con el modpack 1.22.48, también el servidor** (cambia el casino).

# Coralosis 1.22.47

## Casino en 3D
- **Todas las mesas y máquinas del casino tienen modelo 3D nuevo**, ya no son cubos ni una tabla con un palo:
  - **Mesas** (blackjack, ruleta, dados y carrera de tortugas): patas de madera con pies de latón, baranda acolchada de cuero rojo y paño de juego.
  - **Blackjack:** bandeja de fichas del crupier, zapato de cartas y fichas apostadas.
  - **Ruleta:** la rueda de verdad, hundida en su cuenco de madera, con la cruceta de latón. Al jugar gira con la bola.
  - **Dados:** paredes altas de rebote y dos dados encima del paño.
  - **Carrera de tortugas:** calles separadas, las cinco tortugas en la salida y la meta con bandera de cuadros.
  - **Vídeo póker y Minas:** máquinas de pie con pantalla, botonera de colores, puerta de monedas y letrero luminoso arriba.
  - **Plinko:** tablero vertical con clavos de verdad, cubos de premio y letrero.
  - **Rueda de la fortuna:** rueda grande de pie con flecha y bombillas. Al jugar gira y las bombillas parpadean.
  - **Cara o cruz:** vitrina de cristal con una moneda gigante dentro, que da vueltas al jugar.
- Cuando se juega, los letreros hacen correr las bombillas y las pantallas se animan como antes.

## Altavoces: arreglado el sonido «a cámara lenta»
- Las canciones a 44,1 kHz (muchos MP3, M4A, enlaces directos, SoundCloud…) sonaban el doble de lentas y una octava más graves. Ya suenan normal.

## Flechas nuevas
- **Flechas de materiales:** se hacen como la flecha normal (material arriba, palo y pluma) y salen 4. Cuanto mejor el material, más pegan:

  | Flecha | Daño con arco normal | Se hace con | Extra |
  |---|---|---|---|
  | Normal | 6 | sílex | |
  | Cobre | 7 | lingote de cobre | |
  | Hierro | 8 | lingote de hierro | |
  | Oro | 8 | lingote de oro | Sale más rápida y llega más lejos |
  | Diamante | 9 | diamante | |
  | Percebes | 9 | lingote de percebes | Casi no se frena bajo el agua (tras el Capitán) |
  | Netherita | 11 | 8 flechas de diamante + 1 fragmento de netherita (salen 8) | No se quema (tras el Capitán) |
  | Coral purificado | 12 | lingote de coral purificado | Deja un rastro brillante (tras el Kraken) |

- **Flecha de ender:** flecha + perla de ender. Donde se clave, allí apareces, como si tirases una perla pero con la puntería del arco. Quita 1 corazón al llegar.
- Valen para arcos, ballestas y dispensadores. Los arcos de Coralosis multiplican el daño de la flecha que dispares: un arco de diamante con flechas de diamante pega bastante más.


## Cangrejos ermitaños: personajes de rol para los admins
Como las nutrias del Dedsafío: unos personajes con los que los admins pueden hablar con los jugadores, dar misiones, llevar concursos...

- **13 cangrejos**, cada uno con un sombrero o un adorno de una cultura, sus colores y su forma de ser:
  - **Ermi:** el ermitaño cotilla de la playa.
  - **Capitán Pinzanegra:** pirata.
  - **Pancho Pinzas:** mariachi de México.
  - **Juancho Arena:** comerciante de la costa de Colombia.
  - **Lola Concha:** bailaora de Andalucía.
  - **Inti:** guía de los Andes.
  - **Don Mateo:** gaucho con su mate.
  - **Kenji Kani:** viajero de Japón.
  - **Angus McPinza:** de Escocia.
  - **Sasha:** pescador del norte helado.
  - **Ramsés Pinzatón:** faraón de Egipto.
  - **Kai:** surfista de Hawái.
  - **Bjørn Caparazón:** vikingo.
- Cada uno lleva a la espalda una casa: **caracola, cubo o cofre**.
- **Los admins se convierten en ellos** con `/disfraz cangrejo <personaje>`.
  - Todos ven el cangrejo y su nombre, también en el chat.
  - Al disfrazarte te sale su ficha: cómo es, qué papel tiene y frases para usar.
  - Al hacer clic, el cangrejo levanta la pinza grande.
  - `/disfraz quitar` para volver. `/disfraz lista` para verlos todos. Más en `/help disfraz`.
- **También hay cangrejos NPC** (huevo en creativo):
  - Hablan solos de vez en cuando y te saludan con una de sus frases si les haces clic.
  - No atacan, no desaparecen y solo los pueden herir los admins en creativo.


## Tumbas: ya no te quedas con las cosas al morir
- Si el servidor tiene la regla **keepInventory** activada, Minecraft no suelta nada al morir y por eso no salía tumba y te quedabas con el inventario (pasaba igual en el suelo que saltando). Ahora las cosas **van igualmente a la tumba**, también si mueres en el aire: la tumba se queda flotando donde has muerto.
- Si algún día queréis que con keepInventory cada uno conserve sus cosas: `/tumbas keepinventory conservar` (y `/tumbas keepinventory tumba` para volver). `/tumbas estado` dice cómo está.

## Minimapa: calavera, cruces y distancias
- La muerte **más reciente** sale con una **calavera** (en el minimapa, en el mapa grande y en la lista de muertes). Las muertes pasadas, con una **cruz**.
- Encima de cada rayo de muerte sale un letrero con los **bloques de distancia** (se ve a través de las paredes y se lee igual de cerca que de lejos).
- Los **waypoints** también tienen ahora un rayo fino de su color con su nombre y la distancia.
- Si hay varias muertes en el mismo sitio, los letreros se ponen uno encima de otro en vez de pisarse.

## Ojo
- **Todos con el modpack 1.22.47, también el servidor** (cambian Coralosis, el minimapa, las tumbas y el casino).

# Coralosis 1.22.45

## Casino 2.0: todo con DerivaCoins
- **Todo el casino funciona ahora con DerivaCoins.** Las fichas de ayer se canjean 1 a 1 con el botón «Canjear fichas» de cualquier juego.
- **Juegos nuevos** (pestaña Casino del creativo, o crafteándolos): **Ruleta** (hasta toda la mesa a la vez), **Mesa de dados**, **Rueda de la fortuna**, **Carrera de tortugas**, **Plinko**, **Minas**, **Vídeo póker** y **Cara o cruz**.
- **Blackjack mejorado:** las cartas se reparten deslizándose desde el zapato, botón de **Rendirse** (recuperas la mitad) y luces en la mesa.
- **Animaciones por dentro y por fuera:** cada juego tiene su animación en pantalla (la bola de la ruleta, los dados botando, la rueda frenando, las tortugas corriendo, la bola del plinko…) y la mesa o máquina se enciende y se mueve en el mundo mientras se juega, con sonidos y partículas al ganar.
- **Tragaperras:** los rodillos rebotan al parar y, si toca premio, el marco parpadea y llueve el objeto ganado.
- **Edificio del casino:** un admin lo levanta con `/casino construir` (delante de donde mira), con todos los juegos y tragaperras dentro. `/casino deshacer` lo quita y deja el terreno como estaba.
- Admins: `/casino monedas dar <jugador> <cantidad>` y `/casino monedas quitar …`. En creativo los juegos de máquina van en modo prueba (gratis y sin premio).
- Ajustes del servidor en `config/derivacasino-common.toml`: apuesta mínima y máxima (1 a 50 de serie) y desde qué premio se anuncia a los de alrededor.

## Ojo
- **Todos con el modpack 1.22.45, también el servidor.**

# Coralosis 1.22.44

## Casino: mesa de blackjack
- Nuevo mod **Casino Derivaland**: una **Mesa de blackjack** (en la pestaña Casino del modo creativo, o crafteando lana verde, tablas y una esmeralda).
- Clic derecho en la mesa para mirar, **Sentarse** para jugar. Solo contra la banca, o **hasta 4 en la misma mesa**, por turnos.
- Se apuesta con **Fichas de casino**: en la misma mesa se cambian esmeraldas por fichas y al revés (1 esmeralda = 10 fichas; con Mayús, de 10 en 10).
- Botones: **Pedir**, **Plantarse** y **Doblar**. La banca se planta con 17 y el blackjack paga 3 a 2.
- Admins: `/fichas dar <jugador> <cantidad>` y `/fichas quitar …`. Cualquiera puede ver sus fichas con `/fichas`.
- Ajustes del servidor en `config/derivacasino-common.toml`: fichas por esmeralda, apuesta mínima y máxima, mazos, segundos por turno y si se puede cambiar en la mesa.

## Ojo
- **Todos con el modpack 1.22.44, también el servidor.** Sin el mod del casino no deja entrar.

# Coralosis 1.22.43

## El filtro +18 lo decide el admin del servidor
- El filtro +18 de los carteles (imágenes y vídeos porno, y vídeos que la web marca como +18) ahora se puede **encender o apagar desde el servidor**, para todos a la vez.
- Comandos (solo admins): `/filtro18 activar` y `/filtro18 desactivar`. Cualquiera puede ver cómo está con `/filtro18`.
- También en `config/derivamedia-common.toml`: `filtro_18 = true` o `false`. Viene **encendido** de serie.
- Al apagarlo, lo que estaba bloqueado se vuelve a cargar solo, sin tener que tocar los carteles.

## Copyright: quitado del todo
- El altavoz ya no mira si una canción puede tener copyright, y se han quitado los textos que quedaban.

## Ojo
- **Todos con el modpack 1.22.43, también el servidor** (Altavoces, Carteles y Voz 1.6.1). Con la 1.22.42 no deja entrar.

# (1.22.42)

## Fusión: lo de Dani (1.22.37 a 1.22.41) + lo nuestro (1.22.36)
Ahora está todo junto en el mod de Altavoces, Carteles y Voz 1.6.0. Abajo está lo que trae cada parte.

# (1.22.41)

## Arreglado: el sonido iba por delante del vídeo
- El cartel seguía el reloj del servidor, que va a tirones cuando el juego va justo, mientras que el sonido sigue a su ritmo. Por eso el sonido se adelantaba. Ahora el cartel sigue **lo que se oye de verdad en el altavoz**, así que imagen y sonido van juntos aunque el juego vaya lento.
- Si el ordenador no da para descodificar el vídeo a tiempo y se queda atrás, se vuelve a poner en su sitio en vez de ir arrastrando el retraso.
- El vídeo de los carteles gasta un poco menos de ordenador.

## Quitado: avisos de copyright
- Ya no salen los puntos de colores, la leyenda ni los avisos de «puede tener copyright».

# (1.22.40)

## Vídeo y sonido de los altavoces: ahora se descargan
- **Una sola consulta a YouTube.** Antes el altavoz pedía el sonido y el cartel pedía la imagen por separado, y YouTube a veces daba uno y no el otro, o cortaba a mitad. Ahora se pregunta una vez y de ahí salen las dos cosas.
- **El sonido se descarga entero antes de sonar** (tarda unos segundos; una canción, casi nada). Ya no se corta a mitad ni se queda pillado.
- **La imagen se descarga mientras tanto.** Mientras baja, el cartel la enseña desde internet como antes; cuando ya está entera (un vídeo de 24 minutos tarda unos 20 segundos), el cartel se pasa solo al archivo: sin cortes, sin retraso y saltando a cualquier minuto al instante.
- Lo descargado se guarda en `.minecraft/derivamedia/videos` y se borra solo (lo que lleva un día sin usarse, o lo más viejo si pasa de 3 GB). Los directos y los vídeos de más de 3 horas se siguen viendo por internet.
- Si la descarga falla, se usa el sistema de antes, así que nunca va peor que en la 1.22.39.

# (1.22.39)

## Vídeos de los carteles mucho mejor
- **Ya no se bloquean vídeos normales.** El filtro +18 confundía caras de cerca y escenas oscuras con desnudos y paraba vídeos de YouTube que no tenían nada. Ahora, en YouTube, Twitch, TikTok, Vimeo, Dailymotion, Kick e Instagram (que no permiten porno) se usa su propia marca de "mayores de 18". El filtro de imágenes queda solo para vídeos sueltos y de X/Twitter, y tiene que saltar 3 veces seguidas.
- **Más fluidos:** 30 imágenes por segundo (antes 20).
- **Más ligeros:** la resolución se ajusta al tamaño del cartel, así que el ordenador trabaja mucho menos.

# (1.22.38)

## Arreglado: el vídeo de los carteles iba con mucho retraso
- Si el vídeo tardaba más de 2,5 segundos en arrancar (lo normal con YouTube), el juego creía que iba desfasado y lo volvía a arrancar una y otra vez, así que nunca alcanzaba al sonido. Ahora se adelanta lo que tarda en arrancar y sale sincronizado con el altavoz.
- Si YouTube da un enlace que no deja ver (error 403), se pide por otra vía en vez de insistir con el mismo.
- Los vídeos de los carteles en bucle ya no fallan cuando el cartel lleva puesto más rato de lo que dura el vídeo.

# (1.22.37)

## Arreglado: los vídeos de los carteles solo los veía una persona
- Cada jugador necesita en su ordenador las herramientas para ver vídeos (yt-dlp y ffmpeg), y el juego solo sabía descargarlas de GitHub. Cuando GitHub fallaba, a quien no las tenía ya no le salía el vídeo.
- Ahora, si GitHub no responde, las baja de otras webs oficiales o de una copia guardada en el GitHub de Derivaland. Así todos ven el vídeo.

# (1.22.36)

## Vídeos en los carteles: arreglados
- **Ya no tardan una eternidad ni se quedan sin salir.** Con YouTube (que tarda unos segundos en dar el vídeo) el cartel se reiniciaba una y otra vez y no llegaba a enseñar nada. Ahora sale en unos segundos y va a la par con el sonido.
- **Ya lo ve todo el mundo, no solo quien lo pone.** Quien llegaba más tarde de lo que dura el vídeo se quedaba con el cartel vacío.
- Mientras carga, **el propio cartel dice qué está haciendo** (descargando el reproductor la primera vez, buscando el vídeo, abriéndolo...) o por qué falla. Si falla, lo vuelve a intentar solo.
- El reproductor (ffmpeg, yt-dlp y deno) se descarga al abrir el juego, no al ver el primer vídeo.

## Cable entre cartel y altavoz
- Con el **cable**: clic en el cartel y luego en el altavoz (o al revés). El altavoz pone el **sonido** y el cartel la **imagen** del vídeo, a la par. Si el cartel ya tenía un vídeo, se pone solo en el altavoz.
- Se ve el cable del altavoz al cartel. Agachado + clic en el cartel lo desenlaza.

## Chat de voz: menú por apartados
- **Micrófono**: cuál usar, cuánto se sube, hablar por voz o pulsando, umbral con la barra, probar el micro.
- **Sonido**: salida (cascos o altavoces), volumen de las voces, ensordecer y **volumen de cada jugador**.
- **Teclas**: cambia aquí mismo la de hablar, silenciar, ensordecer y abrir el menú (también botones del ratón).

## /help
- Nuevos temas `/help voz` y `/help altavoces`, que también pueden ver los jugadores.

# Coralosis 1.22.35

## Altavoces: fusión con la versión de Dani
Ahora están juntas las dos versiones del mod de altavoces: lo de Dani y lo nuestro (vídeos en carteles, pistas de Derivaland, avisos de copyright, chat de voz…).
- **Cable de altavoz**: une altavoces con un cable (clic en uno y luego en otro). Los conectados suenan lo mismo a la vez, más fuerte (hasta el doble) y más lejos. Se ve el cable colgando.
- **13 filtros de sonido**: Graves, Fiesta, Concierto, Catedral, Bajo el agua, Radio vieja, Teléfono, Megáfono, Lo-fi, Eco, Nightcore y Slowed. Más **ecualizador** y **sala**, en la pestaña Sonido.
- **Visualizador**: barras de colores encima del altavoz que bailan con la música, y notas que saltan con cada golpe de bajo.
- **Altavoz portátil**: llévalo en la mano, en la cabeza o en el inventario y los de tu alrededor oirán tu música. También tiene el botón ♫ Derivaland.
- Aleatorio, el altavoz brilla cuando suena, play/pausa con redstone y el comparador detecta si hay música.
- Recetas: **cable** (salen 4) = 1 lingote de cobre + 2 hilos + 1 redstone, sin forma. **Altavoz portátil** = hierro arriba; cuero, altavoz, cuero; cuero, cobre, cuero.

# Coralosis 1.22.34

- **Chat de voz por proximidad** propio. Pulsa **V** para abrir el menú: micrófono, salida (cascos o altavoces), volumen de las voces, volumen de tu micro, hablar por voz o pulsando una tecla, probar el micro, y el volumen de cada jugador.
- Se oye a la gente desde donde está, y más bajo cuanto más lejos (48 bloques por defecto).
- Teclas: **V** menú · **Bloq Mayús** hablar (si eliges «pulsando») · **N** silenciar el micro. Se cambian en Opciones → Controles → Chat de voz.
- Encima del nombre de cada uno sale un icono cuando habla, tiene el micro silenciado o está ensordecido.
- No hay que abrir puertos: la voz va por la misma conexión del juego.

# Coralosis 1.22.33

- Carteles: los vídeos se ven mucho más nítidos (hasta 720p; antes eran unos 180p). En Mods → Altavoces y Carteles → Configurar puedes cambiar `calidad_video` a baja, media, alta o maxima (1080p).
- Altavoces: el volumen ahora llega hasta el 200 %.

# Coralosis 1.22.31

- Altavoces: los vídeos de YouTube que daban «This video is not available» al ponerlos ahora se prueban de otras formas antes de rendirse.


- Altavoces y carteles: si YouTube no da un vídeo a la primera (contenido para niños, «no eres un robot»...), se prueba de otras formas. Si aun así no se puede, se dice el motivo (privado, bloqueado en tu país, restricción de edad...).


- Carteles: nueva opción «Por detrás»: tablero (se ve el dorso de madera, como un bloque) o la misma imagen (también se ve desde atrás, bien puesta).


- Al entrar ya no sale la pantalla de MCA para elegir entre ser aldeano o vanilla: todos entráis siempre como jugador vanilla.


## Altavoces y Carteles
- **Vídeos en los carteles:** pega un enlace de YouTube, Twitch, TikTok, un mp4... y el cartel lo reproduce en bucle, sin sonido.
- **Cartel enlazado a un altavoz:** si el altavoz pone un vídeo, el cartel lo enseña a la par con el sonido (pausar, saltar y cambiar de canción van juntos).
- **Pistas de Derivaland:** 8 canciones hechas para la serie, sin copyright (calma, el coral, misterio, tensión, pelea, fiesta, despedida y victoria). Botón «♫ Derivaland» del altavoz.
- **Aviso de copyright:** cada canción de la cola lleva un punto: 🔴 puede tener copyright, 🟢 libre, 🟡 no se sabe.
- La primera vez que veas un vídeo se descarga ffmpeg (una vez, unos 100 MB).


## Agua (más simple)
- Se quedan las cantimploras (cuero, cobre, hierro y coral), el molino, el filtro, la depuradora y el kit de reparación.
- Se puede beber del agua con shift + clic. Si el agua está contaminada, te pasa lo de siempre.
- Las botellas de cristal solo se llenan con agua limpia; para el resto, cantimplora.
- Fuera: garrafa, botella de agua contaminada, colector de lluvia, destilador solar, pozo, nasa y lámpara de medusa.

## Minijefes
- El Contramaestre, la Gran Morena y la Reina Medusa solo salen en la sala de antes del jefe y solo sueltan la Llave de coral (en creativo tienen huevo).
- Fuera los trofeos: caparazón, corona, colmillo, daga y báculo.

## Gólem de coral
- Nuevo aspecto: cuerpo de coral purificado, cabeza de coral cerebro, ramas de coral y un núcleo que brilla en el pecho.


- **Corazón del mar** ya se puede fabricar: 4 lapislázuli en las esquinas, 4 lingotes de oro en los lados y 1 diamante en el centro. Sale en la G.
- Los bloques del agua y del mar (molino, filtro, depuradora, colector, destilador, pozo, nasa y lámpara de medusa) tienen icono propio en el inventario; puestos en el mundo siguen igual.


## Skins nuevas
- Cantimploras, garrafa, kit de reparación y botella de agua contaminada.
- Las máquinas del agua, el colector, el destilador, el pozo, la nasa y la lámpara de medusa.
- Los huevos de todos los bichos del mar y de los minijefes.
- Los trofeos de los minijefes.

## Agua
- Para beber directamente del agua, de un caldero, de la lluvia o de un colector/pozo/destilador hay que estar **agachado (shift)** y hacer clic derecho con la mano vacía.


- La gema de la muerte se separa en sus 3 trozos, que salen volando y caen.
- En la G hay una fila vacía entre cada conjunto de recetas.
- Las piedras de teletransporte (registro y automática) ya salen en la G con su receta.


## Pantalla G
- Las recetas van ordenadas por filas: cada armadura en su fila con sus armas y herramientas, luego los arcos, los materiales, el agua, las máquinas y la comida.

## Muertes
- La gema de la muerte ahora se agrieta y se rompe en pedazos, con un sonido de pérdida.
- Si mueres durante un Evento Coral suena distinto: el coral se te traga.


## Avisos
- Cuando alguien popea un tótem (el normal o los de coral), sale en el chat de todos, en amarillo y negrita, quién ha sido y qué tótem.
- Cuando alguien muere, a todos les sale la gema roja con quién ha muerto y cómo. Si ha quedado eliminado, también lo dice.

## Mazmorras
- Las puertas de coral se abren bloque a bloque, empezando por donde metes la llave.


## Pantalla G
- Cada receta va en su cuadro de la rejilla, sin fondo oscuro.
- Nueva sección **Misiones del evento** en la pestaña Misiones: misiones que ponen los admins, algunas una por día, con su progreso y su recompensa.
- Algunas recetas pueden llegar bloqueadas por los admins: salen con candado hasta que se desbloqueen.

## Ayuda
- `/help` enseña la ayuda de Derivaland (los admins ven todos sus comandos por temas). `/help <comando>` de Minecraft sigue funcionando.


## La gema del coral (nuevo)
- Los admins sacan la gema con `/coralosis evento`: sale en el centro de la pantalla, va cambiando de color como una ruleta y se queda en uno. Cada color es un tipo de anuncio: blanca (información), tricolor (evento), violeta (cambio de dificultad), roja (sanción), turquesa (recompensa), coral (aparición).
- **Evento Coral**: la gema se agrieta y estalla. Tras una cuenta atrás llega una catástrofe: lluvia de coral, pinchos que brotan del suelo, oleadas de infectados, creepers, rayos, fantasmas... Cumple el objetivo que sale en pantalla o mueres al final.
- Puede haber **varios Eventos Coral a la vez**, cada uno con su objetivo: arriba de la pantalla salen todos con su tiempo y si lo estás cumpliendo (✔/✖).

## Emotes
- 20 emotes nuevos (38 en total).
- Ahora puedes elegir qué emotes van en tu rueda: pulsa B y luego R.

## Altavoces y Carteles
- **Altavoz**: música de YouTube, Spotify, SoundCloud o mp3 que oye todo el que esté cerca, a la vez, con sonido que se apaga con la distancia.
- **Cartel**: cualquier imagen o GIF de internet, de 1x1 a 16x16 bloques.
- Filtro +18: si una imagen o GIF parece contenido +18, el cartel se queda en blanco. Funciona en tu ordenador sin internet y no hay que configurar nada.

## Mazmorras y jefes
- Cada mazmorra tiene su minijefe antes del jefe y suelta la Llave de coral para abrir la batalla.
- La barra del jefe solo sale al abrir la puerta, y las arenas de jefe están llenas de nidos.
