# Coralosis 1.22.56

## Solo con fichas
- En el casino **ya solo se juega con fichas**: todas las máquinas, mesas y juegos cobran y pagan en fichas. Hay que pasar por la **máquina de cambio** (DerivaCoins → fichas) antes de jugar.
- Las **tragaperras de DerivaEconomía** también van con fichas cuando está el casino (tirada rápida, menú de jugar y premios por defecto).
- La barra de cócteles sigue cobrando en DerivaCoins.

## La casa siempre gana
- En el **panel de premios** (mayúsculas + clic derecho en una máquina, o `/casino premios`) hay un interruptor nuevo: **«La casa siempre gana»** con su **ventaja mínima** (en %).
- Activado (viene así, con un 1 %): ningún juego puede devolver de media más del 99 % de lo apostado. Si un admin pone premios demasiado generosos, se bajan solos lo justo, y avisa en el chat.
- Vale para todos los juegos del casino y para las tragaperras de DerivaEconomía (si sus premios en fichas dan de más, se bajan las probabilidades al tirar).
- Con un 1 % no cambia ningún premio de fábrica. Subidlo (por ejemplo a 5 %) si queréis que la casa gane más.

## Música nueva del casino
- Dos temas nuevos hechos para el casino, más tranquilos y con más ritmo: **«Casino»** (swing con saxo, vibráfono, bajo caminante y metales) y **«Azar»** (bossa lounge para la barra).
- El Gran Casino los pone en bucle al levantarlo. También salen en «Pistas de Derivaland» de cualquier altavoz.

## Volumen de la música para cada uno
- En el chat de voz, pestaña **Sonido**, hay un deslizador nuevo: **Música**. Baja (o sube hasta el 100 %) **solo para ti** la música y los vídeos de altavoces y carteles. Si el altavoz está al 100 % y lo pones al 50 %, tú lo oyes a la mitad y los demás igual que antes.

## Gran Casino
- **Escaleras nuevas:** escalera doble de mármol en el atrio, una a cada lado pegada a las columnas doradas, que sube hacia la entrada y llega al puente de la primera planta. Las del vestíbulo se quitaron.
- La cabeza del creeper ya no se cae: el verde que era arena ahora es lana.

## Ojo
- **Todos con el modpack 1.22.56** (cambian el casino, DerivaEconomía y DerivaMedia).
- Para ver el Gran Casino nuevo: `/casino2 destruir` y `/casino2 construir`.

# Coralosis 1.22.55

## Panel de premios para los admins
- **Mayúsculas + clic derecho** en cualquier máquina o mesa (siendo admin), o **`/casino premios`** junto a ella, abre su panel.
- Se puede cambiar **el premio y la probabilidad de cada cosa**: los números de la rueda, cada tortuga y cada caballo, los premios del rasca, del cofre y del empuja-monedas, los del pachinko por fuerza, la tabla del keno, los del póker, la ruleta, los dados…
- En minas, mayor o menor, crash, pociones y la torre se elige el **porcentaje que devuelven** de media.
- El panel calcula al momento **cuánto devuelve** cada apuesta. Hay un botón para volver a los premios **de fábrica**.
- Se guarda para todo el servidor.

## Casino Tower (juego nuevo)
- Torre de castillo de 4 bloques de alto con **8 pisos de puertas**. En cada piso eliges una puerta: tesoro y subes (el premio crece) o trampa y lo pierdes todo.
- **Cobra cuando quieras.** 4 niveles: fácil (4 puertas, 1 trampa), medio, difícil y experto (3 puertas, 2 trampas).
- En la máquina se ven las puertas abrirse: esmeralda las buenas y TNT las trampas.

## Máquina de cambio y fichas
- Bloque nuevo, la **máquina de cambio**: cambia DerivaCoins por **fichas del casino** y fichas por DerivaCoins, 1 a 1.
- Con fichas se juega en todo el casino. Si apuestas con fichas, cobras en fichas.

## Tragaperras
- En el casino solo quedan las tragaperras de **DerivaEconomía**, ahora **en 3D de verdad**: puerta con un arrecife pintado, bandeja cromada, consola con botones que brillan, marco cromado con cristal, tira de luces, letrero TRAGAPERRAS que se enciende al jugar, corales arriba y palanca.
- Las 7 tragaperras temáticas del casino siguen en el mod (por si acaso), pero ya no salen en la pestaña.

## Arreglos y mejoras de los juegos
- **Pachinko y plinko:** bolas pequeñas que caen botando de clavo en clavo. En el pachinko se ilumina el bolsillo donde entra y pone lo que paga.
- **Ruleta:** la bola es pequeña y acaba justo dentro de su casilla, también en la rueda de la pantalla.
- **Keno:** tus números se ven en el panel con marco dorado y, al acabar, los aciertos en verde y los que salieron en azul. En el tablero grande del fondo también salen tus números. Bolas pequeñas (y el bingo igual).
- **Crash:** si cobras, el cohete **sigue subiendo** hasta donde tenía que explotar en esa ronda. El botón de cobrar ya funciona con el ratón (antes solo con espacio).
- **Las explicaciones ya no se salen del recuadro verde.**
- **Cartas:** a mitad de partida, **Escape esconde el panel** para ver la mesa (las cartas, el cohete, la torre…). Otro Escape o un clic lo vuelve a sacar. Para salir, el botón «Hecho».
- Ya no sale «Nada esta vez» a mitad de partida (al repartir, en cada puerta…), solo al acabar.

## Barras y Gran Casino
- **Gran Casino (`/casino2`):**
  - Escaleras rehechas, con escalones bien puestos, muro y barandilla.
  - En vez del dino, una **cabeza de creeper gigante** encima de la gran barra del centro.
  - **Música en todo el casino** con los altavoces de DerivaMedia. El principal está en la **cabina del DJ** del escenario: ahí los admins pueden cambiar la música.
- **DerivaMedia 1.6.3:** los cables entre altavoces de más de 12 bloques ya no se dibujan (antes cruzaban todo el casino).

## Ojo
- **Todos con el modpack 1.22.55** (cambian el casino, DerivaEconomía y DerivaMedia).
- Para ver el Gran Casino nuevo hay que volver a levantarlo: `/casino2 destruir` y `/casino2 construir`.

# Coralosis 1.22.54

## Barras de cócteles nuevas
- **La barra de cócteles** ahora tiene frente de cuero capitoné granate con botones dorados, encimera de mármol negro con vetas de oro, columnitas doradas, luz bajo el canto y reposapiés de latón.
  - Encima lleva la carta en su atril, un frutero con limas, limones y cerezas, un vaso de pajitas y una campanita.
  - Por detrás, el camarero tiene su balda con vasos y un raíl de botellas.
- **Botellero nuevo**: fondo de espejo ahumado con celosía dorada, baldas de cristal con luz, columnas doradas y botellas de formas distintas (altas, cuadradas y redondas).
- **Bloque nuevo: tramo de barra.** Es igual que la barra pero sin servicio, para alargarla (en la pestaña Casino).
- Las barras que ya estaban puestas cambian solas de aspecto.

## El Gran Casino: `/casino2 construir`
Un casino nuevo entero, hecho para los juegos a tamaño real. El de `/casino construir` sigue como estaba.
- **Por fuera:** 73 bloques de ancho, dos torres art déco escalonadas con aguja, el letrero CASINO en la corona y DERIVALAND en neón, marquesina de entrada con bombillas y alfombra roja, y plaza con dos fuentes, palmeras y farolas.
- **Planta baja:**
  - Vestíbulo a doble altura con la fuente del dino y una gran lámpara.
  - **Bar del vestíbulo**, la caja y dos escaleras de mármol.
  - Atrio a doble altura con bóveda de cristal y oro, y en el centro **la gran barra cuadrada con 8 camareros** bajo una araña enorme.
  - Tragaperras (4 islas con marquesina), mesas de cartas y dados, carreras, craps, ruletas, recreativas y un **escenario** a doble altura con butacas.
- **Primera planta:** concursos (plinko, minas, crash, keno, bingo y 2 ruedas), **bar VIP** con 4 camareros, sala de altas apuestas, balcón sobre el escenario y lounge.
- Hay 46 juegos (algunos repetidos) y 34 tragaperras de siempre.
- **`/casino2 destruir`** lo quita y deja el terreno como estaba, aunque se haya reiniciado el servidor. Si se levantan varios, quita el último.

## Ojo
- **Todos con el modpack 1.22.54.**
- El Gran Casino es grande (unos 73 x 106 bloques y 48 de alto): conviene levantarlo en un sitio llano.

# Coralosis 1.22.53

## El casino, a tamaño real
Todos los juegos del casino están **hechos de nuevo como serían en la vida real**: ya no van metidos en una máquina tragaperras, y son lo bastante grandes como para que las cartas, las fichas y los dibujos se vean bien (antes se juntaban en algunas mesas de cartas).
- **Mesas de cartas en forma de media luna** con tapete de verdad, borde acolchado, bandeja de fichas y zapato: blackjack, Texas hold'em, baccarat (más larga), guerra, dragón y tigre, y mayor o menor (con un atril grande donde el crupier pone la carta).
- **Mesas de dados y de azar**: sic bo (con su campana de cristal), dados, craps (mesa enorme con paredes), cofres del tesoro y cara o cruz (con la moneda gigante en su soporte).
- **Ruleta de verdad**: el cilindro en una punta y el paño con los 37 números a lo largo.
- **Carreras** de caballos y de tortugas en pistas largas con sus calles, salida y meta.
- **La rueda de la fortuna** gigante, de 4 bloques de alto, con su mesa de apuestas.
- **Tableros de concurso de pie**: plinko con clavos dorados, minas con casillas iluminadas y crash con pantalla de cielo estrellado y la rampa del cohete.
- **Keno y bingo**: puesto con mostrador, el tablero de números al fondo y el crupier en medio (el bingo con su bombo de alambre).
- **Recreativas de verdad**: máquina de gancho con urna de cristal, empuja monedas, machaca topos, pachinko japonés, la torre, rasca y gana (quiosco), lotería (bombo de cristal) y pociones (mesa de alquimista con armario de botellas y caldero).
- **Las 7 tragaperras y el vídeo póker**, ahora de 2 bloques de alto con mueble, puerta pintada, rodillos tras el cristal, botones que brillan, palanca y letrero luminoso que se enciende al jugar.
- Cada juego ocupa lo que necesita (de 1x1x2 a 5x3) y el crupier se pone en su sitio, detrás o al lado.

## Casino nuevo con `/casino construir`
- **Distribución rehecha** para los juegos nuevos:
  - Planta baja: las mesas de cartas y dados en filas a un lado, y al otro la isla de tragaperras, las tragaperras de siempre y las recreativas contra la pared.
  - Primera planta: ruleta, craps, caballos y tortugas, y detrás la rueda, keno, bingo, plinko, minas y crash.
- Hay **2 mesas más** de blackjack y Texas hold'em.

## Ojo
- **Todos con el modpack 1.22.53.**
- Los juegos ya colocados del casino viejo **hay que quitarlos y volver a ponerlos** (ahora ocupan más). Lo más fácil: volver a levantar el casino con `/casino construir`.

# Coralosis 1.22.52

## El casino cobra vida: crupieres, camareros y cócteles
- **Crupieres en 3D** detrás de las 12 mesas (blackjack, ruleta, dados, baccarat, Texas, sic bo, guerra, dragón y tigre, craps, caballos, tortugas y cofres). Son **6 distintos**, con chaleco, pajarita y ligas en las mangas, y se mueven de verdad:
  - Reparten las cartas desde el zapato y les dan la vuelta.
  - Agitan los dados en la mano y los tiran.
  - Giran la ruleta, lanzan la bola, levantan la mano en el «no va más» y señalan el número.
  - Dan la salida de las carreras con una bandera a cuadros.
  - Presentan los cofres y señalan el que eliges.
  - **Aplauden** cuando ganas (y saltan con los brazos arriba si es un premio gordo) o se encogen de hombros si pierdes.
  - Te saludan con la mano cuando te acercas. Entre partida y partida miran alrededor, se colocan la pajarita y ordenan fichas.
- **Barra de cócteles** con **camarero en 3D** (hay 2 distintos): eliges un cóctel en la carta y lo prepara delante de ti.
  - Se da la vuelta, coge las botellas del botellero y las sirve en la coctelera.
  - Echa hielo, agita la coctelera, sirve en el vaso, le pone el adorno y te lo desliza por la barra.
  - Todo con sonidos y salpicaduras.
- **10 cócteles**, cada uno con su vaso, su color, su adorno y un efecto al beberlo:
  - Mojito (velocidad), Piña colada (regeneración), Margarita (prisa minera), Blue Lagoon (respirar bajo el agua y gracia del delfín), Tequila Sunrise (resistencia al fuego).
  - Cosmopolitan (suerte), Daiquiri de fresa (absorción), Coral Deriva (el especial de la casa: poder del mar), Dino Verde (el cóctel de DinoFino: supersalto), Noche Dorada (visión nocturna).
  - Cuestan 5–8 DerivaCoins (gratis en creativo).
- El edificio del casino trae ahora **2 barras**: una en el vestíbulo y otra arriba, con botelleros llenos de botellas.
- Bloques nuevos en la pestaña Casino: **barra de cócteles** y **botellero**.

## Animaciones mejoradas en todos los juegos
- Al ganar, **saltan monedas** del juego y caen al suelo, hay fuegos artificiales y suena una fanfarria. Con un premio de x10 o más sale **¡¡GRAN PREMIO!!** con tótem y cohetes.
- Las cartas vuelan en arco girando y suenan al caer; los dados suenan al botar y las fichas al apilarse.
- Los rodillos de las tragaperras hacen tic-tac al girar y un golpe al pararse. La bola de la ruleta suena mientras corre y va frenando.

## Arreglado
- Las cartas, los símbolos, los cofres y demás piezas de las animaciones se veían **girados del revés** (Minecraft gira 180° esos objetos al dibujarlos). Ahora salen como deben.
- Los caballos y las tortugas seguían corriendo de espaldas en la 1.22.51. Ya corren hacia la meta.

## Ojo
- **Todos con el modpack 1.22.52.**
- Para ver las barras nuevas hay que volver a levantar el casino con `/casino construir`. En las mesas de antes, el crupier aparece la primera vez que alguien las usa (si hay sitio detrás).

# Coralosis 1.22.51

## El casino, reimaginado de arriba abajo
- **Edificio nuevo entero** con `/casino construir`, estilo art déco de Las Vegas: **41 de ancho, 2 plantas y una plaza delante**.
- **Fachada**: piedra color crema con paneles art déco de sol naciente, columnas doradas con neón, cornisas doradas, vidrieras de colores y una gran banda negra con **DERIVALAND** en neón azul.
- **Cartel CASINO gigante** sobre el tejado (letras de 7 de alto en neón dorado), con marco de bombillas, soportes, una corona escalonada y focos apuntando al cielo.
- **Pórtico** con 4 columnas y marquesina de bombillas sobre la entrada, y **plaza** de mármol con alfombra roja, farolas, dos fuentes iluminadas, palmeras y setos.
- **Planta baja**:
  - Vestíbulo de mármol a doble altura.
  - **4 islas de tragaperras** con marquesinas de luces y neón.
  - **2 fosos de mesas** con cordón dorado y lámparas de araña.
  - **Rotonda** con 8 columnas, fuente y la **estatua del dino** subiendo hasta la **cúpula de cristal dorado**.
  - La caja con el letrero **JACKPOT**.
  - Techo artesonado con plafones de luz.
- **Primera planta**:
  - Balcón sobre el vestíbulo.
  - Pasarela de mármol hasta la rotonda.
  - Ruleta, craps, caballos y tortugas sobre moqueta de estrellas.
  - **BAR**, zona **VIP** con sofás y tragaperras.
  - Escenario **SHOW** con telón de terciopelo.
  - Palmeras en maceta.
  - Techo artesonado y lámparas de araña.
- **8 bloques de decoración nuevos** (pestaña Casino): piedra crema, fachada art déco, cornisa dorada, techo artesonado, vidriera dorada, moqueta de estrellas, papel pintado art déco y plafón de luz.

## Arreglado
- En la carrera de caballos y la de tortugas los animales iban de espaldas.

## Ojo
- **Todos con el modpack 1.22.51, también el servidor.**
- `/casino construir` ahora ocupa **41 de ancho, desde 1 bloque delante del admin hasta 61 hacia dentro y 35 de alto**: **borra lo que haya** (y rellena huecos debajo). `/casino deshacer` lo quita.

# Coralosis 1.22.50

## El casino, mucho más completo por dentro y por fuera
- **Plaza de entrada**: suelo de mármol, alfombra roja con barandillas doradas hasta la calle, dos fuentes iluminadas, palmeras, farolas doradas y jardín.
- **Fachada**: ventanas iluminadas con marco de neón, remate dorado con bombillas encima del cartel CASINO, focos apuntando al cielo y tiras de neón en los laterales.
- **Planta baja**: columnas doradas con anillo de neón alrededor del atrio, fuente en el centro, **estatua gigante del dino de DinoFino** al fondo del atrio, sofás y mesitas en la entrada, plantas y luces entre las máquinas y el letrero **JACKPOT** en neón sobre la caja.
- **Primera planta**: pared del bar con el letrero **BAR** y farolillos, letrero **VIP** y cordón dorado en la zona VIP, **escenario** con tocadiscos, focos y telón de bombillas, taburetes mirando al atrio y mesitas con lámparas.

## Ojo
- **Todos con el modpack 1.22.50, también el servidor.**
- `/casino construir` ocupa ahora también 14 bloques por delante (la plaza): **borra lo que haya**. `/casino deshacer` lo quita.

# Coralosis 1.22.49

## Casino de verdad: 2 plantas y luces por todas partes
- **Edificio nuevo** con `/casino construir`: casino de **2 plantas** (35 x 41).
  - **Fachada** con el gran cartel **CASINO** en neón dorado rodeado de bombillas, marquesina con luces, columnas doradas y alfombra roja en la entrada.
  - **Planta baja**: las 24 máquinas en las paredes, 8 mesas, lámparas de araña, pasillo de mármol y la caja al fondo.
  - **Atrio a doble altura** en el centro con barandilla dorada, claraboya y grandes lámparas de araña.
  - **Escaleras** a los dos lados del fondo hasta la **primera planta**: ruleta, craps, caballos, carrera de tortugas, **bar** con taburetes y **zona VIP** con tragaperras.
- **16 bloques de decoración nuevos** con texturas propias (pestaña Casino del creativo): moqueta de casino y moqueta real, mármol blanco y negro, pared de terciopelo, panel dorado, columna dorada, neones rojo, dorado, azul y rosa, bombillas que parpadean, lámpara de araña, barandilla dorada, taburete y barra de bar.

## Arreglado
- El vídeo póker, mayor o menor, bingo y rasca y gana salían con partes sin textura (morado y negro).

## Ojo
- **Todos con el modpack 1.22.49, también el servidor.**
- `/casino construir` ocupa 35 x 41 y 17 de alto (y 4 bloques por delante para la entrada): **borra lo que haya**. `/casino deshacer` lo quita.

# Coralosis 1.22.48

## Casino 3.0: 36 juegos, a tamaño de jugador y en 3D
- **Máquinas de 2 bloques de alto** (como un jugador) con vitrina de cristal y letrero luminoso, y **mesas de 2 x 1 y 2 x 2** con su tapete.
- **Animaciones en 3D en el mundo** que ve todo el que esté cerca: cartas que se reparten y se dan la vuelta, dados que ruedan, rodillos girando, la bola de la ruleta, el gancho, caballos y tortugas corriendo, el cohete del crash, la torre…
- **27 juegos nuevos:**
  - **Tragaperras:** Derivaland, Coral, Frutas, Dino, Pirata, Cangrejos y Kraken (cada una con sus símbolos y premios).
  - **Cartas y dados:** baccarat, Texas contra la banca, sic bo, mayor o menor, guerra de cartas, dragón y tigre y craps.
  - **Números:** keno y bingo.
  - **Arcade:** gancho de peluches (¡si lo pillas, el peluche es tuyo!), empuja-monedas, machaca topos, pachinko, torre de bloques y carrera de caballos.
  - **Rápidos:** rasca y gana, crash (cobra antes de que explote el cohete), cofre del tesoro, ruleta de pociones y **lotería diaria** (sorteo todos los días a las 21:00).
- Las pantallas de juego van en un panel abajo para que se vea la máquina mientras juegas.
- **Edificio nuevo:** `/casino construir` levanta un casino de 35 x 41 con los 36 juegos dentro.
- Las mesas de 1 bloque de antes siguen ahí, pero conviene quitarlas y ponerlas de nuevo.

## Ojo
- **Todos con el modpack 1.22.48, también el servidor** (cambia el casino).

# Coralosis 1.22.47

## Casino en 3D
- **Todas las mesas y máquinas del casino tienen modelo 3D nuevo**, ya no son cubos ni una tabla con un palo:
  - **Mesas** (blackjack, ruleta, dados y carrera de tortugas): patas de madera con pies de latón, baranda acolchada de cuero rojo y paño de juego.
  - **Blackjack:** bandeja de fichas del crupier, zapato de cartas y fichas apostadas.
  - **Ruleta:** la rueda de verdad, hundida en su cuenco de madera, con la cruceta de latón. Al jugar gira con la bola.
  - **Dados:** paredes altas de rebote y dos dados encima del paño.
  - **Carrera de tortugas:** calles separadas, las cinco tortugas en la salida y la meta con bandera de cuadros.
  - **Vídeo póker y Minas:** máquinas de pie con pantalla, botonera de colores, puerta de monedas y letrero luminoso arriba.
  - **Plinko:** tablero vertical con clavos de verdad, cubos de premio y letrero.
  - **Rueda de la fortuna:** rueda grande de pie con flecha y bombillas. Al jugar gira y las bombillas parpadean.
  - **Cara o cruz:** vitrina de cristal con una moneda gigante dentro, que da vueltas al jugar.
- Cuando se juega, los letreros hacen correr las bombillas y las pantallas se animan como antes.

## Altavoces: arreglado el sonido «a cámara lenta»
- Las canciones a 44,1 kHz (muchos MP3, M4A, enlaces directos, SoundCloud…) sonaban el doble de lentas y una octava más graves. Ya suenan normal.

## Flechas nuevas
- **Flechas de materiales:** se hacen como la flecha normal (material arriba, palo y pluma) y salen 4. Cuanto mejor el material, más pegan:

  | Flecha | Daño con arco normal | Se hace con | Extra |
  |---|---|---|---|
  | Normal | 6 | sílex | |
  | Cobre | 7 | lingote de cobre | |
  | Hierro | 8 | lingote de hierro | |
  | Oro | 8 | lingote de oro | Sale más rápida y llega más lejos |
  | Diamante | 9 | diamante | |
  | Percebes | 9 | lingote de percebes | Casi no se frena bajo el agua (tras el Capitán) |
  | Netherita | 11 | 8 flechas de diamante + 1 fragmento de netherita (salen 8) | No se quema (tras el Capitán) |
  | Coral purificado | 12 | lingote de coral purificado | Deja un rastro brillante (tras el Kraken) |

- **Flecha de ender:** flecha + perla de ender. Donde se clave, allí apareces, como si tirases una perla pero con la puntería del arco. Quita 1 corazón al llegar.
- Valen para arcos, ballestas y dispensadores. Los arcos de Coralosis multiplican el daño de la flecha que dispares: un arco de diamante con flechas de diamante pega bastante más.


## Cangrejos ermitaños: personajes de rol para los admins
Como las nutrias del Dedsafío: unos personajes con los que los admins pueden hablar con los jugadores, dar misiones, llevar concursos...

- **13 cangrejos**, cada uno con un sombrero o un adorno de una cultura, sus colores y su forma de ser:
  - **Ermi:** el ermitaño cotilla de la playa.
  - **Capitán Pinzanegra:** pirata.
  - **Pancho Pinzas:** mariachi de México.
  - **Juancho Arena:** comerciante de la costa de Colombia.
  - **Lola Concha:** bailaora de Andalucía.
  - **Inti:** guía de los Andes.
  - **Don Mateo:** gaucho con su mate.
  - **Kenji Kani:** viajero de Japón.
  - **Angus McPinza:** de Escocia.
  - **Sasha:** pescador del norte helado.
  - **Ramsés Pinzatón:** faraón de Egipto.
  - **Kai:** surfista de Hawái.
  - **Bjørn Caparazón:** vikingo.
- Cada uno lleva a la espalda una casa: **caracola, cubo o cofre**.
- **Los admins se convierten en ellos** con `/disfraz cangrejo <personaje>`.
  - Todos ven el cangrejo y su nombre, también en el chat.
  - Al disfrazarte te sale su ficha: cómo es, qué papel tiene y frases para usar.
  - Al hacer clic, el cangrejo levanta la pinza grande.
  - `/disfraz quitar` para volver. `/disfraz lista` para verlos todos. Más en `/help disfraz`.
- **También hay cangrejos NPC** (huevo en creativo):
  - Hablan solos de vez en cuando y te saludan con una de sus frases si les haces clic.
  - No atacan, no desaparecen y solo los pueden herir los admins en creativo.


## Tumbas: ya no te quedas con las cosas al morir
- Si el servidor tiene la regla **keepInventory** activada, Minecraft no suelta nada al morir y por eso no salía tumba y te quedabas con el inventario (pasaba igual en el suelo que saltando). Ahora las cosas **van igualmente a la tumba**, también si mueres en el aire: la tumba se queda flotando donde has muerto.
- Si algún día queréis que con keepInventory cada uno conserve sus cosas: `/tumbas keepinventory conservar` (y `/tumbas keepinventory tumba` para volver). `/tumbas estado` dice cómo está.

## Minimapa: calavera, cruces y distancias
- La muerte **más reciente** sale con una **calavera** (en el minimapa, en el mapa grande y en la lista de muertes). Las muertes pasadas, con una **cruz**.
- Encima de cada rayo de muerte sale un letrero con los **bloques de distancia** (se ve a través de las paredes y se lee igual de cerca que de lejos).
- Los **waypoints** también tienen ahora un rayo fino de su color con su nombre y la distancia.
- Si hay varias muertes en el mismo sitio, los letreros se ponen uno encima de otro en vez de pisarse.

## Ojo
- **Todos con el modpack 1.22.47, también el servidor** (cambian Coralosis, el minimapa, las tumbas y el casino).

# Coralosis 1.22.45

## Casino 2.0: todo con DerivaCoins
- **Todo el casino funciona ahora con DerivaCoins.** Las fichas de ayer se canjean 1 a 1 con el botón «Canjear fichas» de cualquier juego.
- **Juegos nuevos** (pestaña Casino del creativo, o crafteándolos): **Ruleta** (hasta toda la mesa a la vez), **Mesa de dados**, **Rueda de la fortuna**, **Carrera de tortugas**, **Plinko**, **Minas**, **Vídeo póker** y **Cara o cruz**.
- **Blackjack mejorado:** las cartas se reparten deslizándose desde el zapato, botón de **Rendirse** (recuperas la mitad) y luces en la mesa.
- **Animaciones por dentro y por fuera:** cada juego tiene su animación en pantalla (la bola de la ruleta, los dados botando, la rueda frenando, las tortugas corriendo, la bola del plinko…) y la mesa o máquina se enciende y se mueve en el mundo mientras se juega, con sonidos y partículas al ganar.
- **Tragaperras:** los rodillos rebotan al parar y, si toca premio, el marco parpadea y llueve el objeto ganado.
- **Edificio del casino:** un admin lo levanta con `/casino construir` (delante de donde mira), con todos los juegos y tragaperras dentro. `/casino deshacer` lo quita y deja el terreno como estaba.
- Admins: `/casino monedas dar <jugador> <cantidad>` y `/casino monedas quitar …`. En creativo los juegos de máquina van en modo prueba (gratis y sin premio).
- Ajustes del servidor en `config/derivacasino-common.toml`: apuesta mínima y máxima (1 a 50 de serie) y desde qué premio se anuncia a los de alrededor.

## Ojo
- **Todos con el modpack 1.22.45, también el servidor.**

# Coralosis 1.22.44

## Casino: mesa de blackjack
- Nuevo mod **Casino Derivaland**: una **Mesa de blackjack** (en la pestaña Casino del modo creativo, o crafteando lana verde, tablas y una esmeralda).
- Clic derecho en la mesa para mirar, **Sentarse** para jugar. Solo contra la banca, o **hasta 4 en la misma mesa**, por turnos.
- Se apuesta con **Fichas de casino**: en la misma mesa se cambian esmeraldas por fichas y al revés (1 esmeralda = 10 fichas; con Mayús, de 10 en 10).
- Botones: **Pedir**, **Plantarse** y **Doblar**. La banca se planta con 17 y el blackjack paga 3 a 2.
- Admins: `/fichas dar <jugador> <cantidad>` y `/fichas quitar …`. Cualquiera puede ver sus fichas con `/fichas`.
- Ajustes del servidor en `config/derivacasino-common.toml`: fichas por esmeralda, apuesta mínima y máxima, mazos, segundos por turno y si se puede cambiar en la mesa.

## Ojo
- **Todos con el modpack 1.22.44, también el servidor.** Sin el mod del casino no deja entrar.

# Coralosis 1.22.43

## El filtro +18 lo decide el admin del servidor
- El filtro +18 de los carteles (imágenes y vídeos porno, y vídeos que la web marca como +18) ahora se puede **encender o apagar desde el servidor**, para todos a la vez.
- Comandos (solo admins): `/filtro18 activar` y `/filtro18 desactivar`. Cualquiera puede ver cómo está con `/filtro18`.
- También en `config/derivamedia-common.toml`: `filtro_18 = true` o `false`. Viene **encendido** de serie.
- Al apagarlo, lo que estaba bloqueado se vuelve a cargar solo, sin tener que tocar los carteles.

## Copyright: quitado del todo
- El altavoz ya no mira si una canción puede tener copyright, y se han quitado los textos que quedaban.

## Ojo
- **Todos con el modpack 1.22.43, también el servidor** (Altavoces, Carteles y Voz 1.6.1). Con la 1.22.42 no deja entrar.

# (1.22.42)

## Fusión: lo de Dani (1.22.37 a 1.22.41) + lo nuestro (1.22.36)
Ahora está todo junto en el mod de Altavoces, Carteles y Voz 1.6.0. Abajo está lo que trae cada parte.

# (1.22.41)

## Arreglado: el sonido iba por delante del vídeo
- El cartel seguía el reloj del servidor, que va a tirones cuando el juego va justo, mientras que el sonido sigue a su ritmo. Por eso el sonido se adelantaba. Ahora el cartel sigue **lo que se oye de verdad en el altavoz**, así que imagen y sonido van juntos aunque el juego vaya lento.
- Si el ordenador no da para descodificar el vídeo a tiempo y se queda atrás, se vuelve a poner en su sitio en vez de ir arrastrando el retraso.
- El vídeo de los carteles gasta un poco menos de ordenador.

## Quitado: avisos de copyright
- Ya no salen los puntos de colores, la leyenda ni los avisos de «puede tener copyright».

# (1.22.40)

## Vídeo y sonido de los altavoces: ahora se descargan
- **Una sola consulta a YouTube.** Antes el altavoz pedía el sonido y el cartel pedía la imagen por separado, y YouTube a veces daba uno y no el otro, o cortaba a mitad. Ahora se pregunta una vez y de ahí salen las dos cosas.
- **El sonido se descarga entero antes de sonar** (tarda unos segundos; una canción, casi nada). Ya no se corta a mitad ni se queda pillado.
- **La imagen se descarga mientras tanto.** Mientras baja, el cartel la enseña desde internet como antes; cuando ya está entera (un vídeo de 24 minutos tarda unos 20 segundos), el cartel se pasa solo al archivo: sin cortes, sin retraso y saltando a cualquier minuto al instante.
- Lo descargado se guarda en `.minecraft/derivamedia/videos` y se borra solo (lo que lleva un día sin usarse, o lo más viejo si pasa de 3 GB). Los directos y los vídeos de más de 3 horas se siguen viendo por internet.
- Si la descarga falla, se usa el sistema de antes, así que nunca va peor que en la 1.22.39.

# (1.22.39)

## Vídeos de los carteles mucho mejor
- **Ya no se bloquean vídeos normales.** El filtro +18 confundía caras de cerca y escenas oscuras con desnudos y paraba vídeos de YouTube que no tenían nada. Ahora, en YouTube, Twitch, TikTok, Vimeo, Dailymotion, Kick e Instagram (que no permiten porno) se usa su propia marca de "mayores de 18". El filtro de imágenes queda solo para vídeos sueltos y de X/Twitter, y tiene que saltar 3 veces seguidas.
- **Más fluidos:** 30 imágenes por segundo (antes 20).
- **Más ligeros:** la resolución se ajusta al tamaño del cartel, así que el ordenador trabaja mucho menos.

# (1.22.38)

## Arreglado: el vídeo de los carteles iba con mucho retraso
- Si el vídeo tardaba más de 2,5 segundos en arrancar (lo normal con YouTube), el juego creía que iba desfasado y lo volvía a arrancar una y otra vez, así que nunca alcanzaba al sonido. Ahora se adelanta lo que tarda en arrancar y sale sincronizado con el altavoz.
- Si YouTube da un enlace que no deja ver (error 403), se pide por otra vía en vez de insistir con el mismo.
- Los vídeos de los carteles en bucle ya no fallan cuando el cartel lleva puesto más rato de lo que dura el vídeo.

# (1.22.37)

## Arreglado: los vídeos de los carteles solo los veía una persona
- Cada jugador necesita en su ordenador las herramientas para ver vídeos (yt-dlp y ffmpeg), y el juego solo sabía descargarlas de GitHub. Cuando GitHub fallaba, a quien no las tenía ya no le salía el vídeo.
- Ahora, si GitHub no responde, las baja de otras webs oficiales o de una copia guardada en el GitHub de Derivaland. Así todos ven el vídeo.

# (1.22.36)

## Vídeos en los carteles: arreglados
- **Ya no tardan una eternidad ni se quedan sin salir.** Con YouTube (que tarda unos segundos en dar el vídeo) el cartel se reiniciaba una y otra vez y no llegaba a enseñar nada. Ahora sale en unos segundos y va a la par con el sonido.
- **Ya lo ve todo el mundo, no solo quien lo pone.** Quien llegaba más tarde de lo que dura el vídeo se quedaba con el cartel vacío.
- Mientras carga, **el propio cartel dice qué está haciendo** (descargando el reproductor la primera vez, buscando el vídeo, abriéndolo...) o por qué falla. Si falla, lo vuelve a intentar solo.
- El reproductor (ffmpeg, yt-dlp y deno) se descarga al abrir el juego, no al ver el primer vídeo.

## Cable entre cartel y altavoz
- Con el **cable**: clic en el cartel y luego en el altavoz (o al revés). El altavoz pone el **sonido** y el cartel la **imagen** del vídeo, a la par. Si el cartel ya tenía un vídeo, se pone solo en el altavoz.
- Se ve el cable del altavoz al cartel. Agachado + clic en el cartel lo desenlaza.

## Chat de voz: menú por apartados
- **Micrófono**: cuál usar, cuánto se sube, hablar por voz o pulsando, umbral con la barra, probar el micro.
- **Sonido**: salida (cascos o altavoces), volumen de las voces, ensordecer y **volumen de cada jugador**.
- **Teclas**: cambia aquí mismo la de hablar, silenciar, ensordecer y abrir el menú (también botones del ratón).

## /help
- Nuevos temas `/help voz` y `/help altavoces`, que también pueden ver los jugadores.

# Coralosis 1.22.35

## Altavoces: fusión con la versión de Dani
Ahora están juntas las dos versiones del mod de altavoces: lo de Dani y lo nuestro (vídeos en carteles, pistas de Derivaland, avisos de copyright, chat de voz…).
- **Cable de altavoz**: une altavoces con un cable (clic en uno y luego en otro). Los conectados suenan lo mismo a la vez, más fuerte (hasta el doble) y más lejos. Se ve el cable colgando.
- **13 filtros de sonido**: Graves, Fiesta, Concierto, Catedral, Bajo el agua, Radio vieja, Teléfono, Megáfono, Lo-fi, Eco, Nightcore y Slowed. Más **ecualizador** y **sala**, en la pestaña Sonido.
- **Visualizador**: barras de colores encima del altavoz que bailan con la música, y notas que saltan con cada golpe de bajo.
- **Altavoz portátil**: llévalo en la mano, en la cabeza o en el inventario y los de tu alrededor oirán tu música. También tiene el botón ♫ Derivaland.
- Aleatorio, el altavoz brilla cuando suena, play/pausa con redstone y el comparador detecta si hay música.
- Recetas: **cable** (salen 4) = 1 lingote de cobre + 2 hilos + 1 redstone, sin forma. **Altavoz portátil** = hierro arriba; cuero, altavoz, cuero; cuero, cobre, cuero.

# Coralosis 1.22.34

- **Chat de voz por proximidad** propio. Pulsa **V** para abrir el menú: micrófono, salida (cascos o altavoces), volumen de las voces, volumen de tu micro, hablar por voz o pulsando una tecla, probar el micro, y el volumen de cada jugador.
- Se oye a la gente desde donde está, y más bajo cuanto más lejos (48 bloques por defecto).
- Teclas: **V** menú · **Bloq Mayús** hablar (si eliges «pulsando») · **N** silenciar el micro. Se cambian en Opciones → Controles → Chat de voz.
- Encima del nombre de cada uno sale un icono cuando habla, tiene el micro silenciado o está ensordecido.
- No hay que abrir puertos: la voz va por la misma conexión del juego.

# Coralosis 1.22.33

- Carteles: los vídeos se ven mucho más nítidos (hasta 720p; antes eran unos 180p). En Mods → Altavoces y Carteles → Configurar puedes cambiar `calidad_video` a baja, media, alta o maxima (1080p).
- Altavoces: el volumen ahora llega hasta el 200 %.

# Coralosis 1.22.31

- Altavoces: los vídeos de YouTube que daban «This video is not available» al ponerlos ahora se prueban de otras formas antes de rendirse.


- Altavoces y carteles: si YouTube no da un vídeo a la primera (contenido para niños, «no eres un robot»...), se prueba de otras formas. Si aun así no se puede, se dice el motivo (privado, bloqueado en tu país, restricción de edad...).


- Carteles: nueva opción «Por detrás»: tablero (se ve el dorso de madera, como un bloque) o la misma imagen (también se ve desde atrás, bien puesta).


- Al entrar ya no sale la pantalla de MCA para elegir entre ser aldeano o vanilla: todos entráis siempre como jugador vanilla.


## Altavoces y Carteles
- **Vídeos en los carteles:** pega un enlace de YouTube, Twitch, TikTok, un mp4... y el cartel lo reproduce en bucle, sin sonido.
- **Cartel enlazado a un altavoz:** si el altavoz pone un vídeo, el cartel lo enseña a la par con el sonido (pausar, saltar y cambiar de canción van juntos).
- **Pistas de Derivaland:** 8 canciones hechas para la serie, sin copyright (calma, el coral, misterio, tensión, pelea, fiesta, despedida y victoria). Botón «♫ Derivaland» del altavoz.
- **Aviso de copyright:** cada canción de la cola lleva un punto: 🔴 puede tener copyright, 🟢 libre, 🟡 no se sabe.
- La primera vez que veas un vídeo se descarga ffmpeg (una vez, unos 100 MB).


## Agua (más simple)
- Se quedan las cantimploras (cuero, cobre, hierro y coral), el molino, el filtro, la depuradora y el kit de reparación.
- Se puede beber del agua con shift + clic. Si el agua está contaminada, te pasa lo de siempre.
- Las botellas de cristal solo se llenan con agua limpia; para el resto, cantimplora.
- Fuera: garrafa, botella de agua contaminada, colector de lluvia, destilador solar, pozo, nasa y lámpara de medusa.

## Minijefes
- El Contramaestre, la Gran Morena y la Reina Medusa solo salen en la sala de antes del jefe y solo sueltan la Llave de coral (en creativo tienen huevo).
- Fuera los trofeos: caparazón, corona, colmillo, daga y báculo.

## Gólem de coral
- Nuevo aspecto: cuerpo de coral purificado, cabeza de coral cerebro, ramas de coral y un núcleo que brilla en el pecho.


- **Corazón del mar** ya se puede fabricar: 4 lapislázuli en las esquinas, 4 lingotes de oro en los lados y 1 diamante en el centro. Sale en la G.
- Los bloques del agua y del mar (molino, filtro, depuradora, colector, destilador, pozo, nasa y lámpara de medusa) tienen icono propio en el inventario; puestos en el mundo siguen igual.


## Skins nuevas
- Cantimploras, garrafa, kit de reparación y botella de agua contaminada.
- Las máquinas del agua, el colector, el destilador, el pozo, la nasa y la lámpara de medusa.
- Los huevos de todos los bichos del mar y de los minijefes.
- Los trofeos de los minijefes.

## Agua
- Para beber directamente del agua, de un caldero, de la lluvia o de un colector/pozo/destilador hay que estar **agachado (shift)** y hacer clic derecho con la mano vacía.


- La gema de la muerte se separa en sus 3 trozos, que salen volando y caen.
- En la G hay una fila vacía entre cada conjunto de recetas.
- Las piedras de teletransporte (registro y automática) ya salen en la G con su receta.


## Pantalla G
- Las recetas van ordenadas por filas: cada armadura en su fila con sus armas y herramientas, luego los arcos, los materiales, el agua, las máquinas y la comida.

## Muertes
- La gema de la muerte ahora se agrieta y se rompe en pedazos, con un sonido de pérdida.
- Si mueres durante un Evento Coral suena distinto: el coral se te traga.


## Avisos
- Cuando alguien popea un tótem (el normal o los de coral), sale en el chat de todos, en amarillo y negrita, quién ha sido y qué tótem.
- Cuando alguien muere, a todos les sale la gema roja con quién ha muerto y cómo. Si ha quedado eliminado, también lo dice.

## Mazmorras
- Las puertas de coral se abren bloque a bloque, empezando por donde metes la llave.


## Pantalla G
- Cada receta va en su cuadro de la rejilla, sin fondo oscuro.
- Nueva sección **Misiones del evento** en la pestaña Misiones: misiones que ponen los admins, algunas una por día, con su progreso y su recompensa.
- Algunas recetas pueden llegar bloqueadas por los admins: salen con candado hasta que se desbloqueen.

## Ayuda
- `/help` enseña la ayuda de Derivaland (los admins ven todos sus comandos por temas). `/help <comando>` de Minecraft sigue funcionando.


## La gema del coral (nuevo)
- Los admins sacan la gema con `/coralosis evento`: sale en el centro de la pantalla, va cambiando de color como una ruleta y se queda en uno. Cada color es un tipo de anuncio: blanca (información), tricolor (evento), violeta (cambio de dificultad), roja (sanción), turquesa (recompensa), coral (aparición).
- **Evento Coral**: la gema se agrieta y estalla. Tras una cuenta atrás llega una catástrofe: lluvia de coral, pinchos que brotan del suelo, oleadas de infectados, creepers, rayos, fantasmas... Cumple el objetivo que sale en pantalla o mueres al final.
- Puede haber **varios Eventos Coral a la vez**, cada uno con su objetivo: arriba de la pantalla salen todos con su tiempo y si lo estás cumpliendo (✔/✖).

## Emotes
- 20 emotes nuevos (38 en total).
- Ahora puedes elegir qué emotes van en tu rueda: pulsa B y luego R.

## Altavoces y Carteles
- **Altavoz**: música de YouTube, Spotify, SoundCloud o mp3 que oye todo el que esté cerca, a la vez, con sonido que se apaga con la distancia.
- **Cartel**: cualquier imagen o GIF de internet, de 1x1 a 16x16 bloques.
- Filtro +18: si una imagen o GIF parece contenido +18, el cartel se queda en blanco. Funciona en tu ordenador sin internet y no hay que configurar nada.

## Mazmorras y jefes
- Cada mazmorra tiene su minijefe antes del jefe y suelta la Llave de coral para abrir la batalla.
- La barra del jefe solo sale al abrir la puerta, y las arenas de jefe están llenas de nidos.
