# Coralosis 1.22.18

## La gema del coral (nuevo)
- Los admins sacan la gema con `/coralosis evento`: sale en el centro de la pantalla, va cambiando de color como una ruleta y se queda en uno. Cada color es un tipo de anuncio: blanca (información), tricolor (evento), violeta (cambio de dificultad), roja (sanción), turquesa (recompensa), coral (aparición).
- **Evento Coral**: la gema se agrieta y estalla. Tras 1 minuto de cuenta atrás llega una catástrofe: lluvia de coral, pinchos que brotan del suelo, oleadas de infectados y nidos sueltos. Cumple el objetivo que sale en pantalla o mueres al final.

## Emotes
- 20 emotes nuevos (38 en total).
- Ahora puedes elegir qué emotes van en tu rueda: pulsa B y luego R.

## Altavoces: mucho más guapos (nuevo)
- **Cable de altavoz**: une altavoces con un cable (clic en uno y luego en otro). Los conectados suenan lo mismo a la vez, más fuerte (hasta el doble) y más lejos. Se ve el cable colgando.
- **13 filtros de sonido**: Graves, Fiesta, Concierto, Catedral, Bajo el agua, Radio vieja, Teléfono, Megáfono, Lo-fi, Eco, Nightcore y Slowed. Más **ecualizador** y **sala**, en la pestaña Sonido.
- **Visualizador**: barras de colores encima del altavoz que bailan con la música, y notas que saltan con cada golpe de bajo.
- **Altavoz portátil**: llévalo en la mano, en la cabeza o en el inventario y los de tu alrededor oirán tu música.
- Aleatorio, el altavoz brilla cuando suena, play/pausa con redstone y el comparador detecta si hay música.

## Altavoces y Carteles
- **Altavoz**: música de YouTube, Spotify, SoundCloud o mp3 que oye todo el que esté cerca, a la vez, con sonido que se apaga con la distancia.
- **Cartel**: cualquier imagen o GIF de internet, de 1x1 a 16x16 bloques.
- Filtro +18: si una imagen o GIF parece contenido +18, el cartel se queda en blanco. Funciona en tu ordenador sin internet y no hay que configurar nada.

## Mazmorras y jefes
- Cada mazmorra tiene su minijefe antes del jefe y suelta la Llave de coral para abrir la batalla.
- La barra del jefe solo sale al abrir la puerta, y las arenas de jefe están llenas de nidos.
