# Coralosis 1.22.41

## Arreglado: el sonido iba por delante del vídeo
- El cartel seguía el reloj del servidor, que va a tirones cuando el juego va justo, mientras que el sonido sigue a su ritmo. Por eso el sonido se adelantaba. Ahora el cartel sigue **lo que se oye de verdad en el altavoz**, así que imagen y sonido van juntos aunque el juego vaya lento.
- Si el ordenador no da para descodificar el vídeo a tiempo y se queda atrás, se vuelve a poner en su sitio en vez de ir arrastrando el retraso.
- El vídeo de los carteles gasta un poco menos de ordenador.

## Quitado: avisos de copyright
- Ya no salen los puntos de colores, la leyenda ni los avisos de «puede tener copyright».

# (1.22.40)

## Vídeo y sonido de los altavoces: ahora se descargan
- **Una sola consulta a YouTube.** Antes el altavoz pedía el sonido y el cartel pedía la imagen por separado, y YouTube a veces daba uno y no el otro, o cortaba a mitad. Ahora se pregunta una vez y de ahí salen las dos cosas.
- **El sonido se descarga entero antes de sonar** (tarda unos segundos; una canción, casi nada). Ya no se corta a mitad ni se queda pillado.
- **La imagen se descarga mientras tanto.** Mientras baja, el cartel la enseña desde internet como antes; cuando ya está entera (un vídeo de 24 minutos tarda unos 20 segundos), el cartel se pasa solo al archivo: sin cortes, sin retraso y saltando a cualquier minuto al instante.
- Lo descargado se guarda en `.minecraft/derivamedia/videos` y se borra solo (lo que lleva un día sin usarse, o lo más viejo si pasa de 3 GB). Los directos y los vídeos de más de 3 horas se siguen viendo por internet.
- Si la descarga falla, se usa el sistema de antes, así que nunca va peor que en la 1.22.39.

# (1.22.39)

## Vídeos de los carteles mucho mejor
- **Ya no se bloquean vídeos normales.** El filtro +18 confundía caras de cerca y escenas oscuras con desnudos y paraba vídeos de YouTube que no tenían nada. Ahora, en YouTube, Twitch, TikTok, Vimeo, Dailymotion, Kick e Instagram (que no permiten porno) se usa su propia marca de "mayores de 18". El filtro de imágenes queda solo para vídeos sueltos y de X/Twitter, y tiene que saltar 3 veces seguidas.
- **Más fluidos:** 30 imágenes por segundo (antes 20).
- **Más ligeros:** la resolución se ajusta al tamaño del cartel, así que el ordenador trabaja mucho menos.

# (1.22.38)

## Arreglado: el vídeo de los carteles iba con mucho retraso
- Si el vídeo tardaba más de 2,5 segundos en arrancar (lo normal con YouTube), el juego creía que iba desfasado y lo volvía a arrancar una y otra vez, así que nunca alcanzaba al sonido. Ahora se adelanta lo que tarda en arrancar y sale sincronizado con el altavoz.
- Si YouTube da un enlace que no deja ver (error 403), se pide por otra vía en vez de insistir con el mismo.
- Los vídeos de los carteles en bucle ya no fallan cuando el cartel lleva puesto más rato de lo que dura el vídeo.

# (1.22.37)

## Arreglado: los vídeos de los carteles solo los veía una persona
- Cada jugador necesita en su ordenador las herramientas para ver vídeos (yt-dlp y ffmpeg), y el juego solo sabía descargarlas de GitHub. Cuando GitHub fallaba, a quien no las tenía ya no le salía el vídeo.
- Ahora, si GitHub no responde, las baja de otras webs oficiales o de una copia guardada en el GitHub de Derivaland. Así todos ven el vídeo.



## Altavoces: fusión con la versión de Dani
Ahora están juntas las dos versiones del mod de altavoces: lo de Dani y lo nuestro (vídeos en carteles, pistas de Derivaland, avisos de copyright, chat de voz…).
- **Cable de altavoz**: une altavoces con un cable (clic en uno y luego en otro). Los conectados suenan lo mismo a la vez, más fuerte (hasta el doble) y más lejos. Se ve el cable colgando.
- **13 filtros de sonido**: Graves, Fiesta, Concierto, Catedral, Bajo el agua, Radio vieja, Teléfono, Megáfono, Lo-fi, Eco, Nightcore y Slowed. Más **ecualizador** y **sala**, en la pestaña Sonido.
- **Visualizador**: barras de colores encima del altavoz que bailan con la música, y notas que saltan con cada golpe de bajo.
- **Altavoz portátil**: llévalo en la mano, en la cabeza o en el inventario y los de tu alrededor oirán tu música. También tiene el botón ♫ Derivaland.
- Aleatorio, el altavoz brilla cuando suena, play/pausa con redstone y el comparador detecta si hay música.
- Recetas: **cable** (salen 4) = 1 lingote de cobre + 2 hilos + 1 redstone, sin forma. **Altavoz portátil** = hierro arriba; cuero, altavoz, cuero; cuero, cobre, cuero.

# Coralosis 1.22.34

- **Chat de voz por proximidad** propio. Pulsa **V** para abrir el menú: micrófono, salida (cascos o altavoces), volumen de las voces, volumen de tu micro, hablar por voz o pulsando una tecla, probar el micro, y el volumen de cada jugador.
- Se oye a la gente desde donde está, y más bajo cuanto más lejos (48 bloques por defecto).
- Teclas: **V** menú · **Bloq Mayús** hablar (si eliges «pulsando») · **N** silenciar el micro. Se cambian en Opciones → Controles → Chat de voz.
- Encima del nombre de cada uno sale un icono cuando habla, tiene el micro silenciado o está ensordecido.
- No hay que abrir puertos: la voz va por la misma conexión del juego.

# Coralosis 1.22.33

- Carteles: los vídeos se ven mucho más nítidos (hasta 720p; antes eran unos 180p). En Mods → Altavoces y Carteles → Configurar puedes cambiar `calidad_video` a baja, media, alta o maxima (1080p).
- Altavoces: el volumen ahora llega hasta el 200 %.

# Coralosis 1.22.31

- Altavoces: los vídeos de YouTube que daban «This video is not available» al ponerlos ahora se prueban de otras formas antes de rendirse.


- Altavoces y carteles: si YouTube no da un vídeo a la primera (contenido para niños, «no eres un robot»...), se prueba de otras formas. Si aun así no se puede, se dice el motivo (privado, bloqueado en tu país, restricción de edad...).


- Carteles: nueva opción «Por detrás»: tablero (se ve el dorso de madera, como un bloque) o la misma imagen (también se ve desde atrás, bien puesta).


- Al entrar ya no sale la pantalla de MCA para elegir entre ser aldeano o vanilla: todos entráis siempre como jugador vanilla.


## Altavoces y Carteles
- **Vídeos en los carteles:** pega un enlace de YouTube, Twitch, TikTok, un mp4... y el cartel lo reproduce en bucle, sin sonido.
- **Cartel enlazado a un altavoz:** si el altavoz pone un vídeo, el cartel lo enseña a la par con el sonido (pausar, saltar y cambiar de canción van juntos).
- **Pistas de Derivaland:** 8 canciones hechas para la serie, sin copyright (calma, el coral, misterio, tensión, pelea, fiesta, despedida y victoria). Botón «♫ Derivaland» del altavoz.
- **Aviso de copyright:** cada canción de la cola lleva un punto: 🔴 puede tener copyright, 🟢 libre, 🟡 no se sabe.
- La primera vez que veas un vídeo se descarga ffmpeg (una vez, unos 100 MB).


## Agua (más simple)
- Se quedan las cantimploras (cuero, cobre, hierro y coral), el molino, el filtro, la depuradora y el kit de reparación.
- Se puede beber del agua con shift + clic. Si el agua está contaminada, te pasa lo de siempre.
- Las botellas de cristal solo se llenan con agua limpia; para el resto, cantimplora.
- Fuera: garrafa, botella de agua contaminada, colector de lluvia, destilador solar, pozo, nasa y lámpara de medusa.

## Minijefes
- El Contramaestre, la Gran Morena y la Reina Medusa solo salen en la sala de antes del jefe y solo sueltan la Llave de coral (en creativo tienen huevo).
- Fuera los trofeos: caparazón, corona, colmillo, daga y báculo.

## Gólem de coral
- Nuevo aspecto: cuerpo de coral purificado, cabeza de coral cerebro, ramas de coral y un núcleo que brilla en el pecho.


- **Corazón del mar** ya se puede fabricar: 4 lapislázuli en las esquinas, 4 lingotes de oro en los lados y 1 diamante en el centro. Sale en la G.
- Los bloques del agua y del mar (molino, filtro, depuradora, colector, destilador, pozo, nasa y lámpara de medusa) tienen icono propio en el inventario; puestos en el mundo siguen igual.


## Skins nuevas
- Cantimploras, garrafa, kit de reparación y botella de agua contaminada.
- Las máquinas del agua, el colector, el destilador, el pozo, la nasa y la lámpara de medusa.
- Los huevos de todos los bichos del mar y de los minijefes.
- Los trofeos de los minijefes.

## Agua
- Para beber directamente del agua, de un caldero, de la lluvia o de un colector/pozo/destilador hay que estar **agachado (shift)** y hacer clic derecho con la mano vacía.


- La gema de la muerte se separa en sus 3 trozos, que salen volando y caen.
- En la G hay una fila vacía entre cada conjunto de recetas.
- Las piedras de teletransporte (registro y automática) ya salen en la G con su receta.


## Pantalla G
- Las recetas van ordenadas por filas: cada armadura en su fila con sus armas y herramientas, luego los arcos, los materiales, el agua, las máquinas y la comida.

## Muertes
- La gema de la muerte ahora se agrieta y se rompe en pedazos, con un sonido de pérdida.
- Si mueres durante un Evento Coral suena distinto: el coral se te traga.


## Avisos
- Cuando alguien popea un tótem (el normal o los de coral), sale en el chat de todos, en amarillo y negrita, quién ha sido y qué tótem.
- Cuando alguien muere, a todos les sale la gema roja con quién ha muerto y cómo. Si ha quedado eliminado, también lo dice.

## Mazmorras
- Las puertas de coral se abren bloque a bloque, empezando por donde metes la llave.


## Pantalla G
- Cada receta va en su cuadro de la rejilla, sin fondo oscuro.
- Nueva sección **Misiones del evento** en la pestaña Misiones: misiones que ponen los admins, algunas una por día, con su progreso y su recompensa.
- Algunas recetas pueden llegar bloqueadas por los admins: salen con candado hasta que se desbloqueen.

## Ayuda
- `/help` enseña la ayuda de Derivaland (los admins ven todos sus comandos por temas). `/help <comando>` de Minecraft sigue funcionando.


## La gema del coral (nuevo)
- Los admins sacan la gema con `/coralosis evento`: sale en el centro de la pantalla, va cambiando de color como una ruleta y se queda en uno. Cada color es un tipo de anuncio: blanca (información), tricolor (evento), violeta (cambio de dificultad), roja (sanción), turquesa (recompensa), coral (aparición).
- **Evento Coral**: la gema se agrieta y estalla. Tras una cuenta atrás llega una catástrofe: lluvia de coral, pinchos que brotan del suelo, oleadas de infectados, creepers, rayos, fantasmas... Cumple el objetivo que sale en pantalla o mueres al final.
- Puede haber **varios Eventos Coral a la vez**, cada uno con su objetivo: arriba de la pantalla salen todos con su tiempo y si lo estás cumpliendo (✔/✖).

## Emotes
- 20 emotes nuevos (38 en total).
- Ahora puedes elegir qué emotes van en tu rueda: pulsa B y luego R.

## Altavoces y Carteles
- **Altavoz**: música de YouTube, Spotify, SoundCloud o mp3 que oye todo el que esté cerca, a la vez, con sonido que se apaga con la distancia.
- **Cartel**: cualquier imagen o GIF de internet, de 1x1 a 16x16 bloques.
- Filtro +18: si una imagen o GIF parece contenido +18, el cartel se queda en blanco. Funciona en tu ordenador sin internet y no hay que configurar nada.

## Mazmorras y jefes
- Cada mazmorra tiene su minijefe antes del jefe y suelta la Llave de coral para abrir la batalla.
- La barra del jefe solo sale al abrir la puerta, y las arenas de jefe están llenas de nidos.
