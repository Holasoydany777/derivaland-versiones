# Coralosis 1.22.96

## Subastas en directo
- Un admin se pone en la mano lo que quiera vender y escribe **`/subasta empezar <precio> [segundos] [subida]`**. Por ejemplo: `/subasta empezar 50 90 10`.
- Sale un **título en pantalla**, una **barra arriba** con el objeto, la puja más alta y el tiempo, y **botones en el chat** para pujar.
- Se puja en **DerivaCoins** con los botones, con **`/pujar`** (la mínima) o **`/pujar <cantidad>`**.
- Las monedas de la puja más alta se quedan guardadas. Si te superan, te las devuelven al momento.
- Si alguien puja en los últimos 10 segundos, **hay prórroga** hasta 10 segundos más.
- Cuenta atrás con **«¡A la una, a las dos, a las tres!»** y **«¡ADJUDICADO!»**. El objeto va al ganador y las monedas al vendedor.
- **Atril de subasta** (en la pestaña del casino): si hay uno cerca cuando empieza la subasta, el objeto **flota encima**. Clic dos veces para pujar la mínima; agachado, para ver la subasta.
- Admins: `/subasta terminar` (adjudica ya) y `/subasta cancelar` (devuelve todo).

## Torneo de póker o blackjack (evento especial)
- Se activa cuando queráis con **`/torneo empezar poker <premio> [inscripción]`** o **`/torneo empezar blackjack <premio> [inscripción]`**.
- Todos ven el aviso con el botón **[APUNTARME]** (o `/torneo apuntarme`). Si hay inscripción, se paga en DerivaCoins y se suma al premio.
- Un admin lo arranca con **`/torneo comenzar`**. Se juega **desde el chat con botones**, con fichas del torneo (no son fichas ni DerivaCoins de verdad).
- **Póker:** Texas Hold'em sin límite, hasta 10 jugadores. Las ciegas se doblan cada pocas manos. Gana el último que quede con fichas.
- **Blackjack:** hasta 12 jugadores contra la banca, todos a la vez. Después de las rondas que toquen, gana quien tenga más fichas.
- El ganador se lleva el **premio en DerivaCoins**. Con `/torneo premio objeto`, un admin puede añadir también lo que lleva en la mano.
- Más: `/torneo estado`, `/torneo salir`, `/torneo terminar` (gana quien vaya primero) y `/torneo cancelar`.

## Ojo
- **Todos con el modpack 1.22.96** (cambia el casino: hay un bloque nuevo).
- Si el ganador de una subasta o un torneo no está conectado, se le guarda el premio y se le da al entrar.

