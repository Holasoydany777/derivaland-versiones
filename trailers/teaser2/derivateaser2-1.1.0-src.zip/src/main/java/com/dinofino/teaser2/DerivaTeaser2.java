package com.dinofino.teaser2;

import net.neoforged.fml.common.Mod;

/**
 * Derivaland: Teaser Trailer 2. Plató del pueblo (dimensión derivateaser2:pueblo) y director del teaser.
 * Solo para grabar en un mundo de un jugador: /teasertrailer2 accion
 */
@Mod(DerivaTeaser2.MODID)
public final class DerivaTeaser2 {
    public static final String MODID = "derivateaser2";
}
