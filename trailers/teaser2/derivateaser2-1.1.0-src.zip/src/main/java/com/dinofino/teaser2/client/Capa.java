package com.dinofino.teaser2.client;

import net.minecraft.resources.Identifier;

/** Algo que se dibuja encima de la imagen: negro, destellos, bandas de cine, textos o el logo. */
public final class Capa {
    public enum Tipo { NEGRO, COLOR, BANDAS, OSCURECER, IMAGEN }

    final Tipo tipo;
    final int t0, t1, entrada, salida;
    final int z;
    int color = 0x000000;
    float max = 1f;
    // imágenes (en píxeles de una pantalla de 1920x1080)
    Identifier tex;
    int ancho, alto;
    float cx = 960, cy = 540, escala = 1f;
    float subir = 0f;   // se desliza hacia arriba mientras aparece (en píxeles)

    Capa(Tipo tipo, int t0, int t1, int entrada, int salida, int z) {
        this.tipo = tipo; this.t0 = t0; this.t1 = t1; this.entrada = entrada; this.salida = salida; this.z = z;
    }

    /** Opacidad en el instante t (con fundidos de entrada y salida). */
    float alfa(double t) {
        if (t < t0 || t > t1) return 0f;
        double a = 1;
        if (entrada > 0 && t < t0 + entrada) a = (t - t0) / entrada;
        if (salida > 0 && t > t1 - salida) a = Math.min(a, (t1 - t) / salida);
        a = Math.max(0, Math.min(1, a));
        return (float) (a * a * (3 - 2 * a)) * max;
    }

    float progresoEntrada(double t) {
        if (entrada <= 0) return 1f;
        return (float) Math.max(0, Math.min(1, (t - t0) / entrada));
    }
}
