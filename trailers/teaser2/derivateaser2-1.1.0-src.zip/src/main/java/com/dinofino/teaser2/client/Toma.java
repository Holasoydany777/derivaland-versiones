package com.dinofino.teaser2.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import net.minecraft.world.phys.Vec3;

/** Un plano: tramo de tiempo, movimiento de cámara, quién sale y lo que pasa durante él. */
public final class Toma {
    public final String nombre;
    public final int t0, t1;
    Supplier<Vec3> p0, p1, look0, look1;
    float yaw0, yaw1, pitch0, pitch1, fov0 = 60, fov1 = 60;
    int curva = 1;          // 0 lineal, 1 suave (entra y sale), 2 acelera, 3 frena
    float temblor = 0f;     // cámara en mano (grados)
    // niebla de este plano (lejos < 0: la normal)
    float nieblaCerca = 0, nieblaLejos = -1;
    int nieblaColor = -1;
    int hora = -1;          // hora del mundo al empezar
    Runnable alEmpezar;
    Runnable preparacion;
    final Set<String> actores = new HashSet<>();
    final List<int[]> evT = new ArrayList<>();
    final List<Runnable> evR = new ArrayList<>();
    IntConsumer cadaTick;

    Toma(String nombre, int t0, int t1) { this.nombre = nombre; this.t0 = t0; this.t1 = t1; }

    Toma desde(Vec3 p, Vec3 hasta) { this.p0 = () -> p; this.p1 = () -> hasta; return this; }
    Toma desde(Supplier<Vec3> p, Supplier<Vec3> hasta) { this.p0 = p; this.p1 = hasta; return this; }
    Toma mirando(Vec3 a, Vec3 b) { this.look0 = () -> a; this.look1 = () -> b; return this; }
    Toma mirando(Supplier<Vec3> a, Supplier<Vec3> b) { this.look0 = a; this.look1 = b; return this; }
    Toma angulos(float y0, float y1, float p0, float p1) { this.yaw0 = y0; this.yaw1 = y1; this.pitch0 = p0; this.pitch1 = p1; return this; }
    Toma fov(float a, float b) { this.fov0 = a; this.fov1 = b; return this; }
    Toma curva(int c) { this.curva = c; return this; }
    Toma temblor(float t) { this.temblor = t; return this; }
    Toma niebla(float cerca, float lejos, int color) { this.nieblaCerca = cerca; this.nieblaLejos = lejos; this.nieblaColor = color; return this; }
    Toma hora(int h) { this.hora = h; return this; }
    Toma alEmpezar(Runnable r) { this.alEmpezar = r; return this; }
    Toma prepara(Runnable r) { this.preparacion = r; return this; }
    Toma actores(String... tags) { for (String t : tags) actores.add(t); return this; }
    Runnable preparar() { return preparacion; }
    Toma en(int rel, Runnable r) { evT.add(new int[]{rel}); evR.add(r); return this; }
    Toma cadaTick(IntConsumer c) { this.cadaTick = c; return this; }

    double avance(double t) {
        double u = Math.max(0, Math.min(1, (t - t0) / (double) (t1 - t0)));
        return switch (curva) {
            case 0 -> u;
            case 2 -> u * u;
            case 3 -> 1 - (1 - u) * (1 - u);
            default -> u * u * (3 - 2 * u);
        };
    }
}
