package com.dinofino.teaser2.client;

import com.dinofino.teaser2.Plato;
import com.dinofino.teaser2.Servidor;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.world.phys.Vec3;

/**
 * /teasertrailer2 accion          el teaser entero (si el pueblo no está montado, lo monta antes)
 * /teasertrailer2 plano <1-21>    un plano suelto, para repetir tomas (sin la música)
 * /teasertrailer2 parar           corta
 * /teasertrailer2 montar          vuelve a levantar el pueblo
 * /teasertrailer2 ir              entra al pueblo en espectador para mirarlo
 * /teasertrailer2 salir           vuelve a donde estabas
 * /teasertrailer2 amigo <nombre>  el nombre de Minecraft de ZainZero para su cameo en la plaza
 */
public final class Comandos {
    static final Vec3 MIRADOR = new Vec3(-12, 80, 26);

    public static void registrar(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("teasertrailer2")
            .then(Commands.literal("accion").executes(c -> { accion(); return 1; }))
            .then(Commands.literal("plano").then(Commands.argument("n", IntegerArgumentType.integer(1, Guion.PLANOS.length))
                .executes(c -> { plano(IntegerArgumentType.getInteger(c, "n")); return 1; })))
            .then(Commands.literal("parar").executes(c -> { Director.parar(true); return 1; }))
            .then(Commands.literal("montar").executes(c -> { montar(false, 0); return 1; }))
            .then(Commands.literal("ir").executes(c -> { ir(); return 1; }))
            .then(Commands.literal("salir").executes(c -> { salir(); return 1; }))
            .then(Commands.literal("amigo").then(Commands.argument("nombre", StringArgumentType.word())
                .executes(c -> { amigo(StringArgumentType.getString(c, "nombre")); return 1; }))));
    }

    static void accion() {
        Director.mensaje("¡Acción! Empieza a grabar: 4 segundos en negro y luego el teaser (88 s).");
        montar(true, 0);
    }

    static void plano(int n) {
        Director.mensaje("Plano " + n + ": " + Guion.NOMBRES[n - 1] + " (sin música; la música va en /teasertrailer2 accion).");
        montar(true, n);
    }

    /** Monta el pueblo si hace falta (o siempre, si no se va a grabar) y luego, si toca, empieza. */
    static void montar(boolean yEmpezar, int plano) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSingleplayerServer() == null || mc.player == null) { Director.mensaje("Solo en un mundo de un jugador."); return; }
        var uuid = mc.player.getUUID();
        Director.servidor(s -> {
            var l = Servidor.pueblo(s);
            if (l == null) {
                mc.execute(() -> Director.mensaje("No encuentro la dimensión del pueblo. Sal del mundo y vuelve a entrar con el mod puesto."));
                return;
            }
            boolean hacia = !Plato.montado(l) || !yEmpezar;
            if (hacia) {
                mc.execute(() -> Director.mensaje("Montando el pueblo… unos segundos."));
                try {
                    Servidor.restaurar(s);
                    Plato.montar(l);
                } catch (Throwable e) {
                    Servidor.LOG.error("Error montando el pueblo", e);
                    mc.execute(() -> Director.mensaje("Error montando el pueblo: " + e));
                    return;
                }
            }
            if (yEmpezar) mc.execute(() -> Director.empezar(plano));
            else {
                Servidor.entrar(s, uuid, MIRADOR, -160, 25);
                mc.execute(() -> Director.mensaje("Pueblo listo. Para grabar: /teasertrailer2 accion"));
            }
        });
    }

    static void ir() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSingleplayerServer() == null || mc.player == null) return;
        var uuid = mc.player.getUUID();
        Director.servidor(s -> Servidor.entrar(s, uuid, MIRADOR, -160, 25));
    }

    static void salir() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSingleplayerServer() == null || mc.player == null) return;
        Director.parar(false);
        var uuid = mc.player.getUUID();
        Director.servidor(s -> Servidor.salir(s, uuid));
    }

    static void amigo(String nombre) {
        Director.amigo = nombre;
        Director.mensaje("Cameo de la plaza: " + nombre + " (sale junto a tu skin en el plano 4).");
    }

    private Comandos() {}
}
