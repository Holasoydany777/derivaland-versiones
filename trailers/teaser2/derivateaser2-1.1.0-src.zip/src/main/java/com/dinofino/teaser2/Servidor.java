package com.dinofino.teaser2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Lo básico del servidor (siempre en el hilo del servidor integrado): entrar y salir del plató, congelar el mundo,
 * sacar y quitar entidades, y los bloques temporales (todo lo que cambia durante el teaser se deja como estaba).
 */
public final class Servidor {
    public static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger("derivateaser2");
    /** Etiqueta de todo lo que saca el teaser (se borra al acabar). */
    public static final String TAG = "dt2";

    private static final Map<BlockPos, BlockState> RESTAURAR = new LinkedHashMap<>();
    private static final Map<String, UUID> CACHE = new HashMap<>();

    private static ResourceKey<Level> antesDim;
    private static Vec3 antesPos;
    private static GameType antesModo;
    private static Boolean antesTiempo, antesClima, antesMobs;
    private static Integer antesFuego;
    private static long antesHora;
    private static String antesLluvia = "clear";

    public static ServerLevel pueblo(MinecraftServer s) { return s.getLevel(Sitio.PUEBLO); }

    public static void cmd(MinecraftServer s, String c) {
        ServerLevel l = pueblo(s);
        if (l == null) return;
        try {
            s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withLevel(l).withSuppressedOutput(), c);
        } catch (Throwable e) {
            LOG.warn("Comando del teaser fallido: {} ({})", c, e.toString());
        }
    }

    public static String f(double d) { return String.format(Locale.ROOT, "%.3f", d); }

    // ------------------------------------------------------------------ jugador
    public static void entrar(MinecraftServer s, UUID jugador, Vec3 pos, float yaw, float pitch) {
        ServerPlayer p = s.getPlayerList().getPlayer(jugador);
        ServerLevel l = pueblo(s);
        if (p == null || l == null) return;
        if (p.level().dimension() != Sitio.PUEBLO) {
            antesDim = p.level().dimension();
            antesPos = p.position();
            antesModo = p.gameMode.getGameModeForPlayer();
        }
        cmd(s, "gamemode spectator " + jugador);
        cmd(s, "execute in " + Sitio.PUEBLO.identifier() + " run tp " + jugador + " " + f(pos.x) + " " + f(pos.y) + " " + f(pos.z) + " " + f(yaw) + " " + f(pitch));
    }

    public static void salir(MinecraftServer s, UUID jugador) {
        ServerPlayer p = s.getPlayerList().getPlayer(jugador);
        if (p == null) return;
        String dim = antesDim != null ? antesDim.identifier().toString() : "minecraft:overworld";
        if (antesPos != null) cmd(s, "execute in " + dim + " run tp " + jugador + " " + f(antesPos.x) + " " + f(antesPos.y) + " " + f(antesPos.z));
        else cmd(s, "execute in minecraft:overworld run tp " + jugador + " ~ 100 ~");
        cmd(s, "gamemode " + (antesModo != null ? antesModo.getName() : "creative") + " " + jugador);
    }

    // ------------------------------------------------------------------ reglas del mundo
    public static void congelar(MinecraftServer s) {
        GameRules g = s.getGameRules();
        if (antesTiempo == null) {
            antesTiempo = g.get(GameRules.ADVANCE_TIME);
            antesClima = g.get(GameRules.ADVANCE_WEATHER);
            antesMobs = g.get(GameRules.SPAWN_MOBS);
            antesFuego = g.get(GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER);
            ServerLevel o = s.overworld();
            antesHora = o.getDefaultClockTime();
            antesLluvia = o.isThundering() ? "thunder" : (o.isRaining() ? "rain" : "clear");
        }
        g.set(GameRules.ADVANCE_TIME, false, s);
        g.set(GameRules.ADVANCE_WEATHER, false, s);
        g.set(GameRules.SPAWN_MOBS, false, s);
        g.set(GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER, 0, s);
        clima(s, "clear");
    }

    public static void descongelar(MinecraftServer s) {
        GameRules g = s.getGameRules();
        if (antesTiempo != null) {
            g.set(GameRules.ADVANCE_TIME, antesTiempo, s);
            g.set(GameRules.ADVANCE_WEATHER, antesClima, s);
            g.set(GameRules.SPAWN_MOBS, antesMobs, s);
            g.set(GameRules.FIRE_SPREAD_RADIUS_AROUND_PLAYER, antesFuego, s);
            cmd(s, "time set " + (int) Math.min(Integer.MAX_VALUE, Math.max(0, antesHora)));
            clima(s, antesLluvia);
            antesTiempo = antesClima = antesMobs = null;
        }
    }

    public static void hora(MinecraftServer s, int t) { cmd(s, "time set " + t); }

    public static void clima(MinecraftServer s, String w) { cmd(s, "weather " + w); }

    // ------------------------------------------------------------------ entidades
    public static void limpiar(MinecraftServer s) {
        CACHE.clear();
        ServerLevel l = pueblo(s);
        if (l == null) return;
        List<Entity> fuera = new ArrayList<>();
        for (Entity e : l.getAllEntities()) if (e.entityTags().contains(TAG) || esBasura(e)) fuera.add(e);
        for (Entity e : fuera) e.discard();
    }

    private static boolean esBasura(Entity e) {
        String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
        return id.equals("minecraft:item") || id.equals("minecraft:experience_orb") || id.equals("minecraft:lightning_bolt")
            || id.equals("minecraft:drowned") || id.equals("minecraft:squid") || id.equals("minecraft:glow_squid")
            || id.equals("minecraft:tropical_fish") || id.equals("minecraft:cod") || id.equals("minecraft:salmon")
            || id.equals("minecraft:dolphin") || id.startsWith("coralosis:");
    }

    /** Quita los vecinos (y su coral de la cabeza) que no salen en este plano. */
    public static void soloActores(MinecraftServer s, java.util.Set<String> quedan) {
        ServerLevel l = pueblo(s);
        if (l == null) return;
        List<Entity> fuera = new ArrayList<>();
        for (Entity e : l.getAllEntities()) {
            if (!e.entityTags().contains(TAG)) continue;
            String suyo = null;
            for (String t : e.entityTags()) if (!t.equals(TAG)) suyo = t;
            if (suyo == null) continue;
            boolean vecino = e instanceof net.minecraft.world.entity.decoration.Mannequin;
            String dueno = suyo.endsWith("_coral") ? suyo.substring(0, suyo.length() - 6) : null;
            if (vecino && !quedan.contains(suyo)) fuera.add(e);
            else if (dueno != null && !quedan.contains(dueno) && dueno.startsWith("dt2_v_")) fuera.add(e);
        }
        for (Entity e : fuera) {
            for (String t : e.entityTags()) CACHE.remove(t);
            e.discard();
        }
    }

    public static Entity buscar(MinecraftServer s, String tag) {
        ServerLevel l = pueblo(s);
        if (l == null) return null;
        UUID u = CACHE.get(tag);
        if (u != null) {
            Entity e = l.getEntity(u);
            if (e != null && !e.isRemoved()) return e;
            CACHE.remove(tag);
        }
        for (Entity e : l.getAllEntities()) {
            if (e.entityTags().contains(tag)) {
                CACHE.put(tag, e.getUUID());
                return e;
            }
        }
        return null;
    }

    public static boolean hay(MinecraftServer s, String tag) { return buscar(s, tag) != null; }

    public static void summon(MinecraftServer s, String tipo, Vec3 p, String tag, String nbtExtra) {
        String nbt = "{Tags:[\"" + TAG + "\",\"" + tag + "\"]" + (nbtExtra == null || nbtExtra.isEmpty() ? "" : "," + nbtExtra) + "}";
        cmd(s, "summon " + tipo + " " + f(p.x) + " " + f(p.y) + " " + f(p.z) + " " + nbt);
    }

    public static void quitar(MinecraftServer s, String tag) {
        Entity e = buscar(s, tag);
        if (e != null) e.discard();
        CACHE.remove(tag);
    }

    /** Cambia datos de una entidad del teaser (las de display interpolan solas si se les da duración). */
    public static void datos(MinecraftServer s, String tag, String nbt) {
        cmd(s, "data merge entity @e[tag=" + tag + ",limit=1] " + nbt);
    }

    /** Matriz 4x4 en el formato de los display (16 floats, por filas). */
    public static String matriz(Matrix4f m) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < 16; i++) {
            if (i > 0) sb.append(',');
            sb.append(f(m.getRowColumn(i >> 2, i & 3))).append('f');
        }
        return sb.append(']').toString();
    }

    /** Escala uniforme alrededor del centro de un bloque de display (para que crezca/late desde el centro). */
    public static String escalaCentrada(float e) {
        return "{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[" + f(-e / 2) + "f," + f(-e / 2) + "f," + f(-e / 2) + "f],scale:[" + f(e) + "f," + f(e) + "f," + f(e) + "f]}";
    }

    /** Escala uniforme con la base en el sitio de la entidad (para cosas que crecen desde el suelo). */
    public static String escalaPie(float e) {
        return "{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[" + f(-e / 2) + "f,0f," + f(-e / 2) + "f],scale:[" + f(e) + "f," + f(e) + "f," + f(e) + "f]}";
    }

    public static String escala(float e) {
        return "{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[" + f(e) + "f," + f(e) + "f," + f(e) + "f]}";
    }

    // ------------------------------------------------------------------ bloques temporales
    public static void temporal(ServerLevel l, BlockPos p, BlockState st) {
        if (st == null || l == null) return;
        p = p.immutable();
        RESTAURAR.putIfAbsent(p, l.getBlockState(p));
        l.setBlock(p, st, Plato.FLAGS);
    }

    public static void temporal(MinecraftServer s, int x, int y, int z, String id, String props) {
        temporal(pueblo(s), new BlockPos(x, y, z), Plato.b(id, props));
    }

    public static void restaurar(MinecraftServer s) {
        ServerLevel l = pueblo(s);
        if (l == null) { RESTAURAR.clear(); return; }
        for (BlockPos p : RESTAURAR.keySet()) l.setBlock(p, Blocks.AIR.defaultBlockState(), Plato.FLAGS);
        for (Map.Entry<BlockPos, BlockState> e : RESTAURAR.entrySet()) l.setBlock(e.getKey(), e.getValue(), Plato.FLAGS);
        RESTAURAR.clear();
    }

    public static void particulas(MinecraftServer s, String tipo, Vec3 p, double dx, double dy, double dz, int n, double vel) {
        cmd(s, "particle " + tipo + " " + f(p.x) + " " + f(p.y) + " " + f(p.z) + " " + f(dx) + " " + f(dy) + " " + f(dz) + " " + f(vel) + " " + n + " force");
    }

    private Servidor() {}
}
