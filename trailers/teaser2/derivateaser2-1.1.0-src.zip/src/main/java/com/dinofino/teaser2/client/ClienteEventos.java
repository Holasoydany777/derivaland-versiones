package com.dinofino.teaser2.client;

import com.dinofino.teaser2.DerivaTeaser2;
import com.dinofino.teaser2.Sitio;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.SelectMusicEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

@EventBusSubscriber(modid = DerivaTeaser2.MODID, value = Dist.CLIENT)
public final class ClienteEventos {
    @SubscribeEvent
    public static void capas(RegisterGuiLayersEvent e) {
        e.registerAboveAll(Sitio.id("teaser"), Overlay::dibujar);
    }

    @SubscribeEvent
    public static void comandos(RegisterClientCommandsEvent e) {
        Comandos.registrar(e.getDispatcher());
    }

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post e) {
        Director.tickCliente();
        Director.enderezarCuerpos();
    }

    @SubscribeEvent
    public static void fotograma(RenderFrameEvent.Pre e) {
        Director.fotograma(e.getPartialTick().getGameTimeDeltaPartialTick(false));
    }

    /** Fuera toda la interfaz del juego mientras se graba (menos nuestra capa). */
    @SubscribeEvent
    public static void interfaz(RenderGuiLayerEvent.Pre e) {
        if (Director.activo && !e.getName().getNamespace().equals(DerivaTeaser2.MODID)) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void angulos(ViewportEvent.ComputeCameraAngles e) {
        if (!Director.activo) return;
        e.setYaw(Director.camYaw);
        e.setPitch(Director.camPitch);
        e.setRoll(Director.camRoll);
    }

    @SubscribeEvent
    public static void fov(ViewportEvent.ComputeFov e) {
        if (Director.activo) e.setFOV(Director.camFov);
    }

    private static Toma nieblaToma() {
        if (!Director.activo || Director.prep > 0 || Director.actual == null) return null;
        Toma t = Director.actual;
        return t.nieblaLejos > 0 ? t : null;
    }

    @SubscribeEvent
    public static void niebla(ViewportEvent.RenderFog e) {
        Toma t = nieblaToma();
        if (t == null || e.getType() != net.minecraft.world.level.material.FogType.NONE) return;
        e.setNearPlaneDistance(t.nieblaCerca);
        e.setFarPlaneDistance(t.nieblaLejos);
    }

    @SubscribeEvent
    public static void colorNiebla(ViewportEvent.ComputeFogColor e) {
        Toma t = nieblaToma();
        if (t == null || t.nieblaColor < 0) return;
        e.setRed(((t.nieblaColor >> 16) & 255) / 255f);
        e.setGreen(((t.nieblaColor >> 8) & 255) / 255f);
        e.setBlue((t.nieblaColor & 255) / 255f);
    }

    @SubscribeEvent
    public static void musica(SelectMusicEvent e) {
        if (Director.activo) e.setMusic(null);
    }

    @SubscribeEvent
    public static void salir(ClientPlayerNetworkEvent.LoggingOut e) {
        Director.activo = false;
    }

    private ClienteEventos() {}
}
