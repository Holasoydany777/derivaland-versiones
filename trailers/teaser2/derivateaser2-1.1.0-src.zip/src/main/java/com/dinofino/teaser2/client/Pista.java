package com.dinofino.teaser2.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/** Sonido del tráiler que se oye igual esté donde esté la cámara, y que se puede bajar poco a poco. */
public final class Pista extends AbstractTickableSoundInstance {
    private float base;
    private int fundido = -1, fundidoTotal;

    public Pista(Identifier id, float volumen, float tono) {
        super(SoundEvent.createVariableRangeEvent(id), SoundSource.MASTER, RandomSource.create());
        this.base = volumen;
        this.volume = volumen;
        this.pitch = tono;
        this.relative = true;
        this.attenuation = SoundInstance.Attenuation.NONE;
        this.x = 0; this.y = 0; this.z = 0;
        this.looping = false;
    }

    /** Baja hasta cero en n ticks y se para. */
    public void fundir(int n) {
        if (n <= 0) { this.stop(); return; }
        this.fundido = n;
        this.fundidoTotal = n;
    }

    public void cortar() { this.stop(); }

    @Override
    public void tick() {
        if (fundido >= 0) {
            fundido--;
            this.volume = base * Math.max(0f, fundido / (float) fundidoTotal);
            if (fundido <= 0) this.stop();
        }
    }

    @Override
    public boolean canStartSilent() { return true; }
}
