package com.dinofino.teaser2.client;

import com.dinofino.teaser2.Sitio;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.phys.Vec3;

/**
 * El recorrido de un vecino durante un plano: puntos (tick relativo, x, z). La altura sale del terreno y,
 * mientras anda, mira hacia donde va. Quieto, mira hacia el último sitio al que iba (o a donde se le diga).
 */
final class Camino {
    private final List<double[]> p = new ArrayList<>();
    private float yawQuieto = Float.NaN;
    private double alto = Double.NaN;

    Camino en(int tick, double x, double z) { p.add(new double[]{tick, x, z}); return this; }
    Camino mirandoQuieto(float yaw) { this.yawQuieto = yaw; return this; }
    Camino altura(double y) { this.alto = y; return this; }

    Vec3 pos(double t) {
        double[] a = p.get(0);
        if (t <= a[0]) return v(a[1], a[2]);
        for (int i = 1; i < p.size(); i++) {
            double[] b = p.get(i);
            if (t <= b[0]) {
                double u = (t - a[0]) / Math.max(1e-6, b[0] - a[0]);
                return v(a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u);
            }
            a = b;
        }
        return v(a[1], a[2]);
    }

    private Vec3 v(double x, double z) { return new Vec3(x, Double.isNaN(alto) ? Sitio.pie(x, z) : alto, z); }

    boolean anda(double t) {
        Vec3 a = pos(t), b = pos(t + 1);
        return a.distanceToSqr(b) > 1e-5;
    }

    float yaw(double t) {
        // hacia donde va (mirando un poco adelante); quieto, lo último que hizo
        for (double k = t; k >= p.get(0)[0] - 1; k -= 1) {
            Vec3 a = pos(k), b = pos(k + 1);
            if (a.distanceToSqr(b) > 1e-5) {
                if (k < t - 1 && !Float.isNaN(yawQuieto)) return yawQuieto;
                return (float) Math.toDegrees(Math.atan2(-(b.x - a.x), b.z - a.z));
            }
        }
        return Float.isNaN(yawQuieto) ? 0f : yawQuieto;
    }
}
