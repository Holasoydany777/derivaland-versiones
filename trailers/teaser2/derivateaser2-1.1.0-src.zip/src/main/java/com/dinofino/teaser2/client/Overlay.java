package com.dinofino.teaser2.client;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;

/** Dibuja las capas del teaser encima de todo (también con la interfaz oculta). */
public final class Overlay {
    static int argb(float a, int rgb) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static void dibujar(GuiGraphicsExtractor g, DeltaTracker dt) {
        if (!Director.activo) return;
        int W = g.guiWidth(), H = g.guiHeight();
        if (Director.prep > 0) {
            g.fill(0, 0, W, H, 0xFF000000);
            return;
        }
        double t = Director.t;
        float s = Math.min(W / 1920f, H / 1080f);
        float ox = (W - 1920f * s) / 2f, oy = (H - 1080f * s) / 2f;
        for (Capa c : Director.capas()) {
            float a = c.alfa(t);
            if (a <= 0.003f) continue;
            switch (c.tipo) {
                case NEGRO -> g.fill(0, 0, W, H, argb(a, 0x000000));
                case COLOR -> g.fill(0, 0, W, H, argb(a, c.color));
                case OSCURECER -> {
                    g.fillGradient(0, 0, W, H / 2, argb(a * 0.85f, 0x03121C), argb(a * 0.45f, 0x041822));
                    g.fillGradient(0, H / 2, W, H, argb(a * 0.45f, 0x041822), argb(a, 0x01070C));
                }
                case BANDAS -> {
                    // 2.39:1 dentro de 16:9 (135 px de 1080 arriba y abajo)
                    int h = (int) Math.ceil(H * 0.125f);
                    g.fill(0, 0, W, h, 0xFF000000);
                    g.fill(0, H - h, W, H, 0xFF000000);
                }
                case IMAGEN -> {
                    float sub = c.subir * (1f - c.progresoEntrada(t));
                    float e = c.escala;
                    var pose = g.pose();
                    pose.pushMatrix();
                    pose.translate(ox + (c.cx - c.ancho * e / 2f) * s, oy + (c.cy - c.alto * e / 2f + sub) * s);
                    pose.scale(s * e, s * e);
                    g.blit(RenderPipelines.GUI_TEXTURED, c.tex, 0, 0, 0f, 0f, c.ancho, c.alto, c.ancho, c.alto, argb(a, 0xFFFFFF));
                    pose.popMatrix();
                }
            }
        }
    }

    private Overlay() {}
}
