package com.dinofino.teaser2;

import static com.dinofino.teaser2.Servidor.f;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Los vecinos de Derivaland: maniquíes (forma de jugador) con las skins propias del mod
 * (assets/derivateaser2/textures/entity/gente/*.png). Los niños son los mismos maniquíes a escala 0.62.
 *
 * Se mueven fotograma a fotograma desde el director: cada tick se les da posición, hacia dónde miran
 * y la cabeza. Al moverse, Minecraft anima solo las piernas y los brazos (andar o correr según la velocidad).
 */
public final class Actores {
    public static final float NINO = 0.62f;

    public static String textura(String skin) { return DerivaTeaser2.MODID + ":entity/gente/" + skin; }

    /** Saca un vecino con una skin del mod. */
    public static void crear(MinecraftServer s, String tag, String skin, Vec3 p, float yaw, float escala) {
        if (Servidor.hay(s, tag)) return;
        Servidor.summon(s, "minecraft:mannequin", p, tag,
            "profile:{texture:\"" + textura(skin) + "\"}," + comun(yaw, escala));
        colocar(s, tag, p, yaw, yaw, 0f);
    }

    /** Saca un maniquí con la skin de un jugador de verdad (el cameo de los creadores). */
    public static void crearJugador(MinecraftServer s, String tag, String nombre, Vec3 p, float yaw) {
        if (Servidor.hay(s, tag)) return;
        String limpio = nombre == null ? "" : nombre.replaceAll("[^A-Za-z0-9_]", "");
        if (!limpio.isEmpty()) Servidor.summon(s, "minecraft:mannequin", p, tag, "profile:\"" + limpio + "\"," + comun(yaw, 1f));
        if (!Servidor.hay(s, tag)) Servidor.summon(s, "minecraft:mannequin", p, tag, comun(yaw, 1f));
        colocar(s, tag, p, yaw, yaw, 0f);
    }

    private static String comun(float yaw, float escala) {
        String s = "hide_description:1b,Invulnerable:1b,Silent:1b,NoGravity:1b,Rotation:[" + f(yaw) + "f,0f]";
        if (Math.abs(escala - 1f) > 0.001f) s += ",attributes:[{id:\"minecraft:scale\",base:" + f(escala) + "d}]";
        return s;
    }

    /** Pone al actor en su sitio: posición de los pies, hacia dónde mira el cuerpo, la cabeza (yaw) y el cabeceo. */
    public static void colocar(MinecraftServer s, String tag, Vec3 p, float yaw, float cabeza, float pitch) {
        Entity e = Servidor.buscar(s, tag);
        if (e == null) return;
        e.setDeltaMovement(Vec3.ZERO);
        e.setPos(p.x, p.y, p.z);
        e.setYRot(yaw);
        e.setXRot(pitch);
        e.setYHeadRot(cabeza);
        if (e instanceof LivingEntity le) le.setYBodyRot(yaw);
    }

    /** Ángulo (yaw de Minecraft) para mirar desde a hacia b. */
    public static float yawHacia(Vec3 a, Vec3 b) {
        return (float) Math.toDegrees(Math.atan2(-(b.x - a.x), b.z - a.z));
    }

    public static float pitchHacia(Vec3 ojos, Vec3 b) {
        double dx = b.x - ojos.x, dy = b.y - ojos.y, dz = b.z - ojos.z;
        return (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    /** Cambia la skin (para cuando la coralosis le alcanza). */
    public static void skin(MinecraftServer s, String tag, String skin) {
        Servidor.datos(s, tag, "{profile:{texture:\"" + textura(skin) + "\"}}");
    }

    public static void brazo(MinecraftServer s, String tag) {
        if (Servidor.buscar(s, tag) instanceof LivingEntity le) le.swing(InteractionHand.MAIN_HAND, true);
    }

    /** Coral que le sale de la cabeza: una planta de coral (modelo en cruz) que crece encima, de 0 a tam en dur ticks. */
    public static void coralCabeza(MinecraftServer s, String tag, Vec3 pies, float escala, String coral, float tam, int dur) {
        String t = tag + "_coral";
        if (!Servidor.hay(s, t)) {
            Vec3 p = pies.add(0, 1.86 * escala, 0);
            Servidor.summon(s, "minecraft:block_display", p, t,
                "block_state:{Name:\"" + coral + "\",Properties:{waterlogged:\"false\"}},brightness:{sky:12,block:12},transformation:" + Servidor.escalaPie(0.01f));
        }
        Servidor.datos(s, t, "{start_interpolation:0,interpolation_duration:" + dur + ",transformation:" + Servidor.escalaPie(tam * escala) + "}");
    }

    private Actores() {}
}
