package com.dinofino.teaser2.client;

import static com.dinofino.teaser2.client.Director.fundir;
import static com.dinofino.teaser2.client.Director.particula;
import static com.dinofino.teaser2.client.Director.servidor;
import static com.dinofino.teaser2.client.Director.sonar;

import com.dinofino.teaser2.Actores;
import com.dinofino.teaser2.Escena;
import com.dinofino.teaser2.Sitio;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.phys.Vec3;

/**
 * Teaser Tráiler 2 de Derivaland Remake. Todo en ticks (20 por segundo): 88 s.
 * Sin destellos ni cortes de un fotograma; la hora del día solo cambia dentro de tres fundidos a negro.
 *
 *  1  Amanecer         0 –  100   dron hacia el pueblo
 *  2  Calle          100 –  180   travelling lateral, vecinos paseando
 *  3  Cartel         180 –  240   «DERIVALAND»
 *  4  Plaza          240 –  340   la fuente, el cameo (texto 1)
 *  5  Huerto         340 –  420   Tomás siega, Vega corre junto a la cerca
 *  6  Niños          420 –  500   corren hacia la playa; Nico se para y mira al mar
 *  7  Playa          500 –  580   Lucía en las barcas, Nico mirando el mar
 *  8  Arrecife       580 –  660   el coral que late bajo el agua
 *  9  Pozo           660 –  720   el coral sale de las paredes
 * 10  Trigo          720 –  780   se marchita y se vuelve coral
 * 11  Atardecer      780 –  880   el pueblo se recoge; el sol cae en el mar (texto 2)
 * 12  El giro        880 –  960   Iker se vuelve: coral en la cabeza
 * 13  Desde arriba   960 – 1020   la coralosis avanza por las calles
 * 14  Puertas       1020 – 1080   portazos y antorchas que se apagan
 * 15  Campana       1080 – 1140   suena sola, cubierta de coral
 * 16  Infectados    1140 – 1220   todos miran a cámara
 * 17  Cartel roto   1220 – 1320   (texto 3)
 * 18  El mar        1320 – 1420   el fondo del mar se enciende de rosa hacia la orilla
 * 19  Silencio      1420 – 1480   negro y una gota
 * 20  Logo          1480 – 1620   el logo del teaser 1, la coralosis se lo come, PRONTO...
 * 21  Post          1620 – 1760   Nico solo en la playa, de noche
 */
public final class Guion {
    /** Tramos de cada plano (número que se usa en /teasertrailer2 plano N). */
    public static final int[][] PLANOS = {
        {0, 100}, {100, 180}, {180, 240}, {240, 340}, {340, 420}, {420, 500}, {500, 580}, {580, 660}, {660, 720}, {720, 780},
        {780, 880}, {880, 960}, {960, 1020}, {1020, 1080}, {1080, 1140}, {1140, 1220}, {1220, 1320}, {1320, 1420}, {1420, 1480},
        {1480, 1620}, {1620, 1760}};
    public static final String[] NOMBRES = {"Amanecer", "Calle", "Cartel", "Plaza", "Huerto", "Niños", "Playa", "Arrecife", "Pozo",
        "Trigo", "Atardecer", "El giro", "Desde arriba", "Puertas", "Campana", "Infectados", "Cartel roto", "El mar", "Silencio", "Logo", "Post"};

    final List<Toma> tomas = new ArrayList<>();
    final List<Capa> capas = new ArrayList<>();
    final int duracion = 1760;
    String nombreJugador, amigo;
    private final Random rnd = new Random();

    static final int NOCHE = 18000, DIA = 2000, ATARDECER = 12500;

    // ------------------------------------------------------------------ vecinos
    /** Un vecino en un plano: quién es, qué skin lleva y por dónde va. */
    static final class Papel {
        final String tag, skin;
        final float escala;
        final Camino camino;
        String jugador;               // cameo con la skin de un jugador de verdad
        Supplier<Vec3> mira;          // si no es null, la cabeza mira ahí
        float cabezaExtra, pitchExtra;
        IntConsumer animar;           // para ajustar cabezaExtra/pitchExtra en cada tick

        Papel(String tag, String skin, float escala, Camino c) { this.tag = "dt2_v_" + tag; this.skin = skin; this.escala = escala; this.camino = c; }

        Papel mira(Supplier<Vec3> m) { this.mira = m; return this; }
    }

    static Papel vecino(String tag, String skin, Camino c) { return new Papel(tag, skin, 1f, c); }

    static Papel nino(String tag, String skin, Camino c) { return new Papel(tag, skin, Actores.NINO, c); }

    static void crear(MinecraftServer s, Papel p) {
        Vec3 a = p.camino.pos(0);
        float yaw = p.camino.yaw(0);
        if (p.skin == null) {
            // sin nombre: la skin del que está grabando (Dani)
            String nombre = p.jugador != null ? p.jugador : (Director.guion != null ? Director.guion.nombreJugador : null);
            Actores.crearJugador(s, p.tag, nombre, a, yaw);
        }
        else Actores.crear(s, p.tag, p.skin, a, yaw, p.escala);
    }

    static void mover(Papel p, int rel) {
        if (p.animar != null) p.animar.accept(rel);
        Vec3 a = p.camino.pos(rel);
        float yaw = p.camino.yaw(rel);
        float cabeza = yaw, pitch = 0;
        if (p.mira != null) {
            Vec3 ojos = a.add(0, 1.62 * p.escala, 0);
            Vec3 m = p.mira.get();
            cabeza = Actores.yawHacia(ojos, m);
            pitch = Actores.pitchHacia(ojos, m);
            // la cabeza no gira más de 70º respecto al cuerpo
            float d = wrap(cabeza - yaw);
            if (Math.abs(d) > 70) cabeza = yaw + Math.signum(d) * 70;
        }
        float c = cabeza + p.cabezaExtra, pt = pitch + p.pitchExtra;
        servidor(s -> Actores.colocar(s, p.tag, a, yaw, c, pt));
    }

    static float wrap(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    /** Pone el reparto en la toma: se crean al prepararla y se colocan en cada tick. */
    static Toma reparto(Toma t, Papel... ps) {
        Runnable antes = t.preparacion;
        IntConsumer cada = t.cadaTick;
        for (Papel p : ps) t.actores.add(p.tag);
        t.prepara(() -> {
            if (antes != null) antes.run();
            servidor(s -> { for (Papel p : ps) crear(s, p); });
        });
        t.cadaTick(rel -> {
            if (cada != null) cada.accept(rel);
            for (Papel p : ps) mover(p, rel);
        });
        return t;
    }

    static Camino quieto(double x, double z, float yaw) { return new Camino().en(0, x, z).mirandoQuieto(yaw); }

    static float hacia(double x, double z, double tx, double tz) { return Actores.yawHacia(new Vec3(x, 0, z), new Vec3(tx, 0, tz)); }

    static double suave(double u) { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); }

    // ------------------------------------------------------------------ el guion
    Guion() {
        // ------------------------------------------------------------------ 1. Amanecer
        tomas.add(new Toma("Amanecer", 0, 100).hora(23250)
            .desde(new Vec3(-88, 79, 7), new Vec3(-64, 75.5, 3))
            .mirando(new Vec3(24, 68, -2), new Vec3(20, 67, -1)).fov(62, 58).curva(3)
            .niebla(24, 170, 0xE9B795));

        // ------------------------------------------------------------------ 2. Calle (travelling lateral)
        tomas.add(reparto(new Toma("Calle", 100, 180).hora(DIA)
                .desde(new Vec3(-26.5, 66.55, -2.35), new Vec3(-16.5, 66.55, -2.35))
                .angulos(0, 0, -4, -4).fov(60, 60).curva(0)
                .cadaTick(rel -> { if (rel == 22 || rel == 30 || rel == 38) servidor(s -> Actores.brazo(s, "dt2_v_elias")); }),
            vecino("marta", "marta", new Camino().en(0, -28.5, 0.6).en(80, -18.5, 0.6)),
            vecino("tomas", "tomas", new Camino().en(0, -12.0, -0.4).en(80, -22.5, -0.5)),
            vecino("lucia", "lucia", new Camino().en(0, -13.5, 1.4).en(80, -23.5, 1.2)),
            vecino("elias", "elias", quieto(-20.6, 2.2, 180f)).mira(() -> new Vec3(-17.5, 66.6, -0.4))));

        // ------------------------------------------------------------------ 3. Cartel
        tomas.add(new Toma("Cartel", 180, 240).hora(DIA)
            .desde(new Vec3(-29.6, 66.2, -3.0), new Vec3(-29.0, 66.15, -3.4))
            .mirando(new Vec3(-26.5, 66.1, -3.6), new Vec3(-26.5, 66.1, -3.5)).fov(56, 52));

        // ------------------------------------------------------------------ 4. Plaza (texto 1) y el cameo
        Vec3 fuente = new Vec3(6.0, 66.4, 0.0);
        List<Papel> plaza = new ArrayList<>();
        plaza.add(new Papel("dani", null, 1f, quieto(3.0, 2.7, hacia(3.0, 2.7, 6, 0))));
        if (amigo == null) amigo = Director.amigo;
        if (amigo != null && !amigo.isEmpty()) {
            Papel zz = new Papel("amigo", null, 1f, quieto(3.9, 3.5, hacia(3.9, 3.5, 6, 0)));
            zz.jugador = amigo;
            plaza.add(zz);
        }
        plaza.add(nino("vega", "vega", circulo(6, 0, 5.2, 0.0, 0.05, 100)));
        plaza.add(nino("pablo", "pablo", circulo(6, 0, 5.2, 0.9, 0.05, 100)));
        plaza.add(vecino("rosa", "rosa", quieto(8.6, 5.6, 200f)).mira(() -> new Vec3(6, 65.5, 0)));
        tomas.add(reparto(new Toma("Plaza", 240, 340).hora(DIA)
            .desde(new Vec3(-5.0, 68.2, 9.8), new Vec3(-4.4, 68.15, 9.2))
            .mirando(fuente, fuente).fov(56, 53), plaza.toArray(new Papel[0])));

        // ------------------------------------------------------------------ 5. Huerto: Tomás siega, Vega corre junto a la cerca
        Vec3 posTomas = new Vec3(-22.5, 65.0, 14.5);
        tomas.add(reparto(new Toma("Huerto", 340, 420).hora(DIA)
                .desde(new Vec3(-15.6, 65.95, 18.6), new Vec3(-16.6, 65.95, 17.4))
                .mirando(new Vec3(-22.5, 66.3, 14.5), new Vec3(-22.5, 66.3, 14.5)).fov(58, 54)
                .cadaTick(rel -> { if (rel % 14 == 4) servidor(s -> Actores.brazo(s, "dt2_v_tomas")); }),
            vecino("tomas", "tomas", quieto(posTomas.x, posTomas.z, 30f)).mira(() -> new Vec3(-23.5, 65.4, 15.8)),
            nino("vega", "vega", new Camino().en(0, -29.0, 22.6).en(80, -14.5, 22.6))));

        // ------------------------------------------------------------------ 6. Niños hacia la playa (picado)
        Papel nico = nino("nico", "nico", new Camino().en(0, -4, 0.5).en(48, -26.5, 0.5).en(58, -32.6, 0.6).mirandoQuieto(90f));
        nico.animar = rel -> nico.pitchExtra = (float) (-10 * suave((rel - 60) / 12.0));
        tomas.add(reparto(new Toma("Niños", 420, 500).hora(DIA)
                .desde(new Vec3(-9.0, 73.8, -6.8), new Vec3(-12.0, 73.0, -6.2))
                .mirando(new Vec3(-16, 64.6, 0.5), new Vec3(-31, 64.0, 0.6)).fov(64, 56),
            nico,
            nino("vega", "vega", new Camino().en(0, -6, -0.6).en(45, -26, -0.4).en(70, -34, 5.5).en(80, -36, 9)),
            nino("pablo", "pablo", new Camino().en(0, -2, 1.3).en(46, -24, 1.2).en(72, -31, 9).en(80, -33, 12))));

        // ------------------------------------------------------------------ 7. Playa: Lucía junto a las barcas, Nico mirando el mar
        Papel nico7 = nino("nico", "nico", quieto(-33.4, 0.8, 90f));
        nico7.animar = rel -> nico7.pitchExtra = -8;
        tomas.add(reparto(new Toma("Playa", 500, 580).hora(DIA)
                .desde(new Vec3(-29.5, 66.0, -11.5), new Vec3(-29.5, 65.9, -4.0))
                .mirando(new Vec3(-42, 63.8, -6), new Vec3(-42, 63.8, 0.5)).fov(62, 58).curva(0),
            vecino("lucia", "lucia", new Camino().en(0, -35.4, -9.5).en(80, -35.6, -4.5)).mira(() -> new Vec3(-60, 64, -6)),
            nico7));

        // ------------------------------------------------------------------ 8. Arrecife: el coral que late (suave, sin destellos)
        Vec3 coral = Sitio.CORAL_VIVO.add(0, 0.6, 0);
        tomas.add(new Toma("Arrecife", 580, 660).hora(DIA)
            .prepara(() -> servidor(Escena::coralVivo))
            .desde(new Vec3(-45.6, 48.2, 7.6), new Vec3(-46.3, 52.6, 6.6))
            .mirando(new Vec3(-50, 51.3, 3), new Vec3(-50, 52.0, 3)).fov(60, 56)
            .en(2, () -> sonar("burbujas", 0.55f))
            .cadaTick(rel -> {
                // late como un corazón lento: se hincha 12 ticks y se deshincha otros 12
                if (rel % 24 == 0) servidor(s -> Escena.latido(s, true, 12));
                if (rel % 24 == 12) servidor(s -> Escena.latido(s, false, 12));
                brillo(coral, 1);
                Vec3 c = Director.camPos;
                particula(ParticleTypes.BUBBLE, c.x + rnd.nextGaussian() * 1.5, c.y - 1 - rnd.nextDouble() * 2, c.z + rnd.nextGaussian() * 1.5, 0, 0.12, 0);
            }));

        // ------------------------------------------------------------------ 9. Pozo
        tomas.add(new Toma("Pozo", 660, 720).hora(DIA)
            .desde(new Vec3(-3.0, 68.7, 8.7), new Vec3(-3.05, 68.0, 9.4))
            .mirando(new Vec3(-3.0, 59.6, 11.4), new Vec3(-3.0, 59.4, 11.2)).fov(62, 56)
            .en(6, () -> sonar("coral", 0.7f)).en(26, () -> sonar("coral", 0.8f, 0.9f)).en(44, () -> sonar("coral", 0.9f, 0.8f))
            .cadaTick(rel -> {
                if (rel < 4) return;
                int total = Escena.pozoTotal();
                int hasta = (int) Math.min(total, (rel - 4) / 50.0 * total);
                servidor(s -> Escena.pozo(s, hasta));
            }));

        // ------------------------------------------------------------------ 10. Trigo
        tomas.add(new Toma("Trigo", 720, 780).hora(DIA)
            .desde(new Vec3(-16.3, 66.25, 16.15), new Vec3(-17.2, 66.15, 16.05))
            .mirando(new Vec3(-26.5, 65.55, 16.0), new Vec3(-26.5, 65.45, 16.0)).fov(60, 56)
            .en(10, () -> sonar("coral", 0.6f, 1.1f)).en(32, () -> sonar("coral", 0.7f, 0.9f))
            .cadaTick(rel -> { double f = rel / 56.0; servidor(s -> Escena.trigo(s, f)); }));

        // ------------------------------------------------------------------ 11. Atardecer: el pueblo se recoge (texto 2)
        tomas.add(reparto(new Toma("Atardecer", 780, 880).hora(ATARDECER)
                .desde(new Vec3(12.5, 76.0, 6.5), new Vec3(10.5, 75.4, 4.5))
                .mirando(new Vec3(-60, 67, 0), new Vec3(-60, 66.5, 0)).fov(58, 54).curva(0)
                .en(62, () -> { servidor(s -> Escena.cerrarPuertaEn(s, -19, -3)); sonar("minecraft:block.wooden_door.close", 0.35f, 0.9f); })
                .en(84, () -> { servidor(s -> Escena.cerrarPuertaEn(s, -10, 3)); sonar("minecraft:block.wooden_door.close", 0.3f, 0.95f); }),
            vecino("marta", "marta", new Camino().en(0, 1.5, 0.5).en(70, -9.5, 1.5).en(80, -9.5, 4.5).en(100, -9.5, 5.5)),
            vecino("tomas", "tomas", new Camino().en(0, -6.0, -0.4).en(50, -18.5, -1.5).en(58, -18.5, -4.6).en(100, -18.5, -5.5)),
            vecino("elias", "elias", new Camino().en(0, -1.0, 2.0).en(100, -6.0, 1.4))));

        // ------------------------------------------------------------------ 12. El giro: Iker se vuelve y tiene coral en la cabeza
        Vec3 iker = new Vec3(30.5, 65.0, 0.5);
        tomas.add(new Toma("El giro", 880, 960).hora(ATARDECER)
            .actores("dt2_v_iker")
            .prepara(() -> servidor(s -> {
                Actores.crear(s, "dt2_v_iker", "iker_giro", iker, -90f, 1f);
                Escena.luz(s, 29, 68, 2, 9);
                Escena.luz(s, 28, 67, -1, 7);
            }))
            .desde(new Vec3(27.4, 66.6, 0.95), new Vec3(28.15, 66.62, 0.8))
            .mirando(new Vec3(30.5, 66.55, 0.5), new Vec3(30.5, 66.6, 0.5)).fov(46, 40).curva(3)
            .en(38, () -> sonar("minecraft:entity.zombie_villager.ambient", 0.9f, 0.6f))
            .en(40, () -> servidor(s -> Actores.coralCabeza(s, "dt2_v_iker", iker, 1f, "minecraft:brain_coral", 0.8f, 16)))
            .en(42, () -> sonar("susurros", 0.7f))
            .cadaTick(rel -> {
                float yaw = (float) (-90 - 180 * suave((rel - 30) / 14.0));
                float cabeza = (float) (yaw - 25 * Math.sin(Math.PI * suave((rel - 28) / 14.0)));
                float pitch = (float) (6 * suave((rel - 50) / 20.0));
                servidor(s -> Actores.colocar(s, "dt2_v_iker", iker, yaw, cabeza, pitch));
            }));

        // ------------------------------------------------------------------ 13. Desde arriba: la coralosis avanza
        tomas.add(new Toma("Desde arriba", 960, 1020).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.trigo(s, 1.0); Escena.pozo(s, Escena.pozoTotal()); }))
            .desde(new Vec3(-6, 110, 34), new Vec3(4, 100, 14))
            .mirando(new Vec3(6, 64, -2), new Vec3(6, 64, -6)).fov(70, 64).curva(0)
            .en(5, () -> sonar("coral", 0.5f, 0.7f)).en(30, () -> sonar("coral", 0.6f, 0.6f))
            .cadaTick(rel -> { double f = Math.min(1, rel / 56.0); servidor(s -> Escena.infeccion(s, f)); }));

        // ------------------------------------------------------------------ 14. Puertas y antorchas (cámara en mano, suave)
        int[] antorchas = {4, 14, 22, 32, 40, 50};
        int[] puertas = {10, 28, 44};
        Toma t14 = new Toma("Puertas", 1020, 1080).hora(NOCHE)
            .prepara(() -> servidor(s -> Escena.infeccion(s, 1.0)))
            .desde(new Vec3(18.6, 66.45, 1.5), new Vec3(21.8, 66.35, 1.1))
            .mirando(new Vec3(26.5, 66.3, -3.2), new Vec3(31.0, 66.1, -3.2)).fov(64, 58).temblor(0.5f);
        for (int i = 0; i < antorchas.length; i++) {
            int k = i;
            t14.en(antorchas[i], () -> { servidor(s -> Escena.apagarAntorcha(s, k)); sonar("minecraft:block.fire.extinguish", 0.45f, 0.9f); });
        }
        for (int i = 0; i < puertas.length; i++) {
            int k = i;
            t14.en(puertas[i], () -> { servidor(s -> Escena.cerrarPuerta(s, k)); sonar("minecraft:block.wooden_door.close", 1.0f, 0.72f); });
        }
        tomas.add(t14);

        // ------------------------------------------------------------------ 15. La campana suena sola
        tomas.add(new Toma("Campana", 1080, 1140).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.infeccion(s, 1.0); Escena.campanaCoral(s); }))
            .desde(new Vec3(6.5, 68.5, -7.4), new Vec3(6.5, 68.45, -7.95))
            .mirando(new Vec3(6.5, 68.35, -9.5), new Vec3(6.5, 68.35, -9.5)).fov(58, 52)
            .en(6, () -> { servidor(Escena::campana); sonar("minecraft:block.bell.use", 0.9f, 0.72f); })
            .en(34, () -> { servidor(Escena::campana); sonar("minecraft:block.bell.use", 0.8f, 0.66f); }));

        // ------------------------------------------------------------------ 16. Los infectados miran a cámara
        String[][] multitud = {{"marta_infectado", "2.6", "-3.4", "a"}, {"tomas_infectado", "1.5", "0.9", "a"}, {"lucia_infectado", "3.0", "4.0", "a"},
            {"elias_infectado", "5.0", "-5.4", "a"}, {"rosa_infectado", "6.6", "5.4", "a"}, {"iker_infectado", "10.2", "-3.6", "a"},
            {"vega_infectado", "0.4", "-1.6", "n"}, {"pablo_infectado", "0.6", "2.6", "n"}};
        Papel[] inf = new Papel[multitud.length];
        for (int i = 0; i < multitud.length; i++) {
            double x = Double.parseDouble(multitud[i][1]), z = Double.parseDouble(multitud[i][2]);
            Camino c = quieto(x, z, hacia(x, z, -4.3, 0.5));
            inf[i] = multitud[i][3].equals("n") ? nino("inf" + i, multitud[i][0], c) : vecino("inf" + i, multitud[i][0], c);
            Papel p = inf[i];
            int fase = i;
            p.mira(() -> Director.camPos);
            p.animar = rel -> { double u = suave((rel - 46 - fase % 2) / 14.0); p.pitchExtra = (float) (12 * u); p.cabezaExtra = (float) (14 * u); };
        }
        tomas.add(reparto(new Toma("Infectados", 1140, 1220).hora(NOCHE)
                .prepara(() -> servidor(s -> {
                    Escena.infeccion(s, 1.0);
                    Escena.luz(s, 2, 67, -1, 11);
                    Escena.luz(s, 2, 67, 3, 11);
                    Escena.luz(s, 7, 67, -6, 9);
                    Escena.luz(s, 8, 67, 6, 9);
                    Escena.luz(s, -1, 67, 0, 10);
                    for (int i = 0; i < 4; i++) {
                        double x = Double.parseDouble(multitud[i][1]), z = Double.parseDouble(multitud[i][2]);
                        Actores.coralCabeza(s, "dt2_v_inf" + i, new Vec3(x, 65, z), 1f, i % 2 == 0 ? "minecraft:brain_coral" : "minecraft:fire_coral", 0.7f, 1);
                    }
                }))
                .desde(new Vec3(-5.4, 66.75, 0.6), new Vec3(-3.2, 66.7, 0.55))
                .mirando(new Vec3(6, 66.3, 0.5), new Vec3(6, 66.3, 0.5)).fov(58, 48).curva(3)
                .en(4, () -> sonar("susurros", 0.7f)).en(40, () -> sonar("susurros", 0.85f, 0.85f)),
            inf));

        // ------------------------------------------------------------------ 17. El cartel roto (texto 3)
        tomas.add(new Toma("Cartel roto", 1220, 1320).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.infeccion(s, 1.0); Escena.cartel(s, true); }))
            .desde(new Vec3(-30.4, 65.95, -2.4), new Vec3(-29.5, 66.0, -3.0))
            .mirando(new Vec3(-26.5, 65.95, -3.4), new Vec3(-26.5, 66.0, -3.5)).fov(58, 50).curva(3).temblor(0.6f));

        // ------------------------------------------------------------------ 18. El mar: el fondo se enciende de rosa hacia la orilla
        tomas.add(new Toma("El mar", 1320, 1420).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.infeccion(s, 1.0); Escena.luz(s, -31, 66, 3, 3); }))
            .desde(new Vec3(-30.5, 67.6, 3.5), new Vec3(-33.6, 66.4, 2.0))
            .mirando(new Vec3(-48, 58.5, 0), new Vec3(-48, 59.5, 0)).fov(62, 54).curva(0)
            .en(0, () -> sonar("burbujas", 0.35f, 0.7f))
            .cadaTick(rel -> { double f = Math.min(1, rel / 88.0); servidor(s -> Escena.marBrilla(s, f)); }));

        // ------------------------------------------------------------------ 19. Silencio (negro y una gota)
        tomas.add(new Toma("Silencio", 1420, 1480).hora(NOCHE)
            .desde(new Vec3(-33.6, 66.4, 2.0), new Vec3(-33.6, 66.4, 2.0))
            .mirando(new Vec3(-48, 59.5, 0), new Vec3(-48, 59.5, 0)).fov(54, 54).curva(0)
            .en(12, () -> sonar("gota", 0.8f)));

        // ------------------------------------------------------------------ 20. Logo
        tomas.add(new Toma("Logo", 1480, 1620).hora(6000)
            .prepara(() -> servidor(Escena::coralVivo))
            .desde(new Vec3(-44.4, 47.6, 9.2), new Vec3(-45.6, 48.3, 7.6))
            .mirando(new Vec3(-57, 49.5, 0.5), new Vec3(-57, 49.8, 0.5)).fov(64, 60).curva(0)
            .en(0, () -> sonar("burbujas", 0.4f, 0.8f))
            .cadaTick(rel -> {
                if (rel % 30 == 0) servidor(s -> Escena.latido(s, true, 15));
                if (rel % 30 == 15) servidor(s -> Escena.latido(s, false, 15));
                if (rel % 3 == 0) {
                    Vec3 c = Director.camPos;
                    particula(ParticleTypes.BUBBLE, c.x + rnd.nextGaussian() * 2, c.y - 2, c.z + rnd.nextGaussian() * 2, 0, 0.1, 0);
                }
            }));

        // ------------------------------------------------------------------ 21. Post: el niño solo en la playa
        Vec3 np = Sitio.NINO_PLAYA;
        Papel nicoPlaya = nino("nico", "nico", quieto(np.x, np.z, 90f));
        nicoPlaya.animar = rel -> nicoPlaya.cabezaExtra = (float) (-14 * suave((rel - 50) / 30.0));
        tomas.add(reparto(new Toma("Post", 1620, 1760).hora(NOCHE)
                .prepara(() -> servidor(s -> Escena.luz(s, -33, 66, 2, 4)))
                .desde(new Vec3(-31.6, 65.7, 1.7), new Vec3(-32.2, 65.65, 1.5))
                .mirando(new Vec3(-40, 64.8, 0.6), new Vec3(-40, 64.8, 0.6)).fov(54, 50).curva(0)
                .en(40, () -> sonar("raro", 0.9f)),
            nicoPlaya));

        capas();
    }

    /** Un círculo alrededor de (cx, cz): niños jugando. */
    static Camino circulo(double cx, double cz, double r, double fase, double vel, int ticks) {
        Camino c = new Camino();
        for (int k = 0; k <= ticks; k += 4) {
            double a = fase + k * vel;
            c.en(k, cx + Math.cos(a) * r, cz + Math.sin(a) * r);
        }
        return c;
    }

    /** Destellos rosas alrededor del coral que late. */
    void brillo(Vec3 c, int n) {
        for (int i = 0; i < n; i++)
            particula(ParticleTypes.GLOW, c.x + rnd.nextGaussian() * 0.9, c.y + rnd.nextDouble() * 1.2, c.z + rnd.nextGaussian() * 0.9, 0, 0.02, 0);
    }

    // ------------------------------------------------------------------ sonidos que no dependen del plano
    void eventos(int k) {
        if (k == 0) {
            sonar("banda", 1.0f);
            sonar("pueblo", 0.7f);
        }
        if (k == 556) fundir("pueblo", 28);
    }

    /** Al reproducir un plano suelto, lo que ya estaría sonando. */
    void sonidosDesde(int inicio) {
        if (inicio > 0 && inicio < 556) sonar("pueblo", 0.6f);
    }

    /** Al reproducir un plano suelto, el pueblo como estaría en ese momento. */
    void alcanzar(int inicio) {
        servidor(s -> {
            if (inicio >= 780) { Escena.trigo(s, 1.0); Escena.pozo(s, Escena.pozoTotal()); }
            if (inicio >= 1020) Escena.infeccion(s, 1.0);
            if (inicio >= 1420) Escena.marBrilla(s, 1.0);
        });
    }

    /** Sacudida de cámara (grados) en el instante t. */
    float sacudida(double t) {
        if (t >= 1480 && t < 1510) return (float) (1.2 * Math.exp(-(t - 1480) / 9.0));
        return 0f;
    }

    // ------------------------------------------------------------------ capas
    private Capa negro(int t0, int t1, int in, int out) {
        Capa c = new Capa(Capa.Tipo.NEGRO, t0, t1, in, out, 10);
        capas.add(c);
        return c;
    }

    private Capa imagen(String tex, int w, int h, float cx, float cy, int t0, int t1, int in, int out) {
        Capa c = new Capa(Capa.Tipo.IMAGEN, t0, t1, in, out, 30);
        c.tex = Sitio.id("textures/gui/" + tex + ".png");
        c.ancho = w; c.alto = h; c.cx = cx; c.cy = cy;
        capas.add(c);
        return c;
    }

    private void destello(int color, float max, int t0, int t1, int out) {
        Capa c = new Capa(Capa.Tipo.COLOR, t0, t1, 0, out, 40);
        c.color = color; c.max = max;
        capas.add(c);
    }

    private void capas() {
        capas.add(new Capa(Capa.Tipo.BANDAS, 0, duracion, 0, 0, 20));
        negro(0, 30, 0, 28);                      // se abre desde negro
        // fundidos suaves donde cambia la hora (la luz nueva llega a oscuras)
        for (int t0 : new int[]{100, 780, 960}) negro(t0 - 8, t0 + 8, 7, 7);
        // textos (Lora cursiva, abajo, como en el teaser 1)
        imagen("t_hogar", 865, 83, 960, 905, 270, 332, 14, 14).subir = 10;
        imagen("t_desperto", 715, 83, 960, 905, 812, 872, 14, 16).subir = 10;
        imagen("t_detener", 486, 83, 960, 905, 1234, 1312, 16, 18).subir = 10;
        // silencio: a negro con la música
        negro(1416, 1481, 4, 0);
        // logo (el del teaser 1): limpio, la coralosis se lo come, PRONTO...
        Capa os = new Capa(Capa.Tipo.OSCURECER, 1480, 1620, 0, 0, 0);
        os.max = 0.62f;
        capas.add(os);
        Capa limpio = imagen("logo_limpio", 1388, 626, 945, 455, 1481, 1572, 8, 26);
        limpio.escala = 0.82f;
        Capa infectado = imagen("logo_coral", 1750, 634, 959, 458, 1532, 1620, 40, 0);
        infectado.escala = 0.82f;
        imagen("pronto", 520, 92, 960, 790, 1556, 1620, 20, 0).subir = 8;
        // al post y fin
        negro(1604, 1640, 16, 18);
        negro(1716, 1760, 30, 0);
        capas.sort((a, b) -> Integer.compare(a.z, b.z));
    }
}
