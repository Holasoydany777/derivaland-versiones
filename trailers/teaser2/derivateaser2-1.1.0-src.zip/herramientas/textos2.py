"""Textos del Teaser 2 con la tipografía del teaser 1 (Lora) y PRONTO... con las letras pixeladas de «2027...»."""
import sys, numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
OUT = sys.argv[1]
REG = '/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'
ITA = '/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf'

def render(name, text, font, size, track=0.0, color=(245, 240, 232), glow=True):
    f = ImageFont.truetype(font, size)
    try: f.set_variation_by_name('Regular' if font == REG else 'Italic')
    except Exception: pass
    adv = [f.getlength(ch) + track * size for ch in text]
    W = int(sum(adv) - track * size + size * 1.2); H = int(size * 1.9)
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    x = size * 0.6; y = size * 0.35
    for ch, a in zip(text, adv):
        d.text((x, y), ch, font=f, fill=color + (255,)); x += a
    if glow:
        sh = Image.new('RGBA', im.size, (0, 0, 0, 0)); a = im.split()[3]
        sh.putalpha(a.filter(ImageFilter.GaussianBlur(size * 0.18)).point(lambda v: int(v * 0.85)))
        base = Image.new('RGBA', im.size, (0, 0, 0, 0)); base.alpha_composite(sh); base.alpha_composite(im); im = base
    bb = im.getbbox(); pad = int(size * 0.3)
    im = im.crop((max(0, bb[0] - pad), max(0, bb[1] - pad), min(im.width, bb[2] + pad), min(im.height, bb[3] + pad)))
    im.save(f'{OUT}/{name}.png'); print(name, im.size)

render('t_hogar', 'Derivaland siempre fue nuestro hogar.', ITA, 44, track=0.03)
render('t_desperto', 'Pero algo despertó bajo el agua.', ITA, 44, track=0.03)
render('t_detener', 'Y no se va a detener.', ITA, 44, track=0.03)

import pixeltitle as pt
pt.G['P'] = ["XXXXXX.", "XXXXXXX", "XX...XX", "XX...XX", "XXXXXXX", "XXXXXX.", "XX.....", "XX.....", "XX....."]
pt.G['T'] = ["XXXXXXX", "XXXXXXX", "..XXX..", "..XXX..", "..XXX..", "..XXX..", "..XXX..", "..XXX..", "..XXX.."]
pt.G['.'] = ["..", "..", "..", "..", "..", "..", "..", "XX", "XX"]
w = pt.word("PRONTO...", seed=5, gap=4)
im = Image.fromarray(w)
im = im.resize((im.width * 2, im.height * 2), Image.NEAREST)
im.save(f'{OUT}/pronto.png'); print('pronto', im.size)
