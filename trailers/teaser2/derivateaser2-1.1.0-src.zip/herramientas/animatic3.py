"""Animatic del Teaser 2: tiempos, textos, logo, música y efectos (sin la imagen del juego).
Uso: python3 animatic2.py <carpeta_assets_mod> <salida.mp4>
"""
import sys, subprocess, numpy as np
from PIL import Image, ImageDraw, ImageFont

A = sys.argv[1]; OUT = sys.argv[2]
W, H, FPS = 960, 540, 30
DUR_T = 1760  # ticks
SR = 44100
FONT = '/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'

PLANOS = [(0, 100, "Amanecer", "Dron hacia el pueblo al amanecer"),
          (100, 180, "Calle", "Travelling lateral: Marta, Tomás, Lucía; Elías saluda"),
          (180, 240, "Cartel", "DERIVALAND, cartel de madera"),
          (240, 340, "Plaza", "La fuente, niños jugando, tu skin de espaldas"),
          (340, 420, "Huerto", "Tomás siega el trigo; Vega corre junto a la cerca"),
          (420, 500, "Niños", "Corren a la playa; Nico se para y mira al mar"),
          (500, 580, "Playa", "Lucía junto a las barcas, Nico mirando el mar"),
          (580, 660, "Arrecife", "Bajo el agua: el coral que late despacio"),
          (660, 720, "Pozo", "El coral sale de las paredes del pozo"),
          (720, 780, "Trigo", "El trigo se marchita y se vuelve coral"),
          (780, 880, "Atardecer", "El pueblo se recoge; el sol cae en el mar"),
          (880, 960, "El giro", "Iker se gira: coral en la cabeza, ojos rosas"),
          (960, 1020, "Desde arriba", "De noche: la coralosis avanza por las calles"),
          (1020, 1080, "Puertas", "Portazos, antorchas que se apagan"),
          (1080, 1140, "Campana", "Suena sola, cubierta de coral"),
          (1140, 1220, "Infectados", "Todos miran a cámara y ladean la cabeza"),
          (1220, 1320, "Cartel roto", "El cartel partido y comido por el coral"),
          (1320, 1420, "El mar", "El fondo del mar se enciende de rosa hacia la orilla"),
          (1420, 1480, "Silencio", "Negro y una gota"),
          (1480, 1620, "Logo", "Logo del teaser 1 → coralosis → PRONTO..."),
          (1620, 1760, "Post", "Nico solo en la playa, de noche")]
COLOR = [(232, 170, 120), (150, 190, 120), (150, 190, 120), (150, 190, 120), (170, 180, 90), (150, 190, 120), (200, 190, 140),
         (40, 120, 150), (110, 120, 110), (190, 170, 90), (220, 120, 70), (150, 90, 80), (30, 30, 60), (30, 30, 60), (30, 30, 60),
         (30, 30, 60), (30, 30, 60), (40, 20, 60), (0, 0, 0), (10, 50, 64), (10, 14, 30)]


def suave(a): a = max(0, min(1, a)); return a * a * (3 - 2 * a)


def alfa(t, t0, t1, i, o, mx=1.0):
    if t < t0 or t > t1: return 0.0
    a = 1.0
    if i > 0 and t < t0 + i: a = (t - t0) / i
    if o > 0 and t > t1 - o: a = min(a, (t1 - t) / o)
    return suave(a) * mx


def load(n, s=1.0):
    im = Image.open(f'{A}/textures/gui/{n}.png').convert('RGBA')
    return im.resize((max(1, int(im.width * s * W / 1920)), max(1, int(im.height * s * W / 1920))), Image.LANCZOS)


IMG = {
    't_hogar': (load('t_hogar'), 960, 905, 270, 332, 14, 14, 10),
    't_desperto': (load('t_desperto'), 960, 905, 812, 872, 14, 16, 10),
    't_detener': (load('t_detener'), 960, 905, 1234, 1312, 16, 18, 10),
    'logo_limpio': (load('logo_limpio', 0.82), 945, 455, 1481, 1572, 8, 26, 0),
    'logo_coral': (load('logo_coral', 0.82), 959, 458, 1532, 1620, 40, 0, 0),
    'pronto': (load('pronto'), 960, 790, 1556, 1620, 20, 0, 8),
}
NEGROS = [(0, 30, 0, 28), (92, 108, 7, 7), (772, 788, 7, 7), (952, 968, 7, 7), (1416, 1481, 4, 0), (1604, 1640, 16, 18), (1716, 1760, 30, 0)]
COLORES = []
f_big = ImageFont.truetype(FONT, 30); f_small = ImageFont.truetype(FONT, 18)
try:
    f_big.set_variation_by_name('Bold'); f_small.set_variation_by_name('Regular')
except Exception:
    pass

# ------------------------------------------------------------------ audio
def dec(n):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f'{A}/sounds/{n}.ogg', '-f', 's16le', '-ac', '2', '-ar', str(SR), '-'], capture_output=True).stdout
    return np.frombuffer(raw, '<i2').reshape(-1, 2).astype(np.float32) / 32768


mix = np.zeros((int(DUR_T / 20 * SR) + SR, 2), np.float32)
def put(n, tick, vol, pitch=1.0, fade_at=None):
    x = dec(n) * vol
    if pitch != 1.0:
        idx = np.arange(0, len(x) - 1, pitch); x = np.stack([np.interp(idx, np.arange(len(x)), x[:, c]) for c in range(2)], 1)
    i = int(tick / 20 * SR); j = min(len(mix), i + len(x)); mix[i:j] += x[:j - i]
put('banda', 0, 1.0)
p = dec('pueblo') * 0.7
fa = int(556 / 20 * SR); p[fa:fa + int(1.2 * SR)] *= np.linspace(1, 0, min(len(p) - fa, int(1.2 * SR)))[:, None]; p[fa + int(1.2 * SR):] = 0
mix[:len(p)] += p
for tick, n, v, pt in [(582, 'burbujas', 0.55, 1), (666, 'coral', 0.7, 1), (686, 'coral', 0.8, 0.9), (704, 'coral', 0.9, 0.8),
                       (730, 'coral', 0.6, 1.1), (752, 'coral', 0.7, 0.9), (922, 'susurros', 0.7, 1), (965, 'coral', 0.5, 0.7),
                       (990, 'coral', 0.6, 0.6), (1144, 'susurros', 0.7, 1), (1180, 'susurros', 0.85, 0.85), (1320, 'burbujas', 0.35, 0.7),
                       (1432, 'gota', 0.8, 1), (1480, 'burbujas', 0.4, 0.8), (1660, 'raro', 0.9, 1)]:
    put(n, tick, v, pt)
mix = np.clip(mix, -1, 1)
raw = (mix * 32767).astype('<i2').tobytes()
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ar', str(SR), '-ac', '2', '-i', '-',
                '/tmp/claude-0/-home-claude/90b65aca-2285-52da-ac07-01637e558a63/scratchpad/animatic_audio.wav'], input=raw, check=True)

# ------------------------------------------------------------------ vídeo
proc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                         '-i', '/tmp/claude-0/-home-claude/90b65aca-2285-52da-ac07-01637e558a63/scratchpad/animatic_audio.wav',
                         '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-shortest', OUT],
                        stdin=subprocess.PIPE)

n = int(DUR_T / 20 * FPS)
for fr in range(n):
    t = fr / FPS * 20
    k = next(i for i, pl in enumerate(PLANOS) if pl[0] <= t < pl[1]) if t < 1760 else len(PLANOS) - 1
    pl = PLANOS[k]
    im = Image.new('RGB', (W, H), tuple(int(c * 0.55) for c in COLOR[k]))
    d = ImageDraw.Draw(im)
    # degradado suave
    top = Image.new('RGB', (W, H), tuple(int(c * 0.9) for c in COLOR[k]))
    m = Image.linear_gradient('L').resize((W, H))
    im = Image.composite(im, top, m)
    d = ImageDraw.Draw(im)
    if k != 18:
        d.text((40, 90), f"{k + 1} · {pl[2]}", font=f_big, fill=(240, 236, 228))
        d.text((40, 132), pl[3], font=f_small, fill=(220, 214, 206))
        s0 = pl[0] / 20; s1 = pl[1] / 20
        d.text((40, 160), f"{int(s0 // 60)}:{s0 % 60:04.1f} – {int(s1 // 60)}:{s1 % 60:04.1f}", font=f_small, fill=(200, 196, 190))
        prog = (t - pl[0]) / (pl[1] - pl[0])
        d.rectangle((40, 186, 40 + int(300 * prog), 189), fill=(255, 95, 168))
    im = im.convert('RGBA')
    if False:
        sil = Image.new('RGBA', (W, H), (232, 120, 70, 255))
        ds = ImageDraw.Draw(sil); ds.ellipse((330, 150, 630, 520), fill=(0, 0, 0, 255)); ds.rectangle((0, 400, W, H), fill=(20, 20, 30, 255))
        im = sil
    if 1480 <= t < 1620:
        ov = Image.new('RGBA', (W, H), (2, 14, 20, int(255 * alfa(t, 1480, 1620, 0, 0, 0.62))))
        im.alpha_composite(ov)
    for name, (img, cx, cy, t0, t1, i, o, sub) in IMG.items():
        a = alfa(t, t0, t1, i, o)
        if a <= 0.003: continue
        pe = 1 if i <= 0 else max(0, min(1, (t - t0) / i))
        layer = img.copy(); layer.putalpha(layer.split()[3].point(lambda v: int(v * a)))
        x = int(cx * W / 1920 - layer.width / 2); y = int((cy + sub * (1 - pe)) * H / 1080 - layer.height / 2)
        im.alpha_composite(layer, (x, y))
    for col, mx, t0, t1, o in COLORES:
        a = alfa(t, t0, t1, 0, o, mx)
        if a > 0: im.alpha_composite(Image.new('RGBA', (W, H), (*col, int(255 * a))))
    for t0, t1, i, o in NEGROS:
        a = alfa(t, t0, t1, i, o)
        if a > 0: im.alpha_composite(Image.new('RGBA', (W, H), (0, 0, 0, int(255 * a))))
    hb = int(H * 0.125)
    d = ImageDraw.Draw(im); d.rectangle((0, 0, W, hb), fill=(0, 0, 0)); d.rectangle((0, H - hb, W, H), fill=(0, 0, 0))
    proc.stdin.write(im.convert('RGB').tobytes())
proc.stdin.close(); proc.wait()
print('animatic', n, 'frames')
