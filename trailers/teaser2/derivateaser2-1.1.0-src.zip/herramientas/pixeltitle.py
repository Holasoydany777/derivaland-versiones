import numpy as np, random
from PIL import Image
G={
'V':["XX...XX","XX...XX","XX...XX","XX...XX","XX...XX",".XX.XX.",".XX.XX.","..XXX..","...X..."],
'E':["XXXXXXX","XXXXXXX","XX.....","XXXXXX.","XXXXXX.","XX.....","XX.....","XXXXXXX","XXXXXXX"],
'R':["XXXXXX.","XXXXXXX","XX...XX","XX...XX","XXXXXXX","XXXXXX.","XX..XX.","XX...XX","XX...XX"],
'A':[".XXXXX.","XXXXXXX","XX...XX","XX...XX","XXXXXXX","XXXXXXX","XX...XX","XX...XX","XX...XX"],
'N':["XX...XX","XXX..XX","XXXX.XX","XXXXXXX","XX.XXXX","XX..XXX","XX...XX","XX...XX","XX...XX"],
'O':[".XXXXX.","XXXXXXX","XX...XX","XX...XX","XX...XX","XX...XX","XX...XX","XXXXXXX",".XXXXX."],
'2':["XXXXXX.","XXXXXXX",".....XX",".....XX",".XXXXXX","XXXXXX.","XX.....","XXXXXXX","XXXXXXX"],
'0':[".XXXXX.","XXXXXXX","XX...XX","XX..XXX","XX.X.XX","XXX..XX","XX...XX","XXXXXXX",".XXXXX."],
'7':["XXXXXXX","XXXXXXX",".....XX","....XX.","...XX..","..XX...","..XX...","..XX...","..XX..."],
}
SAND=[(232,220,192),(222,208,176),(240,232,212),(214,200,168)]
SANDSH=(116,100,92); SANDSH2=(92,78,74)
WAT=[(58,168,184),(52,156,174),(66,178,192)]
WATL=(111,214,220); WATD=(36,126,148); FOAM=(214,240,236)
EXW=(28,86,106); EXW2=(22,70,90)
PINK=(255,79,168); OUT=(40,22,44)
def glyph(ch,cell=4,depth=6,seed=0,cracks=True):
    rnd=random.Random(seed)
    b=G[ch]; h=len(b)*cell; w=len(b[0])*cell
    M=np.zeros((h,w),bool)
    for j,row in enumerate(b):
        for i,c in enumerate(row):
            if c=='X': M[j*cell:(j+1)*cell,i*cell:(i+1)*cell]=True
    # chamfer convex corners
    M2=M.copy()
    for y in range(h):
        for x in range(w):
            if not M[y,x]: continue
            up=y>0 and M[y-1,x]; dn=y<h-1 and M[y+1,x]; lf=x>0 and M[y,x-1]; rt=x<w-1 and M[y,x+1]
            if ((not up and not lf) or (not up and not rt) or (not dn and not lf) or (not dn and not rt)) and (x%cell in (0,cell-1)) and (y%cell in (0,cell-1)): M2[y,x]=False
    M=M2
    P=2; H=h+depth+2*P; W=w+2*P
    face=np.zeros((H,W),bool); face[P:P+h,P:P+w]=M
    ext=np.zeros((H,W),bool)
    for d in range(1,depth+1):
        ext[d:,:]|=face[:-d,:]
    ext&=~face
    img=np.zeros((H,W,4),np.uint8)
    wl=[int(h*0.48)+rnd.choice([-1,0,0,1]) for _ in range(W)]
    for x in range(1,W): 
        if abs(wl[x]-wl[x-1])>1: wl[x]=wl[x-1]+np.sign(wl[x]-wl[x-1])
    for y in range(H):
        for x in range(W):
            yy=y-P
            if face[y,x]:
                if yy<wl[x]:
                    c=rnd.choice(SAND) if rnd.random()<0.25 else SAND[0]
                    if yy==wl[x]-1: c=FOAM
                else:
                    c=WAT[0] if rnd.random()>0.2 else rnd.choice(WAT)
                    if rnd.random()<0.06: c=WATL
                    if yy>h-4: c=WATD
                img[y,x]=(*c,255)
            elif ext[y,x]:
                # what's above on the face column decides sand/water extrusion
                yy2=yy
                c=SANDSH if yy2<wl[x]+2 else EXW
                if rnd.random()<0.15: c=SANDSH2 if c==SANDSH else EXW2
                img[y,x]=(*c,255)
    if cracks:
        for _ in range(rnd.randint(2,3)):
            x=rnd.randrange(P+2,P+w-2); y=wl[x]+P+rnd.randint(2,5); L=rnd.randint(6,12)
            for k in range(L):
                if 0<=y<H and 0<=x<W and face[y,x] and y-P>=wl[x]: img[y,x]=(*PINK,255)
                y+=1; x+=rnd.choice([-1,0,0,1])
    # outline
    sol=face|ext
    out=np.zeros_like(sol)
    for dy in (-1,0,1):
        for dx in (-1,0,1):
            out|=np.roll(np.roll(sol,dy,0),dx,1)
    out&=~sol
    img[out]=(*OUT,255)
    return img
def word(s,cell=4,depth=6,gap=4,seed=1):
    gs=[glyph(c,cell,depth,seed+i) if c!=' ' else None for i,c in enumerate(s)]
    H=max(g.shape[0] for g in gs if g is not None)
    W=sum((g.shape[1] if g is not None else cell*3) for g in gs)+gap*(len(s)-1)
    im=np.zeros((H,W,4),np.uint8); x=0
    for g in gs:
        if g is None: x+=cell*3+gap; continue
        im[:g.shape[0],x:x+g.shape[1]]=np.maximum(im[:g.shape[0],x:x+g.shape[1]],g); x+=g.shape[1]+gap
    return im
if __name__=='__main__':
    import sys
    out=sys.argv[1]
    v=word("VERANO",seed=3); y=word("2027",seed=11)
    vs,ys=5,5
    V=Image.fromarray(v).resize((v.shape[1]*vs,v.shape[0]*vs),Image.NEAREST)
    Y=Image.fromarray(y).resize((y.shape[1]*ys,y.shape[0]*ys),Image.NEAREST)
    W=max(V.width,Y.width); H=V.height+Y.height+24
    im=Image.new('RGBA',(W,H),(0,0,0,0))
    im.alpha_composite(V,((W-V.width)//2,0)); im.alpha_composite(Y,((W-Y.width)//2,V.height+24))
    im.save(out); print(im.size, V.size, Y.size)
