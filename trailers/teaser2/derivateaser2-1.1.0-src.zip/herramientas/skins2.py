"""Skins del pueblo de Derivaland, versión 2 (64x64, brazos anchos). Hechas desde cero.

Más detalle que la v1: sombreado por cara (arriba claro, abajo oscuro, laterales y espalda más oscuros),
pelo con mechones y volumen en la capa exterior, ojos de dos filas con pestañas, nariz, boca con labios,
orejas, cuello, ropa con cuello, botones, costuras, pliegues, cinturón con hebilla y zapatos con suela.
Infectados: piel enferma, venas rosas, costras de coral en tres tonos, ropa rota y ramas de coral en relieve.

Uso: python3 skins2.py <carpeta_salida> [<preview.png>]
"""
import random, sys, os, colorsys
from PIL import Image, ImageDraw

BOX = {  # (base uv, capa exterior uv, w, h, d)
    'head': ((0, 0), (32, 0), 8, 8, 8),
    'body': ((16, 16), (16, 32), 8, 12, 4),
    'rarm': ((40, 16), (40, 32), 4, 12, 4),
    'larm': ((32, 48), (48, 48), 4, 12, 4),
    'rleg': ((0, 16), (0, 32), 4, 12, 4),
    'lleg': ((16, 48), (0, 48), 4, 12, 4),
}
SIDES = ('top', 'bottom', 'right', 'front', 'left', 'back')


def faces(u, v, w, h, d):
    return {'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d), 'right': (u, v + d, d, h),
            'front': (u + d, v + d, w, h), 'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h)}


def cl(c): return tuple(max(0, min(255, int(round(x)))) for x in c[:3])
def mul(c, k): return cl([x * k for x in c])
def mix(a, b, t): return cl([a[i] + (b[i] - a[i]) * t for i in range(3)])
def hsv(c, dh=0, ds=0, dv=0):
    h, s, v = colorsys.rgb_to_hsv(*[x / 255 for x in c])
    return cl([x * 255 for x in colorsys.hsv_to_rgb((h + dh) % 1, max(0, min(1, s + ds)), max(0, min(1, v + dv)))])


# luz: cuánto se oscurece cada cara
LUZ = {'top': 1.10, 'front': 1.0, 'right': 0.86, 'left': 0.86, 'back': 0.80, 'bottom': 0.62}


class Skin:
    def __init__(self, seed):
        self.im = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        self.px = self.im.load()
        self.r = random.Random(seed)

    def face(self, part, side, layer=0):
        base, over, w, h, d = BOX[part]
        u, v = base if layer == 0 else over
        return faces(u, v, w, h, d)[side]

    def put(self, part, side, x, y, c, layer=0, sombra=True):
        fx, fy, fw, fh = self.face(part, side, layer)
        if not (0 <= x < fw and 0 <= y < fh): return
        if c is None:
            self.px[fx + x, fy + y] = (0, 0, 0, 0); return
        if sombra:
            c = mul(c, LUZ[side])
        self.px[fx + x, fy + y] = (*cl(c), 255)

    def get(self, part, side, x, y, layer=0):
        fx, fy, fw, fh = self.face(part, side, layer)
        return self.px[fx + x, fy + y]

    def dims(self, part, side):
        return self.face(part, side)[2:]

    def pintar(self, part, color, layer=0, sides=SIDES, rows=None, grano=5, grad=0.10, dither=True):
        """Rellena con degradado vertical (arriba más claro) y grano."""
        for side in sides:
            fw, fh = self.dims(part, side)
            for y in range(fh):
                if rows and side not in ('top', 'bottom') and not (rows[0] <= y < rows[1]): continue
                if rows and side == 'top' and rows[0] > 0: continue
                if rows and side == 'bottom' and rows[1] < fh: continue
                k = 1 + grad * (0.5 - y / max(1, fh - 1)) if side not in ('top', 'bottom') else 1
                for x in range(fw):
                    n = self.r.randint(-grano, grano) if dither else 0
                    # bordes laterales un pelín más oscuros (volumen)
                    borde = 0.95 if side in ('front', 'back') and (x == 0 or x == fw - 1) else 1
                    self.put(part, side, x, y, [ch * k * borde + n for ch in color], layer)


# ------------------------------------------------------------------ piezas
def pelo(s, p):
    c = p['pelo']; claro = hsv(c, dv=0.10); oscuro = mul(c, 0.72)
    largo = p.get('largo', 'corto')
    # base: arriba, detrás y lados
    for side in ('top', 'back', 'right', 'left', 'front'):
        fw, fh = s.dims('head', side)
        for y in range(fh):
            for x in range(fw):
                if side == 'top': on = True
                elif side == 'back': on = y < (8 if largo != 'calvo' else 3)
                elif side in ('right', 'left'):
                    lim = {'corto': 3, 'medio': 5, 'largo': 8, 'calvo': 2}[largo]
                    # el pelo baja más por detrás que por delante (patilla)
                    atras = x < 3 if side == 'right' else x > 4
                    on = y < lim or (atras and y < lim + 2)
                    if side == 'right' and x > 5 and y > 1: on = on and y < 2
                    if side == 'left' and x < 2 and y > 1: on = on and y < 2
                else:  # flequillo
                    fl = p.get('flequillo', [2, 2, 1, 1, 1, 1, 2, 2])
                    on = y < fl[x]
                if not on: continue
                # mechones: rayas verticales alternas
                tono = claro if (x + (y // 3)) % 3 == 0 else (oscuro if (x * 7 + y) % 5 == 0 else c)
                if side == 'top' and (x + y) % 4 == 0: tono = claro
                s.put('head', side, x, y, tono)
    # volumen en la capa exterior: bordes con mechones sueltos
    for side in ('right', 'left', 'back', 'front'):
        fw, fh = s.dims('head', side)
        for x in range(fw):
            if side == 'front':
                if p.get('flequillo_ext') and x in p['flequillo_ext']:
                    s.put('head', side, x, p['flequillo'][x], oscuro, layer=1)
                continue
            if s.r.random() < 0.55:
                y = 0 if side != 'back' else s.r.choice((0, 7 if largo == 'largo' else 0))
                s.put('head', side, x, y, claro if s.r.random() < 0.4 else c, layer=1)
    if largo == 'largo':
        # melena que cae por la espalda (capa exterior del cuerpo)
        for y in range(0, p.get('melena_y', 5)):
            for x in range(8):
                if y == p.get('melena_y', 5) - 1 and x % 2: continue
                s.put('body', 'back', x, y, claro if (x + y) % 3 == 0 else c, layer=1)
    if p.get('coletas'):
        for side, xs in (('right', (2, 3)), ('left', (4, 5))):
            for y in range(4, 8):
                for x in xs: s.put('head', side, x, y, c if y % 2 else claro, layer=1)
        for y in range(0, 3):
            for x in (0, 3):
                s.put('rarm' if x == 0 else 'larm', 'top', x if x == 0 else 3, y, c, layer=1)
    if p.get('mono'):  # moño
        for x in range(2, 6):
            for y in range(0, 3): s.put('head', 'back', x, y, claro if (x + y) % 2 else c, layer=1)


def cara(s, p):
    piel = p['piel']; oy = p.get('ojos_y', 4)
    blanco = (240, 238, 232); iris = p.get('ojo', (70, 110, 160)); pupila = mul(iris, 0.45)
    ceja = mul(p['pelo'], 0.8) if p.get('largo') != 'calvo' else mul(p.get('barba', p['pelo']), 0.85)
    # sombra bajo el flequillo
    for x in range(8):
        fl = p.get('flequillo', [2, 2, 1, 1, 1, 1, 2, 2])[x]
        if fl < 8: s.put('head', 'front', x, fl, mul(piel, 0.88))
    # ojos (dos filas: pestaña arriba, blanco + iris abajo)
    for x0, lado in ((1, 0), (5, 1)):
        s.put('head', 'front', x0, oy, blanco if lado == 0 else iris)
        s.put('head', 'front', x0 + 1, oy, iris if lado == 0 else blanco)
        s.put('head', 'front', x0 + (1 if lado == 0 else 0), oy, iris)
        s.put('head', 'front', x0 + (0 if lado == 0 else 1), oy, blanco)
        s.put('head', 'front', x0 + (1 if lado == 0 else 0), oy - 1 + 1, iris)
        if p.get('pestanas', False):
            s.put('head', 'front', x0 + (0 if lado == 0 else 1), oy - 1, mul(p['pelo'], 0.6))
        # brillo en el iris
    s.put('head', 'front', 2, oy, mul(iris, 1.15)); s.put('head', 'front', 5, oy, mul(iris, 1.15))
    s.put('head', 'front', 2, oy + 1 if False else oy, iris)
    # cejas
    if p.get('cejas', True):
        for x in (1, 2): s.put('head', 'front', x, oy - 1, ceja)
        for x in (5, 6): s.put('head', 'front', x, oy - 1, ceja)
    # nariz: sombra de dos píxeles
    s.put('head', 'front', 3, oy + 1, mul(piel, 0.86)); s.put('head', 'front', 4, oy + 1, mul(piel, 0.80))
    # boca
    labio = p.get('labio', mix(piel, (190, 80, 80), 0.35))
    if p.get('sonrisa', True):
        s.put('head', 'front', 2, oy + 2, mul(piel, 0.85)); s.put('head', 'front', 5, oy + 2, mul(piel, 0.85))
        s.put('head', 'front', 3, oy + 3 if oy < 4 else oy + 2, labio); s.put('head', 'front', 4, oy + 3 if oy < 4 else oy + 2, labio)
    else:
        s.put('head', 'front', 3, oy + 2, labio); s.put('head', 'front', 4, oy + 2, labio)
    if p.get('mejillas'):
        rubor = mix(piel, (235, 120, 125), 0.35)
        s.put('head', 'front', 1, oy + 1, rubor); s.put('head', 'front', 6, oy + 1, rubor)
    # barbilla y mandíbula algo más oscuras
    for x in range(8): s.put('head', 'front', x, 7, mul(piel, 0.93))
    # orejas
    for side, xo in (('right', 4), ('left', 3)):
        s.put('head', side, xo, oy, mul(piel, 0.9)); s.put('head', side, xo, oy + 1, mul(piel, 0.82))
    if p.get('barba'):
        b = p['barba']; bc = hsv(b, dv=0.08)
        for y in range(oy + 1, 8):
            for x in range(8):
                if y == oy + 1 and 2 <= x <= 5: continue                 # bigote aparte
                if y == oy + 2 and x in (3, 4): s.put('head', 'front', x, y, mul(piel, 0.6)); continue
                s.put('head', 'front', x, y, bc if (x + y) % 3 == 0 else b)
        for x in range(2, 6): s.put('head', 'front', x, oy + 1 if x in (2, 5) else oy + 1, b)
        for side in ('right', 'left'):
            for y in range(oy, 8):
                for x in range(8):
                    if (side == 'right' and x > 4) or (side == 'left' and x < 3): s.put('head', side, x, y, b)
        for x in range(8): s.put('head', 'bottom', x, 7, b)
    if p.get('gafas'):
        g = p['gafas']
        for x in (0, 1, 2, 3, 4, 5, 6, 7):
            if x in (0, 3, 4, 7): s.put('head', 'front', x, oy, g, layer=1, sombra=False)
        for x in (1, 2, 5, 6): s.put('head', 'front', x, oy - 1, g, layer=1, sombra=False)


def cuerpo(s, p):
    piel = p['piel']; cam = p['camisa']; pan = p['pantalon']; zap = p['zapato']
    s.pintar('head', piel, sides=('front', 'right', 'left', 'back', 'bottom', 'top'), grad=0.06, grano=3)
    s.pintar('body', cam)
    manga = p.get('manga', 4)
    for arm in ('rarm', 'larm'):
        s.pintar(arm, piel, grano=3)
        s.pintar(arm, cam, rows=(0, manga))
        if manga < 12:  # puño de la manga
            for side in ('right', 'front', 'left', 'back'):
                for x in range(4): s.put(arm, side, x, manga - 1, mul(cam, 0.82))
        # mano algo más oscura abajo
        for side in ('right', 'front', 'left', 'back'):
            for x in range(4): s.put(arm, side, x, 11, mul(piel, 0.88))
    for leg in ('rleg', 'lleg'):
        s.pintar(leg, pan)
        # rodilla
        for x in (1, 2): s.put(leg, 'front', x, 6, mul(pan, 0.9))
        # zapato con suela
        for side in ('right', 'front', 'left', 'back'):
            for x in range(4):
                s.put(leg, side, x, 10, zap); s.put(leg, side, x, 11, mul(zap, 0.6))
        s.pintar(leg, mul(zap, 0.55), sides=('bottom',), grano=2)
        # costura del pantalón
        s.put(leg, 'right' if leg == 'rleg' else 'left', 2, 3, mul(pan, 0.88)); s.put(leg, 'right' if leg == 'rleg' else 'left', 2, 7, mul(pan, 0.88))
    # cuello de la camisa y sombra del cuello
    for x in (2, 3, 4, 5): s.put('body', 'front', x, 0, mul(piel, 0.85) if x in (3, 4) else mul(cam, 0.85))
    s.put('body', 'front', 3, 1, mul(piel, 0.9)) if p.get('escote') else None
    # pliegues
    for y in (5, 9):
        s.put('body', 'front', 1, y, mul(cam, 0.9)); s.put('body', 'front', 6, y + 1, mul(cam, 0.9))
    if p.get('botones'):
        for y in (2, 4, 6): s.put('body', 'front', 4, y, p['botones'])
        for y in range(1, 8): s.put('body', 'front', 3, y, mul(cam, 0.88))
    if p.get('cinturon'):
        cb = p['cinturon']
        for side in ('right', 'front', 'left', 'back'):
            fw, _ = s.dims('body', side)
            for x in range(fw): s.put('body', side, x, 8, cb)
        s.put('body', 'front', 3, 8, (210, 180, 90)); s.put('body', 'front', 4, 8, (180, 150, 70))
    if p.get('vestido'):
        vc = p['vestido']; fal = p.get('falda', 7)
        for leg in ('rleg', 'lleg'):
            s.pintar(leg, vc, rows=(0, fal))
            for side in ('right', 'front', 'left', 'back'):
                for x in range(4): s.put(leg, side, x, fal - 1, mul(vc, 0.8))
            s.pintar(leg, mul(piel, 0.97), rows=(fal, 10), grano=2)
        # vuelo de la falda en la capa exterior
        for leg in ('rleg', 'lleg'):
            for side in ('right', 'front', 'left', 'back'):
                for x in range(4):
                    for y in range(0, fal):
                        if y >= fal - 2: s.put(leg, side, x, y, mul(vc, 0.9 if (x + y) % 2 else 1.0), layer=1)
    if p.get('delantal'):
        dc = p['delantal']
        for y in range(3, 12):
            for x in range(1, 7): s.put('body', 'front', x, y, dc if (x + y) % 6 else mul(dc, 0.93))
        for x in (1, 6): s.put('body', 'front', x, 2, dc)
        for y in (2, 3): s.put('body', 'back', 3, y + 4, mul(dc, 0.9)); s.put('body', 'back', 4, y + 4, mul(dc, 0.9))
        for x in range(2, 6): s.put('body', 'front', x, 7, mul(dc, 0.85))   # bolsillo
        for leg, xs in (('rleg', range(1, 4)), ('lleg', range(0, 3))):
            for y in range(0, 5):
                for x in xs: s.put(leg, 'front', x, y, dc if y < 4 else mul(dc, 0.88))
    if p.get('peto'):  # peto con tirantes (granjero)
        tc = p['peto']
        for side in ('right', 'front', 'left', 'back'):
            fw, _ = s.dims('body', side)
            for y in range(6, 12):
                for x in range(fw): s.put('body', side, x, y, tc)
        for y in range(2, 6):
            for x in range(2, 6): s.put('body', 'front', x, y, tc)
        for y in range(0, 6):
            for x in (1, 6): s.put('body', 'front', x, y, mul(tc, 0.92)); s.put('body', 'back', x, y, mul(tc, 0.92))
        s.put('body', 'front', 2, 2, (200, 180, 110)); s.put('body', 'front', 5, 2, (200, 180, 110))
        for leg in ('rleg', 'lleg'): s.pintar(leg, tc, rows=(0, 10))
        for x in range(3, 5): s.put('body', 'front', x, 4, mul(tc, 0.8))   # bolsillo del peto
    if p.get('rayas'):
        rc = p['rayas']
        for y in range(1, 12, 3):
            for side in ('right', 'front', 'left', 'back'):
                fw, _ = s.dims('body', side)
                for x in range(fw): s.put('body', side, x, y, rc)
            for arm in ('rarm', 'larm'):
                if y < manga:
                    for side in ('right', 'front', 'left', 'back'):
                        for x in range(4): s.put(arm, side, x, y, rc)
    if p.get('chaqueta'):
        cc = p['chaqueta']
        s.pintar('body', cc, layer=1, sides=('right', 'left', 'back', 'top'))
        for y in range(12):
            for x in (0, 1, 6, 7): s.put('body', 'front', x, y, cc if x in (0, 7) else mul(cc, 0.9), layer=1)
        for y in (3, 6, 9): s.put('body', 'front', 1, y, (220, 210, 190), layer=1)
        for arm in ('rarm', 'larm'):
            s.pintar(arm, cc, layer=1)
            for side in ('right', 'front', 'left', 'back'):
                for x in range(4): s.put(arm, side, x, 11, None, layer=1); s.put(arm, side, x, 10, mul(cc, 0.8), layer=1)
            s.pintar(arm, cc, layer=1, sides=('top',))
            fx, fy, fw, fh = s.face(arm, 'bottom', 1)
            for yy in range(fh):
                for xx in range(fw): s.px[fx + xx, fy + yy] = (0, 0, 0, 0)
        # cuello de la chaqueta
        for x in (1, 2, 5, 6): s.put('body', 'front', x, 0, mul(cc, 0.85), layer=1)
    if p.get('chaleco'):
        cc = p['chaleco']
        for y in range(12):
            for x in (0, 1, 2, 5, 6, 7):
                if y > 9 and x in (2, 5): continue
                s.put('body', 'front', x, y, cc)
            for side in ('right', 'left', 'back'):
                fw, _ = s.dims('body', side)
                for x in range(fw): s.put('body', side, x, y, cc)
    if p.get('sombrero'):
        hc = p['sombrero']; banda = p.get('banda', mul(hc, 0.55))
        s.pintar('head', hc, layer=1, sides=('top',), grano=6)
        for side in ('right', 'front', 'left', 'back'):
            fw, _ = s.dims('head', side)
            for x in range(fw):
                s.put('head', side, x, 0, hsv(hc, dv=0.05), layer=1)
                s.put('head', side, x, 1, banda, layer=1)
                s.put('head', side, x, 2, mul(hc, 0.85) if p.get('ala', True) else None, layer=1)
    if p.get('panuelo'):
        pc = p['panuelo']; motivo = p.get('motivo', (240, 240, 230))
        s.pintar('head', pc, layer=1, sides=('top',), grano=3)
        for side in ('right', 'front', 'left', 'back'):
            fw, _ = s.dims('head', side)
            for x in range(fw):
                for y in range(0, 2 if side == 'front' else 4):
                    s.put('head', side, x, y, motivo if (x * 3 + y * 5) % 9 == 0 else pc, layer=1)
        for x in (3, 4): s.put('head', 'back', x, 4, pc, layer=1); s.put('head', 'back', x, 5, mul(pc, 0.85), layer=1)
    if p.get('bufanda'):
        bc = p['bufanda']
        for side in ('right', 'front', 'left', 'back'):
            fw, _ = s.dims('body', side)
            for x in range(fw):
                s.put('body', side, x, 0, bc, layer=1); s.put('body', side, x, 1, mul(bc, 0.85) if x % 2 else bc, layer=1)
        for y in range(2, 6): s.put('body', 'front', 5, y, bc if y % 2 else mul(bc, 0.85), layer=1)
    if p.get('mochila'):
        mc = p['mochila']
        for y in range(1, 9):
            for x in range(1, 7): s.put('body', 'back', x, y, mc if (x + y) % 5 else mul(mc, 0.85), layer=1)
        for y in range(0, 7): s.put('body', 'front', 1, y, mul(mc, 0.8), layer=1); s.put('body', 'front', 6, y, mul(mc, 0.8), layer=1)


def persona(p):
    s = Skin(p['seed'])
    cuerpo(s, p)
    pelo(s, p)
    cara(s, p)
    return s.im


# ------------------------------------------------------------------ coralosis
CORAL = [(255, 98, 172), (255, 140, 196), (226, 58, 140), (255, 178, 214), (196, 40, 110)]


def infectar(im, seed):
    r = random.Random(seed)
    out = im.copy(); px = out.load(); src = im.load()
    s = Skin(0); s.im, s.px = out, px
    # 1. todo pierde color y vira a un gris verdoso, enfermo
    for y in range(64):
        for x in range(64):
            c = src[x, y]
            if c[3] == 0: continue
            g = (c[0] * 30 + c[1] * 59 + c[2] * 11) / 100
            nc = mix(c[:3], (g * 0.92, g * 1.02, g * 0.96), 0.62)
            px[x, y] = (*mul(nc, 0.84), c[3])
    # 2. venas rosas que suben por brazos, cuello y cara
    def vena(part, side, x, y, largo):
        for _ in range(largo):
            fw, fh = s.dims(part, side)
            if 0 <= x < fw and 0 <= y < fh:
                col = s.get(part, side, x, y)
                if col[3]: s.put(part, side, x, y, mix(col[:3], (240, 70, 150), 0.65), sombra=False)
            y -= 1; x += r.choice((-1, 0, 0, 1))
    for arm in ('rarm', 'larm'):
        for side in ('front', 'right', 'left'):
            vena(arm, side, r.randrange(4), 11, r.randint(5, 9))
    vena('head', 'right', 5, 7, 4); vena('head', 'front', 0, 7, 3); vena('body', 'front', 3, 3, 4)
    # 3. costras de coral (racimos con luz y sombra)
    def costra(part, side, cx, cy, n, layer=0):
        for _ in range(n):
            x, y = cx + r.randint(-2, 2), cy + r.randint(-2, 2)
            fw, fh = s.dims(part, side)
            if not (0 <= x < fw and 0 <= y < fh): continue
            if part == 'head' and side == 'front' and 3 <= y <= 6 and 1 <= x <= 6 and layer == 0: continue
            k = r.random()
            col = CORAL[3] if k < 0.2 else (CORAL[0] if k < 0.6 else (CORAL[2] if k < 0.85 else CORAL[4]))
            s.put(part, side, x, y, col, layer=layer, sombra=False)
    for part, side, n in (('head', 'right', 12), ('head', 'back', 14), ('head', 'top', 10), ('body', 'front', 12), ('body', 'back', 16),
                          ('rarm', 'right', 10), ('larm', 'left', 8), ('rleg', 'front', 6), ('lleg', 'left', 6)):
        fw, fh = s.dims(part, side)
        costra(part, side, r.randrange(fw), r.randrange(fh), n)
    # 4. ropa rota: agujeros en la capa exterior y desgarrones en la base
    for part in ('body', 'rarm', 'larm', 'rleg', 'lleg'):
        for side in ('front', 'back', 'right', 'left'):
            fw, fh = s.dims(part, side)
            for _ in range(2):
                x, y = r.randrange(fw), r.randrange(fh)
                fx, fy, _, _ = s.face(part, side, 1)
                px[fx + x, fy + y] = (0, 0, 0, 0)
    # 5. ojos: blanco rosado e iris rosa brillante, con una sombra rosada debajo
    fx, fy, fw, fh = s.face('head', 'front')
    for x, c in ((1, (255, 200, 228)), (2, (255, 38, 160)), (5, (255, 38, 160)), (6, (255, 200, 228))):
        px[fx + x, fy + 4] = (*c, 255)
    for x in (1, 2, 5, 6):
        c = px[fx + x, fy + 5]
        if c[3]: px[fx + x, fy + 5] = (*mix(c[:3], (150, 40, 90), 0.35), 255)
    # 6. ramas de coral en relieve (capa exterior de la cabeza y hombros)
    def rama(part, side, x, y, alto, layer=1):
        col = r.choice(CORAL[:3])
        for k in range(alto):
            s.put(part, side, x, y - k if side != 'top' else y, hsv(col, dv=0.06 * (k % 2)), layer=layer, sombra=False)
            if side == 'top': y += r.choice((-1, 1))
            if k == alto // 2:
                s.put(part, side, x + r.choice((-1, 1)), y - k, CORAL[3], layer=layer, sombra=False)
            x += r.choice((-1, 0, 0, 1))
    for side in ('right', 'left', 'back'):
        for _ in range(3): rama('head', side, r.randrange(8), r.randint(2, 5), r.randint(3, 5))
    for _ in range(5):
        x, y = r.randrange(8), r.randrange(8)
        s.put('head', 'top', x, y, r.choice(CORAL[:4]), layer=1, sombra=False)
    for arm in ('rarm', 'larm'):
        fx, fy, fw, fh = s.face(arm, 'top', 1)
        for _ in range(3): px[fx + r.randrange(fw), fy + r.randrange(fh)] = (*r.choice(CORAL), 255)
        rama(arm, 'right' if arm == 'rarm' else 'left', r.randrange(4), r.randint(4, 9), 3)
    return out


# ------------------------------------------------------------------ el reparto
FLQ_RECTO = [2, 2, 2, 2, 2, 2, 2, 2]
FLQ_LADO = [3, 3, 2, 2, 1, 1, 1, 2]
FLQ_ABIERTO = [3, 2, 1, 0, 0, 1, 2, 3]
FLQ_NINO = [3, 2, 3, 2, 2, 3, 2, 3]
REPARTO = {
    'marta': dict(seed=1, piel=(226, 178, 140), pelo=(104, 60, 34), largo='largo', melena_y=6, flequillo=FLQ_ABIERTO,
                  camisa=(186, 58, 54), pantalon=(150, 46, 42), zapato=(70, 44, 30), vestido=(186, 58, 54), falda=8,
                  delantal=(240, 234, 218), mejillas=True, manga=3, ojo=(80, 120, 70), pestanas=True),
    'tomas': dict(seed=2, piel=(206, 152, 112), pelo=(84, 58, 36), largo='corto', flequillo=FLQ_RECTO, camisa=(110, 150, 84),
                  pantalon=(96, 74, 52), zapato=(58, 40, 28), barba=(92, 64, 40), peto=(70, 92, 140), sombrero=(226, 196, 120),
                  banda=(150, 60, 50), manga=4, ojo=(70, 90, 60), sonrisa=True),
    'elias': dict(seed=3, piel=(230, 190, 156), pelo=(218, 218, 214), largo='calvo', flequillo=[1, 1, 0, 0, 0, 0, 1, 1],
                  camisa=(206, 200, 186), pantalon=(86, 80, 76), zapato=(46, 36, 32), barba=(232, 232, 228), chaqueta=(116, 86, 62),
                  botones=(80, 60, 40), manga=12, ojo=(90, 120, 160), gafas=(60, 50, 40), sonrisa=True),
    'lucia': dict(seed=4, piel=(150, 100, 68), pelo=(34, 24, 20), largo='medio', mono=True, flequillo=FLQ_LADO,
                  panuelo=(232, 196, 64), motivo=(214, 80, 60), camisa=(240, 240, 236), rayas=(44, 74, 146),
                  pantalon=(50, 64, 100), zapato=(40, 32, 28), manga=6, ojo=(70, 46, 32), mejillas=True, pestanas=True),
    'iker': dict(seed=5, piel=(236, 200, 166), pelo=(230, 196, 104), largo='corto', flequillo=FLQ_LADO, flequillo_ext=[0, 1],
                 camisa=(222, 136, 58), pantalon=(72, 86, 116), zapato=(78, 56, 42), cinturon=(84, 58, 38), manga=5,
                 ojo=(70, 124, 176), chaleco=(92, 66, 46)),
    'rosa': dict(seed=6, piel=(184, 130, 94), pelo=(128, 42, 36), largo='largo', melena_y=5, flequillo=FLQ_RECTO,
                 camisa=(94, 126, 178), pantalon=(94, 126, 178), zapato=(76, 52, 40), vestido=(94, 126, 178), falda=9, manga=3,
                 bufanda=(232, 220, 196), ojo=(56, 90, 66), pestanas=True),
    'nico': dict(seed=11, piel=(230, 186, 148), pelo=(118, 74, 42), largo='corto', flequillo=FLQ_NINO, flequillo_ext=[0, 3, 6],
                 camisa=(214, 60, 54), pantalon=(64, 86, 136), zapato=(236, 236, 236), manga=3, mejillas=True, ojo=(64, 104, 168),
                 mochila=(232, 168, 60)),
    'vega': dict(seed=12, piel=(206, 154, 114), pelo=(44, 30, 24), largo='medio', coletas=True, flequillo=FLQ_RECTO,
                 camisa=(244, 204, 66), vestido=(244, 204, 66), falda=6, pantalon=(244, 204, 66), zapato=(204, 74, 94), manga=2,
                 mejillas=True, ojo=(60, 40, 30), pestanas=True),
    'pablo': dict(seed=13, piel=(156, 108, 78), pelo=(28, 22, 18), largo='corto', flequillo=FLQ_NINO, camisa=(64, 156, 206),
                  pantalon=(156, 124, 84), zapato=(94, 64, 44), manga=3, mejillas=True, ojo=(52, 38, 28), rayas=(240, 240, 236)),
}


def vista(im, escala=8):
    def cut(part, side, layer=0):
        base, over, w, h, d = BOX[part]
        u, v = base if layer == 0 else over
        fx, fy, fw, fh = faces(u, v, w, h, d)[side]
        return im.crop((fx, fy, fx + fw, fy + fh))
    out = Image.new('RGBA', (16 * 2 + 4, 34), (0, 0, 0, 0))
    for k, side in ((0, 'front'), (1, 'back')):
        ox = k * 20
        def paste(part, x, y):
            out.alpha_composite(cut(part, side), (ox + x, y + 1))
            out.alpha_composite(cut(part, side, 1), (ox + x, y + 1))
        paste('head', 4, 0); paste('body', 4, 8)
        paste('rarm' if k == 0 else 'larm', 0, 8); paste('larm' if k == 0 else 'rarm', 12, 8)
        paste('rleg' if k == 0 else 'lleg', 4, 20); paste('lleg' if k == 0 else 'rleg', 8, 20)
    return out.resize((out.width * escala, out.height * escala), Image.NEAREST)


def mezcla_giro(sano, inf):
    """Por detrás sano y por delante infectado: al girarse se descubre el coral sin cambiar de skin."""
    out = sano.copy()
    for part, (base, over, w, h, d) in BOX.items():
        for (u, v) in (base, over):
            f = faces(u, v, w, h, d)
            for side in ('front', 'right', 'left'):
                fx, fy, fw, fh = f[side]
                out.paste(inf.crop((fx, fy, fx + fw, fy + fh)), (fx, fy))
    return out


if __name__ == '__main__':
    dst = sys.argv[1]; os.makedirs(dst, exist_ok=True)
    previews = []
    for nombre, p in REPARTO.items():
        sano = persona(p); sano.save(f'{dst}/{nombre}.png')
        inf = infectar(sano, p['seed'] * 7 + 1); inf.save(f'{dst}/{nombre}_infectado.png')
        previews += [vista(sano), vista(inf)]
        if nombre == 'iker': mezcla_giro(sano, inf).save(f'{dst}/iker_giro.png')
    if len(sys.argv) > 2:
        cols = 6; w, h = previews[0].size
        hoja = Image.new('RGBA', (cols * (w + 16), ((len(previews) + cols - 1) // cols) * (h + 16)), (60, 70, 80, 255))
        for i, v in enumerate(previews): hoja.alpha_composite(v, ((i % cols) * (w + 16) + 8, (i // cols) * (h + 16) + 8))
        hoja.save(sys.argv[2])
    print('skins:', len(REPARTO) * 2)
