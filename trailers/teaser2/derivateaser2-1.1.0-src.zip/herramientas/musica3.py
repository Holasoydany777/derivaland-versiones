"""Banda sonora original del Teaser Tráiler 2 (70 s) y los efectos. Todo sintetizado aquí, sin muestras.

 0:00-0:29  nana en caja de música (Re mayor) con guitarra; segunda estrofa. Nota rara a los 23.9 s
 0:29-0:48  la misma nana, cada vez más desafinada; entra un drone grave
 0:48-1:11  latido que acelera (58 -> 134 ppm), cuerdas tensas en crescendo
 1:11-1:14  silencio total (una gota a los 71.6 s)
 1:14-1:21  un único golpe grave con cola larga bajo el agua
 1:21-1:28  las tres primeras notas, rotas

Uso: python3 musica2.py <carpeta_ogg> [<wav_completo>]
"""
import numpy as np, subprocess, sys
from scipy.signal import butter, lfilter, fftconvolve

SR = 44100
OUT = sys.argv[1]
rng = np.random.default_rng(2027)
DUR = 88.0


def t(d): return np.arange(int(d * SR)) / SR
def lp(x, f, o=2): b, a = butter(o, f / (SR / 2), 'low'); return lfilter(b, a, x, axis=0)
def hp(x, f, o=2): b, a = butter(o, f / (SR / 2), 'high'); return lfilter(b, a, x, axis=0)
def bp(x, f1, f2, o=2): b, a = butter(o, [f1 / (SR / 2), f2 / (SR / 2)], 'band'); return lfilter(b, a, x, axis=0)
NOTE = lambda n: 440 * 2 ** ((n - 69) / 12)


def env(n, a, r, shape=4.0):
    e = np.ones(n); A = max(1, int(a * SR)); e[:A] = np.linspace(0, 1, A)
    e *= np.exp(-np.arange(n) / SR * shape / max(r, 1e-3)); return e


def reverb(x, dur=2.5, mix=0.3, dark=4000, seed=1):
    r = np.random.default_rng(seed); n = int(dur * SR)
    ir = r.standard_normal(n) * np.exp(-np.arange(n) / SR * 6.9 / dur); ir = lp(ir, dark); ir /= np.sqrt((ir ** 2).sum())
    if x.ndim == 1: x = np.stack([x, x], 1)
    out = []
    for c in range(2):
        w = fftconvolve(x[:, c], np.roll(ir, c * 41))[:len(x)]
        out.append(x[:, c] * (1 - mix) + w * mix * 3.0)
    return np.stack(out, 1)


def place(buf, x, at):
    i = int(at * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x))
    if buf.ndim == 2 and x.ndim == 1: x = np.stack([x, x], 1)
    buf[i:j] += x[:j - i]


def pan(x, p):  # p -1 izquierda .. 1 derecha
    return np.stack([x * np.sqrt((1 - p) / 2), x * np.sqrt((1 + p) / 2)], 1)


def norm(x, peak=0.89):
    m = np.max(np.abs(x)); return x / m * peak if m > 0 else x


def save(name, x, peak=0.89, stereo=True):
    x = norm(x, peak) if peak else x
    if x.ndim == 1 and stereo: x = np.stack([x, x], 1)
    ch = 1 if x.ndim == 1 else 2
    raw = (np.clip(x, -1, 1) * 32767).astype('<i2').tobytes()
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ar', str(SR), '-ac', str(ch), '-i', '-',
                    '-c:a', 'libvorbis', '-q:a', '6', f'{OUT}/{name}.ogg'], input=raw, check=True)
    print(name, round(len(x) / SR, 2), 's', ch, 'ch')


def cajita(f, d, vel=1.0, desafino=0.0, wobble=0.0):
    """Caja de música: púa metálica con parciales inarmónicos."""
    tt = t(d)
    ph = 2 * np.pi * f * tt
    if wobble: ph += wobble * np.sin(2 * np.pi * 5.2 * tt) * (1 + tt)
    s = (np.sin(ph) + 0.35 * np.sin(ph * 3.01) * np.exp(-tt * 9) + 0.18 * np.sin(ph * 5.43) * np.exp(-tt * 20)
         + 0.08 * np.sin(ph * 8.9) * np.exp(-tt * 35))
    s *= env(len(tt), 0.0015, 1.6, 4.2)
    return s * vel


def pad(fs, d, vel):
    tt = t(d)
    s = sum(np.sin(2 * np.pi * f * tt + 0.3 * np.sin(2 * np.pi * 0.3 * tt)) + 0.3 * np.sin(2 * np.pi * 2 * f * tt) for f in fs)
    a = min(1.5, d / 3)
    e = np.clip(tt / a, 0, 1) * np.clip((d - tt) / a, 0, 1)
    return lp(s * e * vel, 1800)


# ------------------------------------------------------------------ la nana
BPM = 84; BEAT = 60 / BPM
NANA = [(74, 0, 1), (78, 1, 1), (81, 2, 1), (83, 3, 1), (81, 4, 1), (78, 5, 1), (79, 6, 1), (78, 7, 1), (76, 8, 1), (74, 9, 3),
        (78, 12, 1), (81, 13, 1), (86, 14, 1), (85, 15, 1), (83, 16, 1), (81, 17, 1), (83, 18, 1), (81, 19, 1), (79, 20, 1),
        (76, 21, 1), (76, 22, 1), (74, 23, 1)]
ACORDES = [(0, [50, 57, 62, 66]), (6, [43, 55, 59, 62]), (12, [45, 57, 61, 64]), (18, [50, 57, 62, 66])]

M = np.zeros((int(DUR * SR), 2))

# Parte 1 (0 - 29 s): la nana dos veces; la segunda con guitarra y una nota rara a los 23.9 s
def guitarra(f, d, vel):
    n = int(d * SR); N = max(2, int(SR / f)); buf = rng.uniform(-1, 1, N); out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % N]; buf[i % N] = 0.5 * (buf[i % N] + buf[(i + 1) % N]) * 0.995
    return lp(out, 2600) * vel * env(n, 0.002, d * 1.4, 3)
V2 = 17.1  # empieza la segunda estrofa
for n, b, l in NANA:
    place(M, pan(cajita(NOTE(n), 2.2, 0.55), 0.15 if n % 2 else -0.15), b * BEAT)
for i, (n, b, l) in enumerate(NANA):
    at = V2 + b * BEAT * 0.98
    if at > 28.6: break
    f = NOTE(n)
    if abs(at - 23.9) < 0.36: f *= 2 ** (-0.75 / 12)   # la nota rara (Nico mira al mar)
    place(M, pan(cajita(f, 2.2, 0.5), 0.15 if n % 2 else -0.15), at)
    if b % 3 == 0: place(M, pan(cajita(NOTE(n - 12), 2.4, 0.18), -0.3), at)   # segunda voz grave
for v0, esc in ((0.0, 1.0), (V2, 0.98)):
    for b, ch in ACORDES:
        at = v0 + b * BEAT * esc
        if at > 28.8: continue
        place(M, pad([NOTE(x) for x in ch], 6 * BEAT + 0.8, 0.05), at)
        place(M, pan(cajita(NOTE(ch[0] + 12), 3.0, 0.22), 0), at)
        if v0 > 0:   # arpegio de guitarra (6 corcheas por compás de dos)
            notas = [ch[0] + 12, ch[1] + 12, ch[2] + 12, ch[3] + 12, ch[2] + 12, ch[1] + 12]
            for k in range(12):
                tk = at + k * BEAT / 2 * esc
                if tk > 28.8: break
                place(M, pan(guitarra(NOTE(notas[k % 6]), 1.0, 0.16), 0.35 if k % 2 else 0.1), tk)
# Parte 2 (18 - 35 s): la misma nana, cada nota más desafinada y lenta
T2 = 29.0; lento = 1.12
for i, (n, b, l) in enumerate(NANA):
    k = i / len(NANA)
    f = NOTE(n) * 2 ** (rng.uniform(-1, 1) * (0.15 + 1.1 * k) / 12) * (1 - 0.04 * k)
    place(M, pan(cajita(f, 2.6, 0.5 * (1 - 0.35 * k), wobble=0.02 + 0.25 * k), rng.uniform(-0.5, 0.5)), T2 + b * BEAT * lento)
for b, ch in ACORDES:
    fs = [NOTE(x) * 2 ** (rng.uniform(-0.3, 0.3) / 12) for x in ch]
    place(M, pad(fs, 6 * BEAT * lento + 0.8, 0.045), T2 + b * BEAT * lento)
# drone grave (entra a los 18 s, sube hasta 55)
d = 71 - 29; tt = t(d)
dr = np.zeros(len(tt))
for f, a in [(36.7, 1), (55.0, 0.55), (73.4, 0.3), (77.8, 0.22), (38.9, 0.4)]:
    dr += a * np.sin(2 * np.pi * f * tt + 0.8 * np.sin(2 * np.pi * 0.05 * tt * f / 36))
dr += 0.6 * lp(rng.standard_normal(len(tt)), 110)
dr *= np.clip(tt / 6, 0, 1) * (0.25 + 0.75 * (tt / d) ** 1.5)
place(M, np.stack([dr, np.roll(dr, 1800)], 1) * 0.16, 29)

# Parte 3 (35 - 55 s): latido que acelera + cuerdas en crescendo
def latido(v):
    n = int(0.5 * SR); tc = np.arange(n) / SR
    lub = np.sin(2 * np.pi * (55 * np.exp(-tc * 8) + 38) * tc) * np.exp(-tc * 18)
    dub = np.sin(2 * np.pi * (48 * np.exp(-tc * 8) + 34) * tc) * np.exp(-tc * 22)
    s = lub.copy(); k = int(0.22 * SR); s[k:] += 0.7 * dub[:n - k]
    return lp(s * v, 180)
at = 48.0
while at < 70.8:
    u = (at - 48) / 23
    bpm = 58 + 76 * u ** 1.4
    place(M, latido(0.55 + 0.45 * u), at)
    at += 60 / bpm
d = 23; tt = t(d)
cuerdas = np.zeros(len(tt))
for f in [NOTE(62), NOTE(63), NOTE(69), NOTE(70), NOTE(74.4)]:
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * tt + rng.uniform(0, 6))
    ph = np.cumsum(2 * np.pi * f * vib / SR)
    saw = 2 * ((ph / (2 * np.pi)) % 1) - 1
    cuerdas += saw
ab = ((tt / d) ** 2)
cuerdas = lp(cuerdas, 900) * (1 - ab) + lp(cuerdas, 4400) * ab
cuerdas *= (tt / d) ** 2.2
place(M, np.stack([cuerdas, np.roll(cuerdas, 900)], 1) * 0.07, 48)
# fragmentos de la nana, rotos, entre los latidos
for at, n in [(51.5, 81), (54.4, 78), (57.3, 83), (59.6, 74), (61.8, 86), (63.6, 85), (65.3, 81), (66.8, 78), (68.0, 74), (69.1, 81), (69.9, 86)]:
    f = NOTE(n) * 2 ** (rng.uniform(-1.3, 1.3) / 12)
    place(M, pan(cajita(f, 1.4, 0.32, wobble=0.35), rng.uniform(-0.8, 0.8)), at)
# subida final (plano 16)
d = 3.0; tt = t(d)
sub = hp(rng.standard_normal(len(tt)), 1500) * (tt / d) ** 3 * 0.5
sub += np.sin(2 * np.pi * np.cumsum(80 * 2 ** (tt * 2)) / SR) * (tt / d) ** 2 * 0.4
place(M, np.stack([sub, np.roll(sub, 300)], 1), 68.0)
# corte en seco a los 55.0
M[int(71.0 * SR):int(74.0 * SR)] = 0

# Parte 4: el golpe (74.0)
d = 7; tt = t(d)
G = np.sin(2 * np.pi * np.cumsum(58 * np.exp(-tt * 1.3) + 24) / SR) * np.exp(-tt * 0.7) * 1.4
G += lp(rng.standard_normal(len(tt)), 300) * np.exp(-tt * 2.2) * 1.2
G += bp(rng.standard_normal(len(tt)), 600, 4000) * np.exp(-tt * 10) * 0.6
G[:int(0.003 * SR)] *= np.linspace(0, 1, int(0.003 * SR))
Gs = reverb(np.stack([G, np.roll(G, 500)], 1), 5, 0.5, 900, seed=4)
place(M, lp(Gs, 1600) * 0.11, 74.0)

# Parte 5: las tres primeras notas, rotas (81.3)
for i, (n, b, l) in enumerate(NANA[:3]):
    f = NOTE(n) * 2 ** ((-0.4 - 0.5 * i) / 12)
    place(M, pan(cajita(f, 2.5, 0.42, wobble=0.15 * (i + 1)), 0), 81.3 + i * BEAT * (1.25 + 0.3 * i))

# reverb general (más húmeda a partir de la parte 2)
Mr = reverb(M, 3.0, 0.32, 5000, seed=7)
M = Mr
M[int(71.0 * SR):int(71.0 * SR) + int(0.02 * SR)] *= np.linspace(1, 0, int(0.02 * SR))[:, None]
M[int(71.02 * SR):int(74.0 * SR)] = 0
fin = np.ones(len(M)); fin[-int(1.0 * SR):] = np.linspace(1, 0, int(1.0 * SR)) ** 2
M *= fin[:, None]
M = norm(M, 0.9)
save('banda', M, peak=None)
if len(sys.argv) > 2:
    raw = (np.clip(M, -1, 1) * 32767).astype('<i2').tobytes()
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ar', str(SR), '-ac', '2', '-i', '-', sys.argv[2]], input=raw, check=True)

# ------------------------------------------------------------------ efectos
# pueblo: pájaros + río (18 s)
d = 30; P = np.zeros((int(d * SR), 2))
rio = lp(rng.standard_normal(len(t(d))), 1200) * 0.12 + bp(rng.standard_normal(len(t(d))), 2000, 6000) * 0.03
P += np.stack([rio, np.roll(rio, 700)], 1)
at = 0.3
while at < d - 1:
    n = int(rng.uniform(0.06, 0.14) * SR); tc = np.arange(n) / SR
    f0 = rng.uniform(2600, 4200)
    ch = np.sin(2 * np.pi * np.cumsum(f0 + 900 * np.sin(2 * np.pi * rng.uniform(15, 30) * tc)) / SR) * np.sin(np.pi * tc / tc[-1]) ** 2
    for rep in range(rng.integers(1, 4)):
        place(P, pan(ch * rng.uniform(0.1, 0.25), rng.uniform(-0.9, 0.9)), at + rep * (len(tc) / SR + 0.05))
    at += rng.uniform(0.4, 1.6)
P[:int(1.5 * SR)] *= np.linspace(0, 1, int(1.5 * SR))[:, None]
P[-int(1.5 * SR):] *= np.linspace(1, 0, int(1.5 * SR))[:, None]
save('pueblo', reverb(P, 1.2, 0.15, 7000), 0.6)

# burbujas bajo el agua
d = 4; B = np.zeros(int(d * SR))
for k in range(40):
    n = int(0.06 * SR); tc = np.arange(n) / SR; f = rng.uniform(300, 900)
    place(B, np.sin(2 * np.pi * np.cumsum(f * (1 + tc * 12)) / SR) * np.exp(-tc * 40) * rng.uniform(0.2, 0.6), rng.uniform(0, d - 0.1))
B = lp(B, 2500) + 0.25 * lp(rng.standard_normal(len(B)), 200)
save('burbujas', reverb(B, 1.5, 0.35, 1500), 0.7)

# crujido de coral (piedra que crece)
d = 1.6; C = np.zeros(int(d * SR))
at = 0
while at < d - 0.1:
    n = int(rng.uniform(0.005, 0.02) * SR)
    place(C, bp(rng.standard_normal(n), 800, 5000) * env(n, 0.0005, 0.01, 3) * rng.uniform(0.3, 1), at)
    at += rng.uniform(0.005, 0.05)
C += lp(rng.standard_normal(len(C)), 150) * np.sin(np.pi * np.arange(len(C)) / len(C)) * 0.4
save('coral', reverb(C, 0.8, 0.2, 4000), 0.8)

# zumbido eléctrico (luces que parpadean)
d = 4; tt = t(d)
Z = (np.sign(np.sin(2 * np.pi * 50 * tt)) * 0.3 + np.sin(2 * np.pi * 100 * tt) * 0.5) * (0.6 + 0.4 * (rng.random(len(tt)) > 0.02))
Z = lp(Z, 1800)
for k in range(9):
    n = int(0.03 * SR); place(Z, bp(rng.standard_normal(n), 2000, 8000) * 0.8, rng.uniform(0, d - 0.05))
Z *= np.clip(tt / 0.3, 0, 1) * np.clip((d - tt) / 0.5, 0, 1)
save('zumbido', Z, 0.55)

# susurros
d = 3.5; tt = t(d); S = np.zeros((len(tt), 2))
for k in range(7):
    n = int(rng.uniform(0.5, 1.1) * SR); tc = np.arange(n) / n
    x = bp(rng.standard_normal(n), rng.uniform(1500, 2500), rng.uniform(4000, 7000)) * np.sin(np.pi * tc) ** 2
    x *= 0.6 + 0.4 * np.sin(2 * np.pi * rng.uniform(4, 8) * tc * n / SR)
    place(S, pan(x, rng.uniform(-1, 1)), rng.uniform(0, d - n / SR))
save('susurros', reverb(S, 2.0, 0.4, 5000), 0.6)

# gota de agua (en el silencio)
d = 2.0; tt = t(d)
g = np.sin(2 * np.pi * np.cumsum(900 + 1400 * np.exp(-tt * 30)) / SR) * np.exp(-tt * 25)
save('gota', reverb(g, 2.0, 0.55, 6000, seed=9), 0.7)

# el sonido raro del final (canto grave, inhumano, que no se explica)
d = 4.5; tt = t(d)
f = 46 + 6 * np.sin(2 * np.pi * 0.4 * tt) + 14 * np.clip(tt - 2.5, 0, 1)
R = sum(np.sin(2 * np.pi * np.cumsum(f * m) / SR) * a for m, a in [(1, 1), (2.03, 0.6), (3.1, 0.35), (4.97, 0.2), (7.2, 0.12)])
R *= 1 + 0.5 * np.sin(2 * np.pi * 7 * tt)
R = bp(R, 60, 1400)
R *= np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 1.5
save('raro', reverb(np.stack([R, np.roll(R, 1100)], 1), 4, 0.55, 1200, seed=11), 0.85)
