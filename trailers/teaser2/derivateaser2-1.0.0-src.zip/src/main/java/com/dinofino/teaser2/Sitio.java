package com.dinofino.teaser2;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Mapa del plató (dimensión derivateaser2:pueblo). Mar plano: agua de y=39 a y=62, arena del fondo en y=38.
 * El pueblo está en una isla: hierba en y=64 (se camina en y=65), playa al oeste y el mar más allá.
 *
 * Ejes: X crece hacia el este, Z hacia el sur. La calle mayor va de oeste (playa) a este (casino) por z=0.
 */
public final class Sitio {
    public static final ResourceKey<Level> PUEBLO = ResourceKey.create(Registries.DIMENSION, id("pueblo"));

    public static Identifier id(String p) { return Identifier.fromNamespaceAndPath(DerivaTeaser2.MODID, p); }

    public static final int AGUA_ARRIBA = 62;
    public static final int SUELO_MAR = 38;
    public static final int SUELO = 64;        // hierba
    public static final int PIE = 65;          // donde se pisa

    /** Isla: rectángulo de hierba (la playa y la pendiente bajo el agua van alrededor). */
    public static final int ISLA_X0 = -28, ISLA_X1 = 66, ISLA_Z0 = -34, ISLA_Z1 = 34;

    /** Marca para saber si el plató ya está montado (bajo tierra, no se ve). */
    public static final BlockPos MARCA = new BlockPos(0, 20, 0);

    // calle mayor y plaza
    public static final int CALLE_X0 = -38, CALLE_X1 = 47;
    public static final BlockPos PLAZA = new BlockPos(6, SUELO, 0);
    public static final int PLAZA_R = 8;
    public static final BlockPos FUENTE = new BlockPos(6, PIE, 0);

    /** Casas: esquina oeste (x0) de cada una. Las del norte tienen la fachada en z=-3, las del sur en z=3. */
    public static final int[] CASAS_X = {-22, -13, 16, 25, 34};
    public static final int CASA_ANCHO = 7, CASA_FONDO = 6;

    // pozo (anillo 5x5, hueco 3x3)
    public static final int POZO_X = -3, POZO_Z = 11;
    public static final int POZO_AGUA = 58;

    // campo de trigo
    public static final int TRIGO_X0 = -26, TRIGO_X1 = -18, TRIGO_Z0 = 12, TRIGO_Z1 = 20;

    // campanario (al norte de la plaza)
    public static final BlockPos CAMPANA = new BlockPos(6, 68, -10);

    // el cartel de la entrada (mira al oeste, a la playa)
    public static final Vec3 CARTEL = new Vec3(-26.5, 66.1, -3.5);

    // casino (edificio grande al fondo de la calle, sin cartel)
    public static final int CASINO_X0 = 48, CASINO_X1 = 64, CASINO_Z0 = -16, CASINO_Z1 = -4, CASINO_ALTO = 15;

    // arrecife bajo el agua, junto a la costa oeste
    public static final BlockPos ARRECIFE = new BlockPos(-50, 50, 3);
    public static final Vec3 CORAL_VIVO = new Vec3(-50.0, 51.0, 3.0);

    // la silueta en el mar (plano 17)
    public static final Vec3 SILUETA = new Vec3(-112.0, 62.0, 0.5);

    // la playa del final
    public static final Vec3 NINO_PLAYA = new Vec3(-35.2, 64.0, 0.6);

    /** Altura de los pies en (x, z): 65 en el pueblo, 64 en la playa (la arena está un bloque más abajo). */
    public static double pie(double x, double z) {
        return Plato.fuera((int) Math.floor(x), (int) Math.floor(z)) < 2 ? PIE : PIE - 1;
    }

    private Sitio() {}
}
