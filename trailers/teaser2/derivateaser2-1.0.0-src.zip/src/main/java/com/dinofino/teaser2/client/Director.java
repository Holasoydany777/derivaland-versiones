package com.dinofino.teaser2.client;

import com.dinofino.teaser2.Escena;
import com.dinofino.teaser2.Servidor;
import com.dinofino.teaser2.Sitio;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * El director: lleva el reloj del teaser, mueve la cámara fotograma a fotograma, lanza la música y los sonidos,
 * y pide al servidor integrado lo que haga falta (hora, vecinos, coral, puertas, luces...).
 */
public final class Director {
    static boolean activo;
    static int tick;          // siguiente tick que toca
    static int inicio, fin;   // tramo que se reproduce
    static int prep;          // ticks en negro antes de empezar (el plató se coloca)
    static boolean completo;  // el teaser entero (con música) o un plano suelto
    static double t;
    static Guion guion;
    static Toma actual;
    static Vec3 camPos = Vec3.ZERO;
    static float camYaw, camPitch, camRoll, camFov = 60;
    static final Map<String, Pista> SONIDOS = new HashMap<>();
    static final List<Pista> TODAS = new ArrayList<>();
    static String amigo;      // el segundo cameo (ZainZero), si se ha dicho su nombre de Minecraft

    public static boolean activo() { return activo; }

    // ------------------------------------------------------------------ empezar / parar
    /** plano = 0 para el teaser entero; 1..19 para uno suelto. */
    public static void empezar(int plano) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.getSingleplayerServer() == null) {
            mensaje("El teaser solo funciona en un mundo de un jugador.");
            return;
        }
        if (activo) parar(false);
        guion = new Guion();
        if (plano > 0) {
            int[] r = Guion.PLANOS[plano - 1];
            inicio = r[0]; fin = r[1];
            completo = false;
        } else {
            inicio = 0; fin = guion.duracion;
            completo = true;
        }
        tick = inicio;
        prep = 80;
        activo = true;
        actual = tomaEn(inicio);
        mc.getMusicManager().stopPlaying();
        Vec3 p = actual.p0.get();
        var uuid = mc.player.getUUID();
        guion.nombreJugador = mc.player.getGameProfile().name();
        guion.amigo = amigo;
        int desde = inicio;
        servidor(s -> {
            Servidor.restaurar(s);
            Escena.reiniciar();
            Servidor.limpiar(s);
            Servidor.congelar(s);
            Servidor.entrar(s, uuid, p, 0, 0);
            // el cartel entero hasta el plano 15 (allí ya está roto)
            Escena.cartel(s, desde >= Guion.PLANOS[14][0]);
        });
    }

    public static void parar(boolean avisar) {
        if (!activo) return;
        activo = false;
        for (Pista p : TODAS) p.cortar();
        TODAS.clear();
        SONIDOS.clear();
        servidor(s -> {
            Servidor.limpiar(s);
            Servidor.restaurar(s);
            Escena.reiniciar();
            Servidor.descongelar(s);
        });
        if (avisar) mensaje("¡Corten! Teaser terminado. /teasertrailer2 salir para volver a donde estabas.");
    }

    static void mensaje(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[Teaser 2] " + s));
    }

    // ------------------------------------------------------------------ ayudas para el guion
    static void servidor(Consumer<MinecraftServer> c) {
        MinecraftServer s = Minecraft.getInstance().getSingleplayerServer();
        if (s != null) s.execute(() -> c.accept(s));
    }

    static void sonar(String nombre, float vol) { sonar(nombre, vol, 1f); }

    static void sonar(String nombre, float vol, float tono) {
        if (nombre.equals("banda") && !completo) return;   // la música solo en el teaser entero
        Identifier id = nombre.contains(":") ? Identifier.parse(nombre) : Sitio.id(nombre);
        Pista p = new Pista(id, vol, tono);
        TODAS.add(p);
        SONIDOS.put(nombre, p);
        Minecraft.getInstance().getSoundManager().play(p);
    }

    static void fundir(String nombre, int ticks) {
        Pista p = SONIDOS.get(nombre);
        if (p != null) p.fundir(ticks);
    }

    static void particula(ParticleOptions o, double x, double y, double z, double vx, double vy, double vz) {
        var l = Minecraft.getInstance().level;
        if (l != null) l.addAlwaysVisibleParticle(o, true, x, y, z, vx, vy, vz);
    }

    static Toma tomaEn(double tt) {
        Toma ultima = guion.tomas.get(0);
        for (Toma s : guion.tomas) {
            if (tt >= s.t0 && tt < s.t1) return s;
            if (s.t0 <= tt) ultima = s;
        }
        return ultima;
    }

    /** Al empezar un plano: fuera los vecinos que no salen en él, y la hora. */
    static void empezarToma(Toma s) {
        Set<String> quedan = new HashSet<>(s.actores);
        int hora = s.hora;
        servidor(sv -> {
            Servidor.soloActores(sv, quedan);
            if (hora >= 0) Servidor.hora(sv, hora);
        });
        if (s.alEmpezar != null) s.alEmpezar.run();
    }

    // ------------------------------------------------------------------ reloj (un tick de cliente)
    static void tickCliente() {
        if (!activo) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) { activo = false; return; }
        if (mc.isPaused()) return;
        if (prep > 0) {
            prep--;
            if (prep == 40) {
                // ya en el plató: lo que haga falta para la primera toma
                guion.alcanzar(inicio);
                Toma s = tomaEn(inicio);
                if (s.preparar() != null) s.preparar().run();
                empezarToma(s);
            }
            if (prep == 0) guion.sonidosDesde(inicio);
            return;
        }
        int k = tick;
        for (Toma s : guion.tomas) {
            if (s.t0 - 6 == k && s.t0 != inicio && s.preparar() != null) s.preparar().run();
            if (s.t0 == k) {
                actual = s;
                if (s.t0 != inicio) empezarToma(s);
            }
        }
        guion.eventos(k);
        Toma s = actual;
        if (s != null && k >= s.t0 && k < s.t1) {
            int rel = k - s.t0;
            for (int i = 0; i < s.evT.size(); i++) if (s.evT.get(i)[0] == rel) s.evR.get(i).run();
            if (s.cadaTick != null) s.cadaTick.accept(rel);
        }
        tick++;
        if (tick >= fin) parar(true);
    }

    /** Después del tick del mundo: el cuerpo de los vecinos mira siempre hacia donde se les ha dicho. */
    static void enderezarCuerpos() {
        Minecraft mc = Minecraft.getInstance();
        if (!activo || mc.level == null || mc.level.dimension() != Sitio.PUEBLO) return;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof net.minecraft.world.entity.decoration.Mannequin m) {
                m.yBodyRot = m.getYRot();
            }
        }
    }

    // ------------------------------------------------------------------ cámara (cada fotograma)
    static void fotograma(float parcial) {
        if (!activo) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        t = prep > 0 ? inicio : Math.min(fin - 0.001, (tick - 1) + parcial);
        if (prep <= 0 && t < inicio) t = inicio;
        Toma s = tomaEn(t);
        double u = s.avance(t);
        Vec3 pos = lerp(s.p0.get(), s.p1.get(), u);
        float yaw, pitch;
        if (s.look0 != null) {
            Vec3 look = lerp(s.look0.get(), s.look1.get(), u);
            Vec3 d = look.subtract(pos);
            yaw = (float) (Mth.atan2(-d.x, d.z) * Mth.RAD_TO_DEG);
            pitch = (float) (-Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG);
        } else {
            yaw = (float) Mth.lerp(u, s.yaw0, s.yaw1);
            pitch = (float) Mth.lerp(u, s.pitch0, s.pitch1);
        }
        double seg = t / 20.0;
        float sac = guion.sacudida(t);
        float a = s.temblor + sac;
        float dy = (float) (Math.sin(seg * 1.7) * 0.6 + Math.sin(seg * 3.9 + 1.3) * 0.3 + Math.sin(seg * 23.0) * (sac > 0.3f ? 0.5 : 0));
        float dp = (float) (Math.sin(seg * 1.3 + 2.1) * 0.6 + Math.sin(seg * 4.7) * 0.3 + Math.sin(seg * 29.0 + 0.5) * (sac > 0.3f ? 0.5 : 0));
        camYaw = yaw + dy * a;
        camPitch = Mth.clamp(pitch + dp * a, -89.9f, 89.9f);
        camRoll = (float) (Math.sin(seg * 0.9) * 0.4 * a);
        camFov = (float) Mth.lerp(u, s.fov0, s.fov1);
        camPos = pos;
        Vec3 pies = pos.subtract(0, p.getEyeHeight(), 0);
        p.setDeltaMovement(Vec3.ZERO);
        p.setPos(pies);
        p.setOldPosAndRot(pies, camYaw, camPitch);
        p.setYRot(camYaw);
        p.setXRot(camPitch);
        p.setYHeadRot(camYaw);
    }

    static Vec3 lerp(Vec3 a, Vec3 b, double u) {
        return new Vec3(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u, a.z + (b.z - a.z) * u);
    }

    static List<Capa> capas() { return guion != null ? guion.capas : new ArrayList<>(); }

    private Director() {}
}
