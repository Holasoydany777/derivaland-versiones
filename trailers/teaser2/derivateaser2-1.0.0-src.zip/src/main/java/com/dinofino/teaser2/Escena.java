package com.dinofino.teaser2;

import static com.dinofino.teaser2.Servidor.f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BellBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Lo que pasa en cada plano: el coral que crece, las luces, las puertas, la campana, el cartel y la silueta. */
public final class Escena {
    private static final Random R = new Random();

    /** Al restaurar el plató todo vuelve a empezar. */
    public static void reiniciar() {
        infAplicada = 0;
        trigoEstado.clear();
        pozoPaso = 0;
    }

    // ------------------------------------------------------------------ bloques de coral
    static BlockState corrupto() {
        BlockState c = Plato.b("coralosis:coral_corrupto");
        return c != null ? c : Blocks.BRAIN_CORAL_BLOCK.defaultBlockState();
    }

    static BlockState planta(int k) {
        BlockState brote = Plato.b("coralosis:brote_coral", "corrupto=true,edad=" + Math.min(3, k % 4));
        if (brote != null && k % 3 == 0) return brote;
        return switch (k % 3) {
            case 0, 1 -> Plato.b("minecraft:brain_coral", "waterlogged=false");
            default -> Plato.b("minecraft:fire_coral", "waterlogged=false");
        };
    }

    /** Bloque de la mancha: rosa, rojo o brillante (para que se vea de noche). */
    static BlockState mancha(int k) {
        return switch (Math.floorMod(k, 9)) {
            case 0, 1 -> Blocks.PEARLESCENT_FROGLIGHT.defaultBlockState();
            case 2, 3 -> corrupto();
            case 4 -> Blocks.FIRE_CORAL_BLOCK.defaultBlockState();
            default -> Blocks.BRAIN_CORAL_BLOCK.defaultBlockState();
        };
    }

    // ------------------------------------------------------------------ plano 6: el coral que late bajo el agua
    public static void coralVivo(MinecraftServer s) {
        if (Servidor.hay(s, "dt2_corazon")) return;
        String bloque = Plato.b("coralosis:coral_corrupto") != null ? "coralosis:coral_corrupto" : "minecraft:brain_coral_block";
        Vec3 c = Sitio.CORAL_VIVO.add(0, 0.5, 0);
        Servidor.summon(s, "minecraft:block_display", c, "dt2_corazon",
            "block_state:{Name:\"" + bloque + "\"},brightness:{sky:15,block:15},view_range:3f,transformation:" + Servidor.escalaCentrada(1f));
        String[] plantas = {"minecraft:fire_coral", "minecraft:brain_coral", "minecraft:fire_coral", "minecraft:brain_coral"};
        double[][] off = {{0.55, 0.42}, {-0.5, 0.35}, {0.1, -0.55}, {-0.3, -0.2}};
        for (int i = 0; i < 4; i++) {
            Vec3 p = Sitio.CORAL_VIVO.add(off[i][0], 1.0, off[i][1]);
            Servidor.summon(s, "minecraft:block_display", p, "dt2_corazon_p" + i,
                "block_state:{Name:\"" + plantas[i] + "\",Properties:{waterlogged:\"false\"}},brightness:{sky:15,block:15},transformation:" + Servidor.escalaPie(0.9f));
        }
        ServerLevel l = Servidor.pueblo(s);
        Servidor.temporal(l, BlockPos.containing(Sitio.CORAL_VIVO).above(3), Plato.b("minecraft:light", "level=13,waterlogged=true"));
        Servidor.temporal(l, BlockPos.containing(Sitio.CORAL_VIVO).offset(3, 1, 3), Plato.b("minecraft:light", "level=10,waterlogged=true"));
    }

    /** Un latido: se hincha y se deshincha. */
    public static void latido(MinecraftServer s, boolean grande) {
        float e = grande ? 1.28f : 1.0f;
        Servidor.datos(s, "dt2_corazon", "{start_interpolation:0,interpolation_duration:" + (grande ? 4 : 9) + ",transformation:" + Servidor.escalaCentrada(e) + "}");
    }

    // ------------------------------------------------------------------ plano 7: el coral sale de las paredes del pozo
    private static int pozoPaso = 0;
    private static List<int[]> pozoSitios;

    static List<int[]> pozoSitios() {
        if (pozoSitios != null) return pozoSitios;
        List<int[]> l = new ArrayList<>();
        int cx = Sitio.POZO_X, cz = Sitio.POZO_Z;
        // {x, y, z de la pared, dx, dz hacia dentro}
        for (int y = Sitio.POZO_AGUA + 1; y <= 64; y++)
            for (int k = -1; k <= 1; k++) {
                l.add(new int[]{cx - 2, y, cz + k, 1, 0});
                l.add(new int[]{cx + 2, y, cz + k, -1, 0});
                l.add(new int[]{cx + k, y, cz - 2, 0, 1});
                l.add(new int[]{cx + k, y, cz + 2, 0, -1});
            }
        Random r = new Random(41);
        // de abajo (el agua) hacia arriba, algo desordenado
        l.sort(Comparator.comparingDouble(a -> a[1] + r.nextDouble() * 2.2));
        pozoSitios = l;
        return l;
    }

    /** Avanza el coral del pozo hasta el paso n (de 0 a pozoSitios().size()). */
    public static void pozo(MinecraftServer s, int hasta) {
        ServerLevel l = Servidor.pueblo(s);
        List<int[]> sit = pozoSitios();
        while (pozoPaso < Math.min(hasta, sit.size())) {
            int[] a = sit.get(pozoPaso);
            BlockPos pared = new BlockPos(a[0], a[1], a[2]);
            Servidor.temporal(l, pared, mancha(pozoPaso * 7 + 3));
            if (pozoPaso % 2 == 0) {
                BlockPos dentro = pared.offset(a[3], 0, a[4]);
                if (l.getBlockState(dentro).isAir()) {
                    String dir = a[3] > 0 ? "east" : a[3] < 0 ? "west" : a[4] > 0 ? "south" : "north";
                    String abanico = (pozoPaso % 4 == 0) ? "minecraft:brain_coral_wall_fan" : "minecraft:fire_coral_wall_fan";
                    Servidor.temporal(l, dentro, Plato.b(abanico, "facing=" + dir + ",waterlogged=false"));
                }
            }
            pozoPaso++;
        }
    }

    public static int pozoTotal() { return pozoSitios().size(); }

    // ------------------------------------------------------------------ plano 8: el trigo se marchita y se vuelve coral
    private static final Map<Long, Integer> trigoEstado = new HashMap<>();

    public static void trigo(MinecraftServer s, double fase) {
        ServerLevel l = Servidor.pueblo(s);
        int zMedio = (Sitio.TRIGO_Z0 + Sitio.TRIGO_Z1) / 2;
        for (int x = Sitio.TRIGO_X0; x <= Sitio.TRIGO_X1; x++)
            for (int z = Sitio.TRIGO_Z0; z <= Sitio.TRIGO_Z1; z++) {
                if (z == zMedio) continue;
                // empieza por lo más lejano de la cámara (el oeste) y avanza hacia ella
                double ruido = ((x * 73856093) ^ (z * 19349663)) % 1000 / 1000.0;
                double t0 = (x - Sitio.TRIGO_X0) / (double) (Sitio.TRIGO_X1 - Sitio.TRIGO_X0) * 0.55 + Math.abs(ruido) * 0.18;
                int quiero = fase < t0 ? 0 : (fase < t0 + 0.2 ? 1 : 2);
                long k = BlockPos.asLong(x, 65, z);
                int ahora = trigoEstado.getOrDefault(k, 0);
                if (quiero <= ahora) continue;
                trigoEstado.put(k, quiero);
                BlockPos p = new BlockPos(x, 65, z);
                if (quiero == 1) Servidor.temporal(l, p, Plato.b("minecraft:dead_bush"));
                else {
                    Servidor.temporal(l, p, planta(x * 5 + z));
                    if (((x + z) & 3) == 0) Servidor.temporal(l, p.below(), mancha(x + z * 3));
                }
            }
    }

    // ------------------------------------------------------------------ plano 9: las luces del casino parpadean
    public static void casinoLuces(MinecraftServer s, double probApagada) {
        ServerLevel l = Servidor.pueblo(s);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int x0 = Sitio.CASINO_X0, x1 = Sitio.CASINO_X1, z0 = Sitio.CASINO_Z0, z1 = Sitio.CASINO_Z1;
        for (int y = 65; y < 65 + Sitio.CASINO_ALTO; y++) {
            for (int z = z0; z <= z1; z++) parpadeo(l, m.set(x0, y, z), probApagada);
            for (int x = x0; x <= x1; x++) parpadeo(l, m.set(x, y, z1), probApagada);
        }
    }

    private static void parpadeo(ServerLevel l, BlockPos p, double prob) {
        BlockState st = l.getBlockState(p);
        if (!st.is(Blocks.REDSTONE_LAMP)) return;
        boolean encender = R.nextDouble() >= prob;
        if (st.getValue(BlockStateProperties.LIT) != encender) Servidor.temporal(l, p, st.setValue(BlockStateProperties.LIT, encender));
    }

    // ------------------------------------------------------------------ plano 11: la coralosis avanza por las calles
    private static List<long[]> manchas;   // {pos, t*1000}
    private static int infAplicada = 0;

    static List<long[]> manchas(ServerLevel l) {
        if (manchas != null) return manchas;
        int[][] focos = {{6, 0}, {-3, 11}, {-31, 0}, {-22, 16}, {30, 1}, {6, -10}};
        double[] retraso = {0.0, 0.05, 0.0, 0.12, 0.25, 0.18};
        List<long[]> lista = new ArrayList<>();
        for (int x = -40; x <= 50; x++)
            for (int z = -30; z <= 30; z++) {
                BlockPos p = new BlockPos(x, 64, z);
                BlockState st = l.getBlockState(p);
                boolean suelo = st.is(Blocks.GRASS_BLOCK) || st.is(Blocks.DIRT_PATH) || st.is(Blocks.COARSE_DIRT) || st.is(Blocks.STONE_BRICKS)
                    || st.is(Blocks.POLISHED_ANDESITE) || st.is(Blocks.CRACKED_STONE_BRICKS) || st.is(Blocks.SAND) || st.is(Blocks.FARMLAND);
                if (!suelo) {
                    // la playa está un bloque más abajo
                    p = new BlockPos(x, 63, z);
                    st = l.getBlockState(p);
                    if (!st.is(Blocks.SAND) || !l.getBlockState(p.above()).isAir()) continue;
                }
                BlockState arriba = l.getBlockState(p.above());
                if (!arriba.isAir() && !arriba.canBeReplaced() && !arriba.is(Blocks.WHEAT) && !arriba.is(Blocks.DEAD_BUSH)) continue;
                double mejor = 9;
                for (int i = 0; i < focos.length; i++) {
                    double d = Math.sqrt((x - focos[i][0]) * (x - focos[i][0]) + (z - focos[i][1]) * (z - focos[i][1]));
                    // las calles (z cerca de 0) llevan la infección más rápido
                    double v = Math.abs(z) <= 1 ? 30 : 19;
                    mejor = Math.min(mejor, retraso[i] + d / v);
                }
                double ruido = (((x * 92837111) ^ (z * 689287499)) & 1023) / 1023.0;
                double t = mejor + ruido * 0.22;
                // no todo: vetas, no una alfombra
                if (ruido > 0.78 && t > 0.35) continue;
                if (t <= 1.0) lista.add(new long[]{p.asLong(), (long) (t * 1000)});
            }
        lista.sort(Comparator.comparingLong(a -> a[1]));
        manchas = lista;
        return lista;
    }

    /** Pone todas las manchas con t <= fase (0..1). */
    public static void infeccion(MinecraftServer s, double fase) {
        ServerLevel l = Servidor.pueblo(s);
        List<long[]> m = manchas(l);
        long lim = (long) (fase * 1000);
        while (infAplicada < m.size() && m.get(infAplicada)[1] <= lim) {
            BlockPos p = BlockPos.of(m.get(infAplicada)[0]);
            int k = (int) (m.get(infAplicada)[0] ^ (m.get(infAplicada)[0] >>> 20));
            Servidor.temporal(l, p, mancha(k));
            BlockState arriba = l.getBlockState(p.above());
            if (Math.floorMod(k, 5) == 0 && (arriba.isAir() || arriba.canBeReplaced() || arriba.is(Blocks.WHEAT)))
                Servidor.temporal(l, p.above(), planta(k));
            else if (!arriba.isAir() && arriba.canBeReplaced()) Servidor.temporal(l, p.above(), Blocks.AIR.defaultBlockState());
            infAplicada++;
        }
    }

    // ------------------------------------------------------------------ plano 12: puertas y antorchas
    /** Las tres casas del norte que salen en el plano (de oeste a este). */
    static final int[] CASAS_PLANO12 = {16, 25, 34};

    public static void cerrarPuerta(MinecraftServer s, int i) {
        ServerLevel l = Servidor.pueblo(s);
        int x = CASAS_PLANO12[i] + 3;
        for (int y = 65; y <= 66; y++) {
            BlockPos p = new BlockPos(x, y, -3);
            BlockState st = l.getBlockState(p);
            if (st.hasProperty(BlockStateProperties.OPEN)) Servidor.temporal(l, p, st.setValue(BlockStateProperties.OPEN, false));
        }
    }

    /** Antorcha i (0..5): dos por casa, de oeste a este. */
    public static BlockPos antorcha(int i) {
        int x0 = CASAS_PLANO12[i / 2];
        return new BlockPos(i % 2 == 0 ? x0 + 1 : x0 + Sitio.CASA_ANCHO - 2, 67, -2);
    }

    public static void apagarAntorcha(MinecraftServer s, int i) {
        ServerLevel l = Servidor.pueblo(s);
        BlockPos p = antorcha(i);
        if (!l.getBlockState(p).isAir()) Servidor.temporal(l, p, Blocks.AIR.defaultBlockState());
        Servidor.particulas(s, "minecraft:smoke", Vec3.atCenterOf(p), 0.08, 0.1, 0.08, 14, 0.01);
        Servidor.particulas(s, "minecraft:large_smoke", Vec3.atCenterOf(p).add(0, 0.2, 0), 0.05, 0.05, 0.05, 3, 0.005);
    }

    // ------------------------------------------------------------------ plano 13: la campana cubierta de coral
    public static void campanaCoral(MinecraftServer s) {
        ServerLevel l = Servidor.pueblo(s);
        BlockPos c = Sitio.CAMPANA;
        int x = c.getX(), z = c.getZ();
        Servidor.temporal(l, new BlockPos(x - 1, 68, z), mancha(5));
        Servidor.temporal(l, new BlockPos(x + 1, 67, z), mancha(2));
        Servidor.temporal(l, new BlockPos(x + 1, 68, z), mancha(0));
        Servidor.temporal(l, new BlockPos(x, 69, z), Blocks.PEARLESCENT_FROGLIGHT.defaultBlockState());
        Servidor.temporal(l, new BlockPos(x - 1, 69, z), mancha(4));
        // abanicos de coral en las caras de los pilares que miran a la cámara (sur)
        Servidor.temporal(l, new BlockPos(x - 1, 67, z + 1), Plato.b("minecraft:brain_coral_wall_fan", "facing=south,waterlogged=false"));
        Servidor.temporal(l, new BlockPos(x + 1, 66, z + 1), Plato.b("minecraft:fire_coral_wall_fan", "facing=south,waterlogged=false"));
        Servidor.temporal(l, new BlockPos(x - 1, 69, z + 1), Plato.b("minecraft:fire_coral_wall_fan", "facing=south,waterlogged=false"));
        Servidor.temporal(l, new BlockPos(x + 1, 69, z + 1), Plato.b("minecraft:brain_coral_wall_fan", "facing=south,waterlogged=false"));
        Servidor.temporal(l, new BlockPos(x - 1, 71, z), planta(1));
        Servidor.temporal(l, new BlockPos(x + 1, 71, z), planta(2));
        // algo de luz para que se vea de noche
        luz(s, x, 67, z + 2, 9);
    }

    public static void campana(MinecraftServer s) {
        ServerLevel l = Servidor.pueblo(s);
        if (l.getBlockState(Sitio.CAMPANA).getBlock() instanceof BellBlock bell) bell.attemptToRing(l, Sitio.CAMPANA, Direction.SOUTH);
    }

    // ------------------------------------------------------------------ luz invisible para los planos de noche
    public static void luz(MinecraftServer s, int x, int y, int z, int nivel) {
        ServerLevel l = Servidor.pueblo(s);
        BlockPos p = new BlockPos(x, y, z);
        BlockState ya = l.getBlockState(p);
        if (!ya.isAir() && !ya.is(Blocks.LIGHT)) return;
        Servidor.temporal(l, p, Plato.b("minecraft:light", "level=" + nivel));
    }

    // ------------------------------------------------------------------ plano 16: fuego en un tejado
    public static void fuego(MinecraftServer s) {
        ServerLevel l = Servidor.pueblo(s);
        int x0 = 34;
        for (int x = x0 + 1; x <= x0 + 4; x++) {
            Servidor.temporal(l, new BlockPos(x, 72, -5), Blocks.NETHERRACK.defaultBlockState());
            Servidor.temporal(l, new BlockPos(x, 73, -5), Blocks.FIRE.defaultBlockState());
        }
        Servidor.temporal(l, new BlockPos(x0 + 2, 72, -6), Blocks.NETHERRACK.defaultBlockState());
        Servidor.temporal(l, new BlockPos(x0 + 2, 73, -6), Blocks.FIRE.defaultBlockState());
    }

    // ------------------------------------------------------------------ el cartel de la entrada
    static final float GROSOR = 0.16f, ALTO = 1.0f, TEXTO = 2.4f;
    // tramos del cartel (z relativa al centro): la mitad «DERIVA» y la mitad «LAND»
    static final float[][] TRAMOS = {{-2.3f, 0.36f}, {0.36f, 2.3f}};
    static final float[] TEXTO_Z = {-0.84f, 1.2f};
    static final String[] TEXTOS = {"DERIVA", "LAND"};

    /** El cartel «DERIVALAND»: entero (plano 3) o roto y comido por el coral (plano 15). */
    public static void cartel(MinecraftServer s, boolean roto) {
        for (int i = 0; i < 2; i++) {
            Servidor.quitar(s, "dt2_cartel" + i);
            Servidor.quitar(s, "dt2_texto" + i);
        }
        for (int i = 0; i < 4; i++) Servidor.quitar(s, "dt2_cartel_coral" + i);
        Vec3 c = Sitio.CARTEL;
        float[] giro = roto ? new float[]{-7f, 22f} : new float[]{0f, 0f};
        float[][] caida = roto ? new float[][]{{0f, -0.04f, 0f}, {0f, -0.32f, 0.12f}} : new float[][]{{0, 0, 0}, {0, 0, 0}};
        String madera = roto ? "minecraft:stripped_oak_wood" : "minecraft:oak_planks";
        for (int i = 0; i < 2; i++) {
            float z0 = TRAMOS[i][0], z1 = TRAMOS[i][1], mz = (z0 + z1) / 2, len = z1 - z0 - (roto ? 0.06f : 0f);
            float a = (float) Math.toRadians(giro[i]);
            Matrix4f tabla = new Matrix4f().translate(caida[i][0], caida[i][1], mz + caida[i][2]).rotateX(a)
                .translate(-GROSOR / 2, -ALTO / 2, -len / 2).scale(GROSOR, ALTO, len);
            Servidor.summon(s, "minecraft:block_display", c, "dt2_cartel" + i,
                "block_state:{Name:\"" + madera + "\"},view_range:2f,transformation:" + Servidor.matriz(tabla));
            // el texto vive en el marco del display (girado 90º: x local = z del mundo, z local = -x del mundo)
            float tz = TEXTO_Z[i] - mz;
            Matrix4f txt = new Matrix4f().translate(mz + caida[i][2], caida[i][1], -caida[i][0])
                .rotateZ(-a)
                .translate(tz, -0.27f, GROSOR / 2 + 0.012f)
                .scale(TEXTO);
            String color = roto ? "#2A1A10" : "#3A2412";
            Servidor.summon(s, "minecraft:text_display", c, "dt2_texto" + i,
                "Rotation:[90f,0f],text:{text:\"" + TEXTOS[i] + "\",bold:true,color:\"" + color + "\"},background:0,shadow:0b,"
                    + "line_width:400,view_range:2f,transformation:" + Servidor.matriz(txt));
        }
        ServerLevel l = Servidor.pueblo(s);
        int px = (int) Math.floor(c.x);
        if (roto) {
            // un poste partido y el coral comiéndoselo todo
            Servidor.temporal(l, new BlockPos(px, 66, -2), Blocks.AIR.defaultBlockState());
            Servidor.temporal(l, new BlockPos(px, 65, -2), Plato.b("minecraft:stripped_spruce_log", "axis=y"));
            int[][] cor = {{px, 64, -3}, {px - 1, 64, -5}, {px, 64, -6}, {px - 1, 64, -2}, {px + 1, 64, -4}, {px - 2, 64, -4}};
            for (int k = 0; k < cor.length; k++) Servidor.temporal(l, new BlockPos(cor[k][0], cor[k][1], cor[k][2]), mancha(k * 2 + 1));
            Servidor.temporal(l, new BlockPos(px - 1, 65, -5), planta(1));
            Servidor.temporal(l, new BlockPos(px - 1, 65, -2), planta(2));
            Servidor.temporal(l, new BlockPos(px + 1, 65, -4), planta(4));
            // coral creciendo sobre la madera
            double[][] sobre = {{-1.7, 0.45}, {-0.6, 0.5}, {0.9, 0.2}, {1.9, -0.05}};
            for (int k = 0; k < sobre.length; k++) {
                Vec3 p = c.add(-0.05, sobre[k][1], sobre[k][0]);
                String b = k % 2 == 0 ? "minecraft:brain_coral" : "minecraft:fire_coral_fan";
                Servidor.summon(s, "minecraft:block_display", p, "dt2_cartel_coral" + k,
                    "block_state:{Name:\"" + b + "\",Properties:{waterlogged:\"false\"}},transformation:" + Servidor.escalaPie(0.75f));
            }
            luz(s, px - 3, 67, -3, 11);
        }
    }

    /** Postes del cartel (bloques de verdad). */
    static void postesCartel(ServerLevel l) {
        int px = (int) Math.floor(Sitio.CARTEL.x);
        for (int z : new int[]{-6, -2})
            for (int y = 65; y <= 66; y++) l.setBlock(new BlockPos(px, y, z), Blocks.SPRUCE_FENCE.defaultBlockState(), Plato.FLAGS);
    }

    // ------------------------------------------------------------------ plano 17: la silueta en el mar
    /** {centro x, y, z (relativo a Sitio.SILUETA), tamaño x, y, z, giro X, giro Y} */
    private static final float[][] SILUETA = {
        {0, 4, 0, 16, 10, 34, 0, 0},          // hombros que salen del agua
        {0, 14, 0, 13, 20, 18, 0, 0},         // cabeza
        {0, 26, 0, 10, 8, 14, 0, 0},          // cráneo
        {-1, 33, -5, 2.2f, 13, 2.2f, -28, 0}, // cuernos
        {-1, 33, 5, 2.2f, 13, 2.2f, 28, 0},
        {0, 9, -15, 2.0f, 22, 2.0f, 34, 0},   // tentáculos
        {0, 7, 16, 2.0f, 20, 2.0f, -38, 0},
        {0, 3, -22, 1.6f, 14, 1.6f, 52, 0},
        {0, 3, 23, 1.6f, 15, 1.6f, -48, 0},
        {0, 19, -8, 3, 6, 3, -40, 0},        // espinas
        {0, 19, 8, 3, 6, 3, 40, 0},
    };

    public static void silueta(MinecraftServer s) {
        if (Servidor.hay(s, "dt2_sil0")) return;
        for (int i = 0; i < SILUETA.length; i++) {
            float[] p = SILUETA[i];
            Matrix4f m = new Matrix4f().translate(p[0], p[1], p[2]).rotateY((float) Math.toRadians(p[7])).rotateX((float) Math.toRadians(p[6]))
                .translate(-p[3] / 2, -p[4] / 2, -p[5] / 2).scale(p[3], p[4], p[5]);
            Servidor.summon(s, "minecraft:block_display", Sitio.SILUETA, "dt2_sil" + i,
                "block_state:{Name:\"minecraft:black_concrete\"},brightness:{sky:0,block:0},view_range:8f,transformation:" + Servidor.matriz(m));
        }
        // dos ojos rosas que brillan (miran al este, a la playa)
        for (int k = 0; k < 2; k++) {
            float z = k == 0 ? -3.4f : 3.4f;
            Matrix4f m = new Matrix4f().translate(6.6f, 16f, z).translate(-0.2f, -0.6f, -1.1f).scale(0.4f, 1.2f, 2.2f);
            Servidor.summon(s, "minecraft:block_display", Sitio.SILUETA, "dt2_ojo" + k,
                "block_state:{Name:\"minecraft:pink_concrete\"},brightness:{sky:15,block:15},view_range:8f,transformation:" + Servidor.matriz(m));
        }
    }

    private Escena() {}
}
