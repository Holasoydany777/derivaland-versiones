package com.dinofino.teaser2;

import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Levanta el pueblo de Derivaland en la dimensión del plató: la isla, la calle, la plaza con la fuente,
 * las casas, el pozo, el trigo, el campanario, el casino del fondo, la playa y el arrecife.
 * Todo con bloques normales de Minecraft (si está la Coralosis, el coral corrupto sale de ahí).
 */
public final class Plato {
    /** Sin avisar a los vecinos: así nada se cae, no se secan los corales y no se apagan las lámparas. */
    public static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
    private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger("derivateaser2");

    /** Bloque por id con propiedades "a=b,c=d"; null si no existe (p. ej. un mod que no está). */
    public static BlockState b(String id, String props) {
        Identifier rl = Identifier.parse(id);
        if (!BuiltInRegistries.BLOCK.containsKey(rl)) return null;
        Block bl = BuiltInRegistries.BLOCK.getValue(rl);
        BlockState st = bl.defaultBlockState();
        if (props != null && !props.isEmpty()) {
            for (String kv : props.split(",")) {
                String[] p = kv.split("=");
                Property<?> pr = bl.getStateDefinition().getProperty(p[0]);
                if (pr != null) st = con(st, pr, p[1]);
            }
        }
        return st;
    }

    public static BlockState b(String id) { return b(id, null); }

    private static <T extends Comparable<T>> BlockState con(BlockState s, Property<T> p, String v) {
        return p.getValue(v).map(x -> s.setValue(p, x)).orElse(s);
    }

    static void set(ServerLevel l, int x, int y, int z, BlockState st) {
        if (st != null) l.setBlock(new BlockPos(x, y, z), st, FLAGS);
    }

    static void set(ServerLevel l, int x, int y, int z, String id) { set(l, x, y, z, b(id)); }

    static void set(ServerLevel l, int x, int y, int z, String id, String props) { set(l, x, y, z, b(id, props)); }

    public static boolean montado(ServerLevel l) {
        return l.getBlockState(Sitio.MARCA).is(Blocks.EMERALD_BLOCK);
    }

    /** Lo levanta todo. */
    public static void montar(ServerLevel l) {
        long t0 = System.currentTimeMillis();
        terreno(l);
        calle(l);
        plaza(l);
        for (int x0 : Sitio.CASAS_X) {
            casa(l, x0, true);
            casa(l, x0, false);
        }
        pozo(l);
        trigo(l);
        campanario(l);
        casino(l);
        farolas(l);
        decorado(l);
        Escena.postesCartel(l);
        arrecife(l);
        set(l, Sitio.MARCA.getX(), Sitio.MARCA.getY(), Sitio.MARCA.getZ(), Blocks.EMERALD_BLOCK.defaultBlockState());
        LOG.info("Pueblo del teaser 2 montado en {} ms", System.currentTimeMillis() - t0);
    }

    // ------------------------------------------------------------------ isla y playa
    /** Distancia (en bloques) desde el borde del rectángulo de hierba; 0 dentro. Con algo de ondulación. */
    static double fuera(int x, int z) {
        double dx = Math.max(0, Math.max(Sitio.ISLA_X0 - x, x - Sitio.ISLA_X1));
        double dz = Math.max(0, Math.max(Sitio.ISLA_Z0 - z, z - Sitio.ISLA_Z1));
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 0) d += 1.2 * Math.sin(x * 0.21 + z * 0.13) + 0.7 * Math.sin(z * 0.37 - x * 0.05);
        return Math.max(0, d);
    }

    /** Distancia hacia dentro desde el borde (para rellenar hasta el fondo cerca de la orilla). */
    static int dentro(int x, int z) {
        return Math.min(Math.min(x - Sitio.ISLA_X0, Sitio.ISLA_X1 - x), Math.min(z - Sitio.ISLA_Z0, Sitio.ISLA_Z1 - z));
    }

    static void terreno(ServerLevel l) {
        BlockState hierba = Blocks.GRASS_BLOCK.defaultBlockState();
        BlockState tierra = Blocks.DIRT.defaultBlockState();
        BlockState piedra = Blocks.STONE.defaultBlockState();
        BlockState arena = Blocks.SAND.defaultBlockState();
        BlockState arenisca = Blocks.SANDSTONE.defaultBlockState();
        for (int x = Sitio.ISLA_X0 - 20; x <= Sitio.ISLA_X1 + 20; x++) {
            for (int z = Sitio.ISLA_Z0 - 20; z <= Sitio.ISLA_Z1 + 20; z++) {
                double d = fuera(x, z);
                if (d == 0) {
                    // hierba; cerca de la orilla, columna entera para que no se vea agua debajo
                    int desde = dentro(x, z) < 4 ? Sitio.SUELO_MAR + 1 : 55;
                    for (int y = desde; y <= 64; y++) set(l, x, y, z, y == 64 ? hierba : (y >= 61 ? tierra : piedra));
                } else if (d <= 8) {
                    int top = d < 2 ? 64 : 63;
                    for (int y = Sitio.SUELO_MAR + 1; y <= top; y++) set(l, x, y, z, y < top - 3 ? arenisca : arena);
                } else if (d <= 18) {
                    int top = (int) Math.round(62 - (d - 8) * 2.4);
                    if (top <= Sitio.SUELO_MAR) continue;
                    for (int y = Sitio.SUELO_MAR + 1; y <= top; y++) set(l, x, y, z, y < top - 2 ? arenisca : arena);
                }
            }
        }
    }

    // ------------------------------------------------------------------ calle y plaza
    static void calle(ServerLevel l) {
        BlockState camino = Blocks.DIRT_PATH.defaultBlockState();
        BlockState grava = Blocks.COARSE_DIRT.defaultBlockState();
        Random r = new Random(4);
        for (int x = Sitio.CALLE_X0; x <= Sitio.CALLE_X1; x++)
            for (int z = -1; z <= 1; z++) {
                int y = altura(l, x, z);
                if (y < 63) continue;
                BlockState s = r.nextInt(9) == 0 ? grava : camino;
                if (l.getBlockState(new BlockPos(x, y, z)).is(Blocks.SAND)) s = r.nextInt(3) == 0 ? camino : Blocks.SAND.defaultBlockState();
                set(l, x, y, z, s);
                set(l, x, y + 1, z, Blocks.AIR.defaultBlockState());
            }
    }

    static void plaza(ServerLevel l) {
        int cx = Sitio.PLAZA.getX(), cz = Sitio.PLAZA.getZ();
        Random r = new Random(8);
        for (int x = cx - Sitio.PLAZA_R; x <= cx + Sitio.PLAZA_R; x++)
            for (int z = cz - Sitio.PLAZA_R; z <= cz + Sitio.PLAZA_R; z++) {
                double d = Math.sqrt((x - cx) * (x - cx) + (z - cz) * (z - cz));
                if (d > Sitio.PLAZA_R + 0.3) continue;
                String s = d > Sitio.PLAZA_R - 1 ? "minecraft:stone_bricks"
                    : ((x + z) % 2 == 0 ? "minecraft:polished_andesite" : (r.nextInt(5) == 0 ? "minecraft:cracked_stone_bricks" : "minecraft:stone_bricks"));
                set(l, x, 64, z, s);
                set(l, x, 65, z, Blocks.AIR.defaultBlockState());
            }
        // fuente: pila 5x5 con agua y un pilar que echa agua por arriba
        int fx = Sitio.FUENTE.getX(), fz = Sitio.FUENTE.getZ();
        for (int x = fx - 2; x <= fx + 2; x++)
            for (int z = fz - 2; z <= fz + 2; z++) {
                boolean borde = Math.abs(x - fx) == 2 || Math.abs(z - fz) == 2;
                set(l, x, 64, z, "minecraft:smooth_stone");
                set(l, x, 65, z, borde ? b("minecraft:stone_bricks") : Blocks.WATER.defaultBlockState());
            }
        for (int y = 65; y <= 67; y++) set(l, fx, y, fz, "minecraft:chiseled_stone_bricks");
        set(l, fx, 68, fz, "minecraft:stone_brick_slab", "type=bottom");
        // el agua de arriba sí se deja correr (cae a la pila)
        l.setBlock(new BlockPos(fx, 69, fz), Blocks.WATER.defaultBlockState(), Block.UPDATE_ALL);
        // banco al sur de la fuente
        for (int k = -1; k <= 1; k++) set(l, fx + k, 65, fz + 5, "minecraft:spruce_stairs", "facing=north,half=bottom");
    }

    // ------------------------------------------------------------------ casas
    /**
     * Casa de 7x6 con zócalo de piedra, entramado de madera, ventanas y tejado a dos aguas.
     * norte=true: fachada en z=-3 (mira al sur, a la calle). La puerta queda abierta (se cierran en el plano 12).
     */
    static void casa(ServerLevel l, int x0, boolean norte) {
        int zf = norte ? -3 : 3;            // fachada
        int dz = norte ? -1 : 1;            // hacia el fondo
        int zb = zf + dz * (Sitio.CASA_FONDO - 1);
        int x1 = x0 + Sitio.CASA_ANCHO - 1;
        Random r = new Random(x0 * 31 + (norte ? 7 : 3));
        String[] paredes = {"minecraft:white_terracotta", "minecraft:oak_planks", "minecraft:birch_planks", "minecraft:mud_bricks"};
        String pared = paredes[r.nextInt(paredes.length)];
        String tejado = r.nextBoolean() ? "minecraft:dark_oak_stairs" : "minecraft:spruce_stairs";
        String tejadoLosa = tejado.replace("_stairs", "_slab");
        String madera = tejado.startsWith("minecraft:dark") ? "minecraft:dark_oak_log" : "minecraft:spruce_log";
        int zMin = Math.min(zf, zb), zMax = Math.max(zf, zb);
        // suelo y vaciado
        for (int x = x0; x <= x1; x++)
            for (int z = zMin; z <= zMax; z++) {
                set(l, x, 64, z, "minecraft:cobblestone");
                for (int y = 65; y <= 72; y++) set(l, x, y, z, Blocks.AIR.defaultBlockState());
            }
        // paredes
        for (int x = x0; x <= x1; x++)
            for (int z = zMin; z <= zMax; z++) {
                boolean bordeX = x == x0 || x == x1, bordeZ = z == zMin || z == zMax;
                if (!bordeX && !bordeZ) continue;
                for (int y = 65; y <= 68; y++) {
                    String s;
                    if (bordeX && bordeZ) s = madera;
                    else if (y == 65) s = "minecraft:cobblestone";
                    else if (y == 68) s = "minecraft:stripped_" + madera.substring(10);
                    else s = pared;
                    set(l, x, y, z, s);
                }
            }
        // ventanas
        for (int y = 66; y <= 67; y++) {
            for (int x : new int[]{x0 + 1, x1 - 1}) {
                set(l, x, y, zf, "minecraft:glass_pane", "east=true,west=true");
                set(l, x, y, zb, "minecraft:glass_pane", "east=true,west=true");
            }
            for (int z = zMin + 2; z <= zMax - 2; z++) {
                set(l, x0, y, z, "minecraft:glass_pane", "north=true,south=true");
                set(l, x1, y, z, "minecraft:glass_pane", "north=true,south=true");
            }
        }
        // puerta (abierta)
        int px = x0 + 3;
        String fachada = norte ? "south" : "north";
        set(l, px, 65, zf, "minecraft:oak_door", "facing=" + fachada + ",half=lower,hinge=left,open=true");
        set(l, px, 66, zf, "minecraft:oak_door", "facing=" + fachada + ",half=upper,hinge=left,open=true");
        set(l, px, 64, zf + (norte ? 1 : -1), "minecraft:cobblestone");
        // antorchas a los lados de la puerta (se apagan en el plano 12)
        set(l, x0 + 1, 67, zf - dz, "minecraft:wall_torch", "facing=" + fachada);
        set(l, x1 - 1, 67, zf - dz, "minecraft:wall_torch", "facing=" + fachada);
        // tejado a dos aguas (cumbrera a lo largo de x)
        int prof = Sitio.CASA_FONDO + 2;   // con alero
        for (int k = 0; k < prof / 2; k++) {
            int y = 68 + k;                // el alero a la altura de lo alto de la pared; la fila de la fachada encima
            int za = zf - dz + dz * k, zc = zb + dz - dz * k;   // filas que suben desde delante y desde atrás
            for (int x = x0 - 1; x <= x1 + 1; x++) {
                set(l, x, y, za, tejado, "facing=" + (norte ? "north" : "south") + ",half=bottom");
                set(l, x, y, zc, tejado, "facing=" + (norte ? "south" : "north") + ",half=bottom");
                if (k > 0) {
                    // rellena los hastiales por debajo
                    if (x == x0 || x == x1) for (int zz = Math.min(za, zc) + 1; zz < Math.max(za, zc); zz++) set(l, x, y, zz, pared);
                }
            }
        }
        int ycum = 68 + prof / 2;
        // chimenea con humo (una hoguera dentro)
        if (r.nextInt(3) != 0) {
            int cx = x1 - 1, cz = zb - dz;
            for (int y = 69; y <= ycum + 1; y++) set(l, cx, y, cz, "minecraft:cobblestone");
            set(l, cx, ycum + 2, cz, "minecraft:campfire", "lit=true,signal_fire=false");
        }
        // farol dentro (se ve la luz por la puerta y las ventanas)
        set(l, x0 + 3, 70, (zf + zb) / 2, "minecraft:lantern", "hanging=true");
        // algo de vida en la fachada
        set(l, x0 + 1, 65, zf - dz, "minecraft:barrel", "facing=up");
        set(l, x1 - 1, 65, zf - dz, "minecraft:potted_red_tulip");
        if (r.nextBoolean()) set(l, x1 + 1, 65, zf - dz, "minecraft:hay_block");
    }

    // ------------------------------------------------------------------ pozo
    static void pozo(ServerLevel l) {
        int cx = Sitio.POZO_X, cz = Sitio.POZO_Z;
        for (int x = cx - 2; x <= cx + 2; x++)
            for (int z = cz - 2; z <= cz + 2; z++) {
                boolean hueco = Math.abs(x - cx) <= 1 && Math.abs(z - cz) <= 1;
                for (int y = 54; y <= 65; y++) {
                    if (hueco) {
                        set(l, x, y, z, y < 55 ? b("minecraft:mossy_cobblestone") : (y <= Sitio.POZO_AGUA ? Blocks.WATER.defaultBlockState() : Blocks.AIR.defaultBlockState()));
                    } else if (y <= 65) {
                        set(l, x, y, z, ((x + y * 3 + z) % 4 == 0) ? "minecraft:mossy_cobblestone" : "minecraft:cobblestone");
                    }
                }
            }
        // postes y travesaño con la cadena y el cubo
        for (int y = 66; y <= 68; y++) {
            set(l, cx - 2, y, cz, "minecraft:spruce_fence");
            set(l, cx + 2, y, cz, "minecraft:spruce_fence");
        }
        for (int x = cx - 2; x <= cx + 2; x++) set(l, x, 69, cz, "minecraft:spruce_slab", "type=bottom");
        set(l, cx, 68, cz, "minecraft:chain", "axis=y");
        set(l, cx, 67, cz, "minecraft:lantern", "hanging=true");
    }

    // ------------------------------------------------------------------ trigo
    static void trigo(ServerLevel l) {
        for (int x = Sitio.TRIGO_X0; x <= Sitio.TRIGO_X1; x++)
            for (int z = Sitio.TRIGO_Z0; z <= Sitio.TRIGO_Z1; z++) {
                boolean acequia = z == (Sitio.TRIGO_Z0 + Sitio.TRIGO_Z1) / 2;
                if (acequia) {
                    set(l, x, 64, z, Blocks.WATER.defaultBlockState());
                    set(l, x, 65, z, Blocks.AIR.defaultBlockState());
                } else {
                    set(l, x, 64, z, "minecraft:farmland", "moisture=7");
                    set(l, x, 65, z, "minecraft:wheat", "age=7");
                }
            }
        // cerca baja alrededor
        for (int x = Sitio.TRIGO_X0 - 1; x <= Sitio.TRIGO_X1 + 1; x++) {
            set(l, x, 65, Sitio.TRIGO_Z0 - 1, "minecraft:oak_fence", "east=true,west=true");
            set(l, x, 65, Sitio.TRIGO_Z1 + 1, "minecraft:oak_fence", "east=true,west=true");
        }
        for (int z = Sitio.TRIGO_Z0; z <= Sitio.TRIGO_Z1; z++) set(l, Sitio.TRIGO_X0 - 1, 65, z, "minecraft:oak_fence", "north=true,south=true");
        set(l, Sitio.TRIGO_X1 + 2, 65, Sitio.TRIGO_Z0, "minecraft:composter");
    }

    // ------------------------------------------------------------------ campanario
    static void campanario(ServerLevel l) {
        BlockPos c = Sitio.CAMPANA;
        int x = c.getX(), z = c.getZ();
        for (int y = 65; y <= 69; y++) {
            set(l, x - 1, y, z, y == 69 ? "minecraft:chiseled_stone_bricks" : "minecraft:stone_bricks");
            set(l, x + 1, y, z, y == 69 ? "minecraft:chiseled_stone_bricks" : "minecraft:stone_bricks");
        }
        set(l, x, 69, z, "minecraft:stone_bricks");
        set(l, x - 1, 70, z, "minecraft:stone_brick_slab", "type=bottom");
        set(l, x, 70, z, "minecraft:stone_brick_stairs", "facing=north,half=bottom");
        set(l, x + 1, 70, z, "minecraft:stone_brick_slab", "type=bottom");
        set(l, x, c.getY(), z, "minecraft:bell", "attachment=ceiling,facing=south");
        for (int xx = x - 1; xx <= x + 1; xx++) set(l, xx, 64, z, "minecraft:stone_bricks");
    }

    // ------------------------------------------------------------------ casino (sin cartel: solo un edificio grande con muchas luces)
    static void casino(ServerLevel l) {
        int x0 = Sitio.CASINO_X0, x1 = Sitio.CASINO_X1, z0 = Sitio.CASINO_Z0, z1 = Sitio.CASINO_Z1, alto = Sitio.CASINO_ALTO;
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++) {
                set(l, x, 64, z, "minecraft:polished_deepslate");
                for (int y = 65; y < 65 + alto; y++) {
                    boolean borde = x == x0 || x == x1 || z == z0 || z == z1;
                    if (!borde) { set(l, x, y, z, Blocks.AIR.defaultBlockState()); continue; }
                    boolean esquina = (x == x0 || x == x1) && (z == z0 || z == z1);
                    boolean ventana = !esquina && (y - 66) % 3 == 0 && y > 65 && y < 64 + alto
                        && (((x == x0 || x == x1) && (z - z0) % 2 == 1) || ((z == z0 || z == z1) && (x - x0) % 2 == 1));
                    String s = esquina ? "minecraft:gold_block" : (ventana ? null : (y % 6 == 0 ? "minecraft:smooth_quartz" : "minecraft:quartz_bricks"));
                    if (ventana) set(l, x, y, z, "minecraft:redstone_lamp", "lit=true");
                    else set(l, x, y, z, s);
                }
                set(l, x, 65 + alto, z, (x + z) % 2 == 0 ? "minecraft:gold_block" : "minecraft:smooth_quartz");
            }
        // cúpula escalonada
        for (int k = 1; k <= 3; k++)
            for (int x = x0 + 2 * k; x <= x1 - 2 * k; x++)
                for (int z = z0 + 2 * k; z <= z1 - 2 * k; z++)
                    set(l, x, 65 + alto + k, z, k == 3 ? "minecraft:gold_block" : "minecraft:smooth_quartz");
        // puerta grande hacia la calle (cerrada, oscura)
        int pz = z1;
        for (int x = (x0 + x1) / 2 - 1; x <= (x0 + x1) / 2 + 1; x++)
            for (int y = 65; y <= 67; y++) set(l, x, y, pz, "minecraft:black_stained_glass");
        // escalinata hasta la calle
        for (int x = x0 - 1; x <= x1 + 1; x++) set(l, x, 64, pz + 1, "minecraft:quartz_slab", "type=top");
    }

    // ------------------------------------------------------------------ farolas por la calle
    static void farolas(ServerLevel l) {
        for (int x = -30; x <= 44; x += 9) {
            if (x >= -3 && x <= 15) continue; // la plaza
            for (int z : new int[]{-2, 2}) {
                int y = altura(l, x, z) + 1;
                set(l, x, y, z, "minecraft:spruce_fence");
                set(l, x, y + 1, z, "minecraft:spruce_fence");
                set(l, x, y + 2, z, "minecraft:lantern");
            }
        }
    }

    // ------------------------------------------------------------------ hierba, flores, árboles y palmeras
    static void decorado(ServerLevel l) {
        Random r = new Random(17);
        String[] flores = {"minecraft:short_grass", "minecraft:short_grass", "minecraft:short_grass", "minecraft:poppy",
            "minecraft:dandelion", "minecraft:cornflower", "minecraft:oxeye_daisy", "minecraft:azure_bluet"};
        for (int x = Sitio.ISLA_X0; x <= Sitio.ISLA_X1; x++)
            for (int z = Sitio.ISLA_Z0; z <= Sitio.ISLA_Z1; z++) {
                if (!l.getBlockState(new BlockPos(x, 64, z)).is(Blocks.GRASS_BLOCK)) continue;
                if (!l.getBlockState(new BlockPos(x, 65, z)).isAir()) continue;
                if (r.nextInt(5) == 0) set(l, x, 65, z, flores[r.nextInt(flores.length)]);
            }
        int[][] arboles = {{-10, -16}, {12, -18}, {30, -20}, {-18, 26}, {14, 22}, {38, 18}, {-24, -26}, {54, 14}, {2, 28}};
        for (int[] a : arboles) arbol(l, a[0], a[1], 5 + r.nextInt(2));
        int[][] palmeras = {{-32, -12, 7, -1, 0}, {-33, 9, 8, -1, 1}, {-31, 22, 6, -1, -1}, {-34, -24, 7, -1, 1}, {-30, 30, 6, 0, 1}};
        for (int[] p : palmeras) palmera(l, p[0], p[1], p[2], p[3], p[4]);
        // barcas varadas en la playa
        for (int z = -8; z <= -6; z++) set(l, -37, 64, z, "minecraft:spruce_slab", "type=bottom");
    }

    static int altura(ServerLevel l, int x, int z) {
        for (int y = 80; y > 0; y--) {
            BlockState s = l.getBlockState(new BlockPos(x, y, z));
            if (!s.isAir() && s.getFluidState().isEmpty() && !s.is(Blocks.SHORT_GRASS)) return y;
        }
        return 0;
    }

    static void arbol(ServerLevel l, int x, int z, int alto) {
        int y0 = altura(l, x, z) + 1;
        for (int y = y0; y < y0 + alto; y++) set(l, x, y, z, "minecraft:oak_log");
        BlockState hoja = b("minecraft:oak_leaves", "persistent=true");
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                for (int dy = -2; dy <= 1; dy++) {
                    int rr = dy >= 0 ? 1 : 2;
                    if (Math.abs(dx) > rr || Math.abs(dz) > rr) continue;
                    if (Math.abs(dx) == rr && Math.abs(dz) == rr && (x + z + dy) % 2 == 0) continue;
                    int yy = y0 + alto + dy;
                    if (dx == 0 && dz == 0 && dy < 0) continue;
                    set(l, x + dx, yy, z + dz, hoja);
                }
    }

    static void palmera(ServerLevel l, int x, int z, int alto, int dx, int dz) {
        BlockState tronco = Blocks.JUNGLE_LOG.defaultBlockState();
        BlockState hoja = b("minecraft:jungle_leaves", "persistent=true");
        int y = altura(l, x, z) + 1;
        int cx = x, cz = z;
        for (int i = 0; i < alto; i++) {
            if (i == alto / 2 || i == alto - 2) { cx += dx; cz += dz; }
            set(l, cx, y, cz, tronco);
            y++;
        }
        int ty = y;
        set(l, cx, ty, cz, hoja);
        set(l, cx, ty - 1, cz, tronco);
        int[][] brazos = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
        for (int[] br : brazos) {
            boolean diag = br[0] != 0 && br[1] != 0;
            int largo = diag ? 2 : 4;
            for (int k = 1; k <= largo; k++) {
                int yy = ty - (k >= 3 ? 1 : 0) - (k >= 4 ? 1 : 0);
                set(l, cx + br[0] * k, yy, cz + br[1] * k, hoja);
            }
        }
        set(l, cx + 1, ty - 1, cz, b("minecraft:cocoa", "age=2,facing=west"));
    }

    // ------------------------------------------------------------------ arrecife (plano 6, 16 y logo)
    static void arrecife(ServerLevel l) {
        BlockPos c = Sitio.ARRECIFE;
        Random r = new Random(23);
        // montículo de arena y piedra que sube del fondo
        for (int x = c.getX() - 12; x <= c.getX() + 12; x++)
            for (int z = c.getZ() - 12; z <= c.getZ() + 12; z++) {
                double d = Math.sqrt((x - c.getX()) * (x - c.getX()) + (z - c.getZ()) * (z - c.getZ()));
                if (d > 12) continue;
                int top = (int) Math.round(c.getY() - d * 0.9 + r.nextInt(2));
                for (int y = Sitio.SUELO_MAR + 1; y <= top; y++)
                    set(l, x, y, z, y == top ? (r.nextInt(4) == 0 ? "minecraft:gravel" : "minecraft:sand") : "minecraft:sandstone");
            }
        BlockState[] bloques = {Blocks.TUBE_CORAL_BLOCK.defaultBlockState(), Blocks.BRAIN_CORAL_BLOCK.defaultBlockState(),
            Blocks.FIRE_CORAL_BLOCK.defaultBlockState(), Blocks.HORN_CORAL_BLOCK.defaultBlockState(), Blocks.BUBBLE_CORAL_BLOCK.defaultBlockState()};
        BlockState[] plantas = {Blocks.TUBE_CORAL.defaultBlockState(), Blocks.BRAIN_CORAL.defaultBlockState(), Blocks.FIRE_CORAL.defaultBlockState(),
            Blocks.HORN_CORAL.defaultBlockState(), Blocks.BUBBLE_CORAL.defaultBlockState(), Blocks.TUBE_CORAL_FAN.defaultBlockState(),
            Blocks.FIRE_CORAL_FAN.defaultBlockState(), Blocks.SEAGRASS.defaultBlockState(), Blocks.SEAGRASS.defaultBlockState()};
        for (int k = 0; k < 260; k++) {
            int x = c.getX() + r.nextInt(25) - 12, z = c.getZ() + r.nextInt(25) - 12;
            double d = Math.sqrt((x - c.getX()) * (x - c.getX()) + (z - c.getZ()) * (z - c.getZ()));
            if (d < 1.6 || d > 12) continue;   // el centro se queda para el coral que late
            int y = suelo(l, x, z) + 1;
            if (y < Sitio.SUELO_MAR + 1 || y > Sitio.AGUA_ARRIBA - 1) continue;
            if (r.nextInt(3) == 0) {
                set(l, x, y, z, bloques[r.nextInt(bloques.length)]);
                if (r.nextBoolean()) set(l, x, y + 1, z, plantas[r.nextInt(7)]);
            } else set(l, x, y, z, plantas[r.nextInt(plantas.length)]);
            if (r.nextInt(12) == 0) set(l, x, y + 1, z, b("minecraft:sea_pickle", "pickles=3,waterlogged=true"));
        }
        // kelp hacia la superficie
        for (int k = 0; k < 18; k++) {
            int x = c.getX() + r.nextInt(25) - 12, z = c.getZ() + r.nextInt(25) - 12;
            int y = suelo(l, x, z) + 1;
            int h = 3 + r.nextInt(8);
            for (int i = 0; i < h && y + i < Sitio.AGUA_ARRIBA; i++)
                set(l, x, y + i, z, i == h - 1 ? b("minecraft:kelp", "age=20") : b("minecraft:kelp_plant"));
        }
        // la base del coral corrupto, en el centro
        set(l, c.getX(), c.getY(), c.getZ(), "minecraft:sandstone");
    }

    /** Último bloque sólido (sin contar agua) de la columna. */
    static int suelo(ServerLevel l, int x, int z) {
        for (int y = 70; y > 0; y--) {
            BlockState s = l.getBlockState(new BlockPos(x, y, z));
            if (!s.isAir() && s.getFluidState().isEmpty()) return y;
        }
        return 0;
    }

    private Plato() {}
}
