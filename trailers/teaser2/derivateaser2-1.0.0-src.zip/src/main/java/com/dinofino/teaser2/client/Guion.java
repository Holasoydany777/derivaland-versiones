package com.dinofino.teaser2.client;

import static com.dinofino.teaser2.client.Director.fundir;
import static com.dinofino.teaser2.client.Director.particula;
import static com.dinofino.teaser2.client.Director.servidor;
import static com.dinofino.teaser2.client.Director.sonar;

import com.dinofino.teaser2.Actores;
import com.dinofino.teaser2.Escena;
import com.dinofino.teaser2.Sitio;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.phys.Vec3;

/**
 * Teaser Tráiler 2 de Derivaland Remake. Todo en ticks (20 por segundo); 70 s de teaser + 1 s de negro.
 *
 *  1  Amanecer         0 –   80   gran plano general, dron hacia el pueblo
 *  2  Calle           80 –  140   travelling lateral, vecinos paseando
 *  3  Cartel         140 –  200   «DERIVALAND»
 *  4  Plaza          200 –  280   la fuente (texto 1) y el cameo
 *  5  Niños          280 –  360   corren hacia la playa; uno se para y mira al mar
 *  6  Arrecife       360 –  420   el coral que late bajo el agua
 *  7  Pozo           420 –  480   el coral sale de las paredes
 *  8  Trigo          480 –  540   se marchita y se vuelve coral
 *  9  Atardecer      540 –  620   las luces del casino parpadean (texto 2)
 * 10  Iker           620 –  700   se gira: le sale coral de la cabeza
 * 11  Desde arriba   700 –  760   la coralosis avanza por las calles
 * 12  Puertas        760 –  820   portazos y antorchas que se apagan
 * 13  Campana        820 –  880   suena sola, cubierta de coral
 * 14  Infectados     880 –  940   todos miran a cámara
 * 15  Cartel roto    940 – 1040   (texto 3)
 * 16  Destellos     1040 – 1100   coral, ojo, agua, fuego, mar
 * 17  Silencio      1100 – 1160   negro; 2 ticks de una silueta enorme en el mar
 * 18  Logo          1160 – 1300   el logo del teaser 1, la coralosis se lo come, PRONTO...
 * 19  Post          1300 – 1420   el niño solo en la playa, de noche
 */
public final class Guion {
    /** Tramos de cada plano (número que se usa en /teasertrailer2 plano N). */
    public static final int[][] PLANOS = {
        {0, 80}, {80, 140}, {140, 200}, {200, 280}, {280, 360}, {360, 420}, {420, 480}, {480, 540}, {540, 620}, {620, 700},
        {700, 760}, {760, 820}, {820, 880}, {880, 940}, {940, 1040}, {1040, 1100}, {1100, 1160}, {1160, 1300}, {1300, 1420}};
    public static final String[] NOMBRES = {"Amanecer", "Calle", "Cartel", "Plaza", "Niños", "Arrecife", "Pozo", "Trigo",
        "Atardecer", "El giro", "Desde arriba", "Puertas", "Campana", "Infectados", "Cartel roto", "Destellos", "Silencio", "Logo", "Post"};

    final List<Toma> tomas = new ArrayList<>();
    final List<Capa> capas = new ArrayList<>();
    final int duracion = 1420;
    String nombreJugador, amigo;
    private final Random rnd = new Random();

    static final int NOCHE = 18000;

    // ------------------------------------------------------------------ vecinos
    /** Un vecino en un plano: quién es, qué skin lleva y por dónde va. */
    static final class Papel {
        final String tag, skin;
        final float escala;
        final Camino camino;
        String jugador;               // cameo con la skin de un jugador de verdad
        Supplier<Vec3> mira;          // si no es null, la cabeza mira ahí
        float cabezaExtra, pitchExtra;
        IntConsumer animar;           // para ajustar cabezaExtra/pitchExtra en cada tick

        Papel(String tag, String skin, float escala, Camino c) { this.tag = "dt2_v_" + tag; this.skin = skin; this.escala = escala; this.camino = c; }

        Papel mira(Supplier<Vec3> m) { this.mira = m; return this; }
    }

    static Papel vecino(String tag, String skin, Camino c) { return new Papel(tag, skin, 1f, c); }

    static Papel nino(String tag, String skin, Camino c) { return new Papel(tag, skin, Actores.NINO, c); }

    static void crear(MinecraftServer s, Papel p) {
        Vec3 a = p.camino.pos(0);
        float yaw = p.camino.yaw(0);
        if (p.skin == null) {
            // sin nombre: la skin del que está grabando (Dani)
            String nombre = p.jugador != null ? p.jugador : (Director.guion != null ? Director.guion.nombreJugador : null);
            Actores.crearJugador(s, p.tag, nombre, a, yaw);
        }
        else Actores.crear(s, p.tag, p.skin, a, yaw, p.escala);
    }

    static void mover(Papel p, int rel) {
        if (p.animar != null) p.animar.accept(rel);
        Vec3 a = p.camino.pos(rel);
        float yaw = p.camino.yaw(rel);
        float cabeza = yaw, pitch = 0;
        if (p.mira != null) {
            Vec3 ojos = a.add(0, 1.62 * p.escala, 0);
            Vec3 m = p.mira.get();
            cabeza = Actores.yawHacia(ojos, m);
            pitch = Actores.pitchHacia(ojos, m);
            // la cabeza no gira más de 70º respecto al cuerpo
            float d = wrap(cabeza - yaw);
            if (Math.abs(d) > 70) cabeza = yaw + Math.signum(d) * 70;
        }
        float c = cabeza + p.cabezaExtra, pt = pitch + p.pitchExtra;
        servidor(s -> Actores.colocar(s, p.tag, a, yaw, c, pt));
    }

    static float wrap(float a) {
        a %= 360f;
        if (a >= 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    /** Pone el reparto en la toma: se crean al prepararla y se colocan en cada tick. */
    static Toma reparto(Toma t, Papel... ps) {
        Runnable antes = t.preparacion;
        IntConsumer cada = t.cadaTick;
        for (Papel p : ps) t.actores.add(p.tag);
        t.prepara(() -> {
            if (antes != null) antes.run();
            servidor(s -> { for (Papel p : ps) crear(s, p); });
        });
        t.cadaTick(rel -> {
            if (cada != null) cada.accept(rel);
            for (Papel p : ps) mover(p, rel);
        });
        return t;
    }

    static Camino quieto(double x, double z, float yaw) { return new Camino().en(0, x, z).mirandoQuieto(yaw); }

    static float hacia(double x, double z, double tx, double tz) { return Actores.yawHacia(new Vec3(x, 0, z), new Vec3(tx, 0, tz)); }

    static double suave(double u) { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); }

    // ------------------------------------------------------------------ el guion
    Guion() {
        // ------------------------------------------------------------------ 1. Amanecer
        tomas.add(new Toma("Amanecer", 0, 80).hora(23250)
            .desde(new Vec3(-86, 79, 7), new Vec3(-66, 75.5, 3))
            .mirando(new Vec3(24, 68, -2), new Vec3(20, 67, -1)).fov(62, 58).curva(3)
            .niebla(24, 170, 0xE9B795));

        // ------------------------------------------------------------------ 2. Calle (travelling lateral)
        tomas.add(reparto(new Toma("Calle", 80, 140).hora(1000)
                .desde(new Vec3(-25.5, 66.55, -2.35), new Vec3(-17.5, 66.55, -2.35))
                .angulos(0, 0, -4, -4).fov(60, 60).curva(0)
                .cadaTick(rel -> { if (rel == 18 || rel == 26 || rel == 34) servidor(s -> Actores.brazo(s, "dt2_v_elias")); }),
            vecino("marta", "marta", new Camino().en(0, -27.5, 0.6).en(60, -19.5, 0.6)),
            vecino("tomas", "tomas", new Camino().en(0, -13.0, -0.4).en(60, -21.5, -0.5)),
            vecino("lucia", "lucia", new Camino().en(0, -14.5, 1.4).en(60, -22.5, 1.2)),
            vecino("elias", "elias", quieto(-20.6, 2.2, 180f)).mira(() -> new Vec3(-17.5, 66.6, -0.4))));

        // ------------------------------------------------------------------ 3. Cartel
        tomas.add(new Toma("Cartel", 140, 200).hora(1100)
            .desde(new Vec3(-29.6, 66.2, -3.0), new Vec3(-29.0, 66.15, -3.4))
            .mirando(new Vec3(-26.5, 66.1, -3.6), new Vec3(-26.5, 66.1, -3.5)).fov(56, 52));

        // ------------------------------------------------------------------ 4. Plaza (texto 1) y el cameo de los creadores
        Vec3 fuente = new Vec3(6.0, 66.4, 0.0);
        List<Papel> plaza = new ArrayList<>();
        Papel dani = new Papel("dani", null, 1f, quieto(3.0, 2.7, hacia(3.0, 2.7, 6, 0)));
        plaza.add(dani);
        if (amigo == null) amigo = Director.amigo;
        if (amigo != null && !amigo.isEmpty()) {
            Papel zz = new Papel("amigo", null, 1f, quieto(3.9, 3.5, hacia(3.9, 3.5, 6, 0)));
            zz.jugador = amigo;
            plaza.add(zz);
        }
        plaza.add(nino("vega", "vega", circulo(6, 0, 5.2, 0.0, 0.055, 80)));
        plaza.add(nino("pablo", "pablo", circulo(6, 0, 5.2, 0.9, 0.055, 80)));
        plaza.add(vecino("rosa", "rosa", quieto(8.6, 5.6, 200f)).mira(() -> new Vec3(6, 65.5, 0)));
        Toma t4 = new Toma("Plaza", 200, 280).hora(1500)
            .desde(new Vec3(-5.0, 68.2, 9.8), new Vec3(-4.6, 68.15, 9.4))
            .mirando(fuente, fuente).fov(56, 54);
        tomas.add(reparto(t4, plaza.toArray(new Papel[0])));

        // ------------------------------------------------------------------ 5. Niños hacia la playa (picado)
        Papel nico = nino("nico", "nico", new Camino().en(0, -4, 0.5).en(48, -26.5, 0.5).en(58, -32.6, 0.6).mirandoQuieto(90f));
        nico.animar = rel -> nico.pitchExtra = (float) (-10 * suave((rel - 60) / 12.0));
        tomas.add(reparto(new Toma("Niños", 280, 360).hora(2000)
                .desde(new Vec3(-9.0, 73.8, -6.8), new Vec3(-12.0, 73.0, -6.2))
                .mirando(new Vec3(-16, 64.6, 0.5), new Vec3(-31, 64.0, 0.6)).fov(64, 56),
            nico,
            nino("vega", "vega", new Camino().en(0, -6, -0.6).en(45, -26, -0.4).en(70, -34, 5.5).en(80, -36, 9)),
            nino("pablo", "pablo", new Camino().en(0, -2, 1.3).en(46, -24, 1.2).en(72, -31, 9).en(80, -33, 12))));

        // ------------------------------------------------------------------ 6. Arrecife: el coral que late
        Vec3 coral = Sitio.CORAL_VIVO.add(0, 0.6, 0);
        tomas.add(new Toma("Arrecife", 360, 420).hora(4000)
            .prepara(() -> servidor(Escena::coralVivo))
            .desde(new Vec3(-45.6, 48.2, 7.6), new Vec3(-46.3, 52.6, 6.6))
            .mirando(new Vec3(-50, 51.3, 3), new Vec3(-50, 52.0, 3)).fov(60, 56)
            .en(2, () -> sonar("burbujas", 0.55f))
            .cadaTick(rel -> {
                if (rel % 10 == 0) servidor(s -> Escena.latido(s, true));
                if (rel % 10 == 4) servidor(s -> Escena.latido(s, false));
                brillo(coral, 2);
                for (int i = 0; i < 2; i++) {
                    Vec3 c = Director.camPos;
                    particula(ParticleTypes.BUBBLE, c.x + rnd.nextGaussian() * 1.5, c.y - 1 - rnd.nextDouble() * 2, c.z + rnd.nextGaussian() * 1.5, 0, 0.15, 0);
                }
            }));

        // ------------------------------------------------------------------ 7. Pozo
        tomas.add(new Toma("Pozo", 420, 480).hora(4500)
            .desde(new Vec3(-3.0, 68.7, 8.7), new Vec3(-3.05, 68.0, 9.4))
            .mirando(new Vec3(-3.0, 59.6, 11.4), new Vec3(-3.0, 59.4, 11.2)).fov(62, 56)
            .en(6, () -> sonar("coral", 0.7f)).en(26, () -> sonar("coral", 0.8f, 0.9f)).en(44, () -> sonar("coral", 0.9f, 0.8f))
            .cadaTick(rel -> {
                if (rel < 4) return;
                int total = Escena.pozoTotal();
                int hasta = (int) Math.min(total, (rel - 4) / 50.0 * total);
                servidor(s -> Escena.pozo(s, hasta));
            }));

        // ------------------------------------------------------------------ 8. Trigo
        tomas.add(new Toma("Trigo", 480, 540).hora(5000)
            .desde(new Vec3(-16.3, 66.25, 16.15), new Vec3(-17.2, 66.15, 16.05))
            .mirando(new Vec3(-26.5, 65.55, 16.0), new Vec3(-26.5, 65.45, 16.0)).fov(60, 56)
            .en(10, () -> sonar("coral", 0.6f, 1.1f)).en(32, () -> sonar("coral", 0.7f, 0.9f))
            .cadaTick(rel -> { double f = rel / 56.0; servidor(s -> Escena.trigo(s, f)); }));

        // ------------------------------------------------------------------ 9. Atardecer: el casino parpadea (texto 2)
        tomas.add(new Toma("Atardecer", 540, 620).hora(12350)
            .desde(new Vec3(2.0, 69.6, 4.8), new Vec3(2.4, 69.6, 4.6))
            .mirando(new Vec3(55, 72.5, -9), new Vec3(55, 72.3, -9)).fov(52, 48)
            .en(16, () -> sonar("zumbido", 0.55f))
            .cadaTick(rel -> {
                if (rel >= 18 && rel <= 76 && rel % 2 == 0) {
                    double p = 0.08 + 0.5 * (rel - 18) / 58.0;
                    servidor(s -> Escena.casinoLuces(s, p));
                }
            }));

        // ------------------------------------------------------------------ 10. El giro: Iker se vuelve y tiene coral en la cabeza
        Vec3 iker = new Vec3(30.5, 65.0, 0.5);
        tomas.add(new Toma("El giro", 620, 700).hora(13050)
            .actores("dt2_v_iker")
            .prepara(() -> servidor(s -> {
                Actores.crear(s, "dt2_v_iker", "iker", iker, -90f, 1f);
                Escena.luz(s, 29, 68, 2, 9);
                Escena.luz(s, 28, 67, -1, 7);
            }))
            .desde(new Vec3(27.4, 66.6, 0.95), new Vec3(28.15, 66.62, 0.8))
            .mirando(new Vec3(30.5, 66.55, 0.5), new Vec3(30.5, 66.6, 0.5)).fov(46, 40).curva(3)
            .en(36, () -> servidor(s -> Actores.skin(s, "dt2_v_iker", "iker_infectado")))
            .en(38, () -> sonar("minecraft:entity.zombie_villager.ambient", 0.9f, 0.6f))
            .en(40, () -> servidor(s -> Actores.coralCabeza(s, "dt2_v_iker", iker, 1f, "minecraft:brain_coral", 0.8f, 16)))
            .en(42, () -> sonar("susurros", 0.7f))
            .cadaTick(rel -> {
                float yaw = (float) (-90 - 180 * suave((rel - 30) / 14.0));
                float cabeza = (float) (yaw - 25 * Math.sin(Math.PI * suave((rel - 28) / 14.0)));
                float pitch = (float) (6 * suave((rel - 50) / 20.0));
                servidor(s -> Actores.colocar(s, "dt2_v_iker", iker, yaw, cabeza, pitch));
            }));

        // ------------------------------------------------------------------ 11. Desde arriba: la coralosis avanza
        tomas.add(new Toma("Desde arriba", 700, 760).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.trigo(s, 1.0); Escena.pozo(s, Escena.pozoTotal()); }))
            .desde(new Vec3(-6, 110, 34), new Vec3(4, 100, 14))
            .mirando(new Vec3(6, 64, -2), new Vec3(6, 64, -6)).fov(70, 64).curva(0)
            .en(5, () -> sonar("coral", 0.5f, 0.7f)).en(30, () -> sonar("coral", 0.6f, 0.6f))
            .cadaTick(rel -> { double f = Math.min(1, rel / 56.0); servidor(s -> Escena.infeccion(s, f)); }));

        // ------------------------------------------------------------------ 12. Puertas y antorchas (cámara en mano)
        int[] antorchas = {4, 14, 22, 32, 40, 50};
        int[] puertas = {10, 28, 44};
        Toma t12 = new Toma("Puertas", 760, 820).hora(NOCHE)
            .prepara(() -> servidor(s -> Escena.infeccion(s, 1.0)))
            .desde(new Vec3(18.6, 66.45, 1.5), new Vec3(21.8, 66.35, 1.1))
            .mirando(new Vec3(26.5, 66.3, -3.2), new Vec3(31.0, 66.1, -3.2)).fov(64, 58).temblor(0.9f);
        for (int i = 0; i < antorchas.length; i++) {
            int k = i;
            t12.en(antorchas[i], () -> { servidor(s -> Escena.apagarAntorcha(s, k)); sonar("minecraft:block.fire.extinguish", 0.45f, 0.9f); });
        }
        for (int i = 0; i < puertas.length; i++) {
            int k = i;
            t12.en(puertas[i], () -> { servidor(s -> Escena.cerrarPuerta(s, k)); sonar("minecraft:block.wooden_door.close", 1.0f, 0.72f); });
        }
        tomas.add(t12);

        // ------------------------------------------------------------------ 13. La campana suena sola
        tomas.add(new Toma("Campana", 820, 880).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.infeccion(s, 1.0); Escena.campanaCoral(s); }))
            .desde(new Vec3(6.5, 68.5, -7.4), new Vec3(6.5, 68.45, -7.95))
            .mirando(new Vec3(6.5, 68.35, -9.5), new Vec3(6.5, 68.35, -9.5)).fov(58, 52)
            .en(6, () -> { servidor(Escena::campana); sonar("minecraft:block.bell.use", 0.9f, 0.72f); })
            .en(34, () -> { servidor(Escena::campana); sonar("minecraft:block.bell.use", 0.8f, 0.66f); }));

        // ------------------------------------------------------------------ 14. Los infectados miran a cámara
        String[][] multitud = {{"marta_infectado", "2.6", "-3.4", "a"}, {"tomas_infectado", "1.5", "0.9", "a"}, {"lucia_infectado", "3.0", "4.0", "a"},
            {"elias_infectado", "5.0", "-5.4", "a"}, {"rosa_infectado", "6.6", "5.4", "a"}, {"iker_infectado", "10.2", "-3.6", "a"},
            {"vega_infectado", "0.4", "-1.6", "n"}, {"pablo_infectado", "0.6", "2.6", "n"}};
        Papel[] inf = new Papel[multitud.length];
        for (int i = 0; i < multitud.length; i++) {
            double x = Double.parseDouble(multitud[i][1]), z = Double.parseDouble(multitud[i][2]);
            Camino c = quieto(x, z, hacia(x, z, -4.3, 0.5));
            inf[i] = multitud[i][3].equals("n") ? nino("inf" + i, multitud[i][0], c) : vecino("inf" + i, multitud[i][0], c);
            Papel p = inf[i];
            int fase = i;
            p.mira(() -> Director.camPos);
            // a la vez, todos ladean la cabeza un poco
            p.animar = rel -> { double u = suave((rel - 40 - fase % 2) / 10.0); p.pitchExtra = (float) (12 * u); p.cabezaExtra = (float) (14 * u); };
        }
        tomas.add(reparto(new Toma("Infectados", 880, 940).hora(NOCHE)
                .prepara(() -> servidor(s -> {
                    Escena.infeccion(s, 1.0);
                    Escena.luz(s, 2, 67, -1, 11);
                    Escena.luz(s, 2, 67, 3, 11);
                    Escena.luz(s, 7, 67, -6, 9);
                    Escena.luz(s, 8, 67, 6, 9);
                    Escena.luz(s, -1, 67, 0, 10);
                    for (int i = 0; i < 4; i++) {
                        double x = Double.parseDouble(multitud[i][1]), z = Double.parseDouble(multitud[i][2]);
                        Actores.coralCabeza(s, "dt2_v_inf" + i, new Vec3(x, 65, z), 1f, i % 2 == 0 ? "minecraft:brain_coral" : "minecraft:fire_coral", 0.7f, 1);
                    }
                }))
                .desde(new Vec3(-5.2, 66.75, 0.6), new Vec3(-3.4, 66.7, 0.55))
                .mirando(new Vec3(6, 66.3, 0.5), new Vec3(6, 66.3, 0.5)).fov(58, 50).curva(3)
                .en(4, () -> sonar("susurros", 0.7f)).en(34, () -> sonar("susurros", 0.85f, 0.85f)),
            inf));

        // ------------------------------------------------------------------ 15. El cartel roto (texto 3)
        tomas.add(new Toma("Cartel roto", 940, 1040).hora(NOCHE)
            .prepara(() -> servidor(s -> { Escena.infeccion(s, 1.0); Escena.cartel(s, true); }))
            .desde(new Vec3(-30.4, 65.95, -2.4), new Vec3(-29.5, 66.0, -3.0))
            .mirando(new Vec3(-26.5, 65.95, -3.4), new Vec3(-26.5, 66.0, -3.5)).fov(58, 50).curva(3).temblor(1.4f));

        // ------------------------------------------------------------------ 16. Destellos (medio segundo cada uno)
        tomas.add(new Toma("Destello: coral", 1040, 1052).hora(NOCHE)
            .prepara(() -> servidor(Escena::coralVivo))
            .desde(new Vec3(-48.3, 51.95, 4.8), new Vec3(-48.6, 51.9, 4.5))
            .mirando(coral, coral).fov(50, 46).temblor(1.5f)
            .en(0, () -> sonar("burbujas", 0.5f, 1.3f))
            .cadaTick(rel -> { boolean g = rel % 4 < 2; servidor(s -> Escena.latido(s, g)); brillo(coral, 3); }));
        Vec3 marta = new Vec3(2.6, 65.0, -3.4);
        Vec3 ojo = new Vec3(2.15, 66.62, -3.15);
        tomas.add(reparto(new Toma("Destello: ojo", 1052, 1064).hora(NOCHE)
                .prepara(() -> servidor(s -> Escena.luz(s, 1, 67, -3, 12)))
                .desde(ojo, new Vec3(2.25, 66.62, -3.21))
                .mirando(new Vec3(2.6, 66.64, -3.4), new Vec3(2.6, 66.64, -3.4)).fov(40, 36).temblor(1.0f),
            vecino("inf0", "marta_infectado", quieto(marta.x, marta.z, hacia(marta.x, marta.z, ojo.x, ojo.z))).mira(() -> Director.camPos)));
        tomas.add(new Toma("Destello: agua", 1064, 1076).hora(NOCHE)
            .desde(new Vec3(-40.5, 63.55, 4.0), new Vec3(-41.2, 63.45, 4.0))
            .mirando(new Vec3(-47, 62.4, 4.2), new Vec3(-47, 62.4, 4.2)).fov(60, 56).temblor(1.6f)
            .cadaTick(rel -> {
                for (int i = 0; i < 6; i++)
                    particula(ParticleTypes.SPLASH, -44 - rnd.nextDouble() * 4, 63.05, 4 + rnd.nextGaussian() * 1.5, 0, 0.05, 0);
            }));
        tomas.add(new Toma("Destello: fuego", 1076, 1088).hora(NOCHE)
            .prepara(() -> servidor(Escena::fuego))
            .desde(new Vec3(37.0, 73.6, -1.6), new Vec3(36.8, 73.5, -2.0))
            .mirando(new Vec3(36.8, 73.4, -5.0), new Vec3(36.8, 73.4, -5.0)).fov(56, 50).temblor(1.4f)
            .en(0, () -> sonar("minecraft:block.fire.ambient", 1.0f, 0.8f)));
        tomas.add(new Toma("Destello: mar", 1088, 1100).hora(NOCHE)
            .desde(new Vec3(-37.6, 65.9, 0.5), new Vec3(-38.0, 65.85, 0.5))
            .mirando(new Vec3(-90, 66.5, 0.5), new Vec3(-90, 66.5, 0.5)).fov(58, 54).temblor(2.2f));

        // ------------------------------------------------------------------ 17. Silencio y la silueta (2 ticks)
        tomas.add(new Toma("Silencio", 1100, 1160).hora(NOCHE)
            .desde(new Vec3(-36.6, 66.5, 0.5), new Vec3(-36.6, 66.5, 0.5))
            .mirando(new Vec3(-112, 79, 0.5), new Vec3(-112, 79, 0.5)).fov(54, 54).curva(0)
            .en(12, () -> sonar("gota", 0.8f))
            .en(20, () -> servidor(Escena::silueta))
            .en(30, () -> servidor(s -> com.dinofino.teaser2.Servidor.hora(s, 12650))));   // atardecer: la silueta a contraluz

        // ------------------------------------------------------------------ 18. Logo
        tomas.add(new Toma("Logo", 1160, 1300).hora(6000)
            .prepara(() -> servidor(Escena::coralVivo))
            .desde(new Vec3(-44.4, 47.6, 9.2), new Vec3(-45.6, 48.3, 7.6))
            .mirando(new Vec3(-57, 49.5, 0.5), new Vec3(-57, 49.8, 0.5)).fov(64, 60).curva(0)
            .en(0, () -> sonar("burbujas", 0.4f, 0.8f))
            .cadaTick(rel -> {
                if (rel % 20 == 0) servidor(s -> Escena.latido(s, true));
                if (rel % 20 == 8) servidor(s -> Escena.latido(s, false));
                if (rel % 3 == 0) {
                    Vec3 c = Director.camPos;
                    particula(ParticleTypes.BUBBLE, c.x + rnd.nextGaussian() * 2, c.y - 2, c.z + rnd.nextGaussian() * 2, 0, 0.1, 0);
                }
            }));

        // ------------------------------------------------------------------ 19. Post: el niño solo en la playa
        Vec3 np = Sitio.NINO_PLAYA;
        Papel nicoPlaya = nino("nico", "nico", quieto(np.x, np.z, 90f));
        nicoPlaya.animar = rel -> nicoPlaya.cabezaExtra = (float) (-14 * suave((rel - 40) / 30.0));
        tomas.add(reparto(new Toma("Post", 1300, 1420).hora(NOCHE)
                .prepara(() -> servidor(s -> Escena.luz(s, -33, 66, 2, 4)))
                .desde(new Vec3(-31.6, 65.7, 1.7), new Vec3(-32.2, 65.65, 1.5))
                .mirando(new Vec3(-40, 64.8, 0.6), new Vec3(-40, 64.8, 0.6)).fov(54, 50).curva(0)
                .en(32, () -> sonar("raro", 0.9f)),
            nicoPlaya));

        capas();
    }

    /** Un círculo alrededor de (cx, cz): niños jugando. */
    static Camino circulo(double cx, double cz, double r, double fase, double vel, int ticks) {
        Camino c = new Camino();
        for (int k = 0; k <= ticks; k += 4) {
            double a = fase + k * vel;
            c.en(k, cx + Math.cos(a) * r, cz + Math.sin(a) * r);
        }
        return c;
    }

    /** Destellos rosas alrededor del coral que late. */
    void brillo(Vec3 c, int n) {
        for (int i = 0; i < n; i++)
            particula(ParticleTypes.GLOW, c.x + rnd.nextGaussian() * 0.9, c.y + rnd.nextDouble() * 1.2, c.z + rnd.nextGaussian() * 0.9, 0, 0.02, 0);
    }

    // ------------------------------------------------------------------ sonidos que no dependen del plano
    void eventos(int k) {
        if (k == 0) {
            sonar("banda", 1.0f);
            sonar("pueblo", 0.7f);
        }
        if (k == 336) fundir("pueblo", 24);
    }

    /** Al reproducir un plano suelto, lo que ya estaría sonando. */
    void sonidosDesde(int inicio) {
        if (inicio > 0 && inicio < 330) sonar("pueblo", 0.6f);
    }

    /** Al reproducir un plano suelto, el pueblo como estaría en ese momento. */
    void alcanzar(int inicio) {
        servidor(s -> {
            if (inicio >= 540) { Escena.trigo(s, 1.0); Escena.pozo(s, Escena.pozoTotal()); }
            if (inicio >= 760) Escena.infeccion(s, 1.0);
        });
    }

    /** Sacudida de cámara (grados) en el instante t. */
    float sacudida(double t) {
        if (t >= 1040 && t < 1100) return 0.8f;
        if (t >= 1160 && t < 1190) return (float) (2.4 * Math.exp(-(t - 1160) / 7.0));
        return 0f;
    }

    // ------------------------------------------------------------------ capas
    private Capa negro(int t0, int t1, int in, int out) {
        Capa c = new Capa(Capa.Tipo.NEGRO, t0, t1, in, out, 10);
        capas.add(c);
        return c;
    }

    private Capa imagen(String tex, int w, int h, float cx, float cy, int t0, int t1, int in, int out) {
        Capa c = new Capa(Capa.Tipo.IMAGEN, t0, t1, in, out, 30);
        c.tex = Sitio.id("textures/gui/" + tex + ".png");
        c.ancho = w; c.alto = h; c.cx = cx; c.cy = cy;
        capas.add(c);
        return c;
    }

    private void destello(int color, float max, int t0, int t1, int out) {
        Capa c = new Capa(Capa.Tipo.COLOR, t0, t1, 0, out, 40);
        c.color = color; c.max = max;
        capas.add(c);
    }

    private void capas() {
        capas.add(new Capa(Capa.Tipo.BANDAS, 0, duracion, 0, 0, 20));
        negro(0, 26, 0, 24);                      // se abre desde negro
        // textos (Lora cursiva, abajo, como en el teaser 1)
        imagen("t_hogar", 865, 83, 960, 905, 236, 278, 12, 12).subir = 10;
        imagen("t_desperto", 715, 83, 960, 905, 560, 618, 12, 14).subir = 10;
        imagen("t_detener", 486, 83, 960, 905, 952, 1034, 14, 16).subir = 10;
        // destellos: cortes secos entre planos
        destello(0xFFFFFF, 0.45f, 1040, 1042, 2);
        for (int k : new int[]{1052, 1064, 1076, 1088}) negro(k - 1, k, 0, 0);
        // silencio: negro salvo 2 ticks
        negro(1100, 1148, 0, 0);
        negro(1150, 1163, 0, 0);
        destello(0xFF5FA8, 0.18f, 1148, 1150, 1);
        // logo (el del teaser 1): limpio, la coralosis se lo come, PRONTO...
        Capa os = new Capa(Capa.Tipo.OSCURECER, 1160, 1300, 6, 0, 0);
        os.max = 0.62f;
        capas.add(os);
        destello(0xFFFFFF, 0.35f, 1160, 1162, 8);
        Capa limpio = imagen("logo_limpio", 1388, 626, 945, 455, 1161, 1250, 5, 22);
        limpio.escala = 0.82f;
        Capa infectado = imagen("logo_coral", 1750, 634, 959, 458, 1214, 1300, 34, 0);
        infectado.escala = 0.82f;
        imagen("pronto", 520, 92, 960, 790, 1236, 1300, 18, 0).subir = 8;
        // al post y fin
        negro(1284, 1318, 14, 16);
        negro(1380, 1420, 24, 0);
        capas.sort((a, b) -> Integer.compare(a.z, b.z));
    }
}
