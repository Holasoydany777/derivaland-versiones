"""Animatic del Teaser 2: tiempos, textos, logo, música y efectos (sin la imagen del juego).
Uso: python3 animatic2.py <carpeta_assets_mod> <salida.mp4>
"""
import sys, subprocess, numpy as np
from PIL import Image, ImageDraw, ImageFont

A = sys.argv[1]; OUT = sys.argv[2]
W, H, FPS = 960, 540, 30
DUR_T = 1420  # ticks
SR = 44100
FONT = '/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf'

PLANOS = [(0, 80, "Amanecer", "Dron hacia el pueblo al amanecer, niebla baja"),
          (80, 140, "Calle", "Travelling lateral: Marta, Tomás, Lucía y Elías"),
          (140, 200, "Cartel", "DERIVALAND, cartel de madera"),
          (200, 280, "Plaza", "La fuente, niños jugando, tu skin de espaldas"),
          (280, 360, "Niños", "Corren a la playa; Nico se para y mira al mar"),
          (360, 420, "Arrecife", "Bajo el agua: el coral que late y brilla"),
          (420, 480, "Pozo", "El coral sale de las paredes del pozo"),
          (480, 540, "Trigo", "El trigo se marchita y se vuelve coral"),
          (540, 620, "Atardecer", "Las luces del casino parpadean"),
          (620, 700, "El giro", "Iker se gira: coral en la cabeza, ojos rosas"),
          (700, 760, "Desde arriba", "De noche: la coralosis avanza por las calles"),
          (760, 820, "Puertas", "Portazos, antorchas que se apagan"),
          (820, 880, "Campana", "Suena sola, cubierta de coral"),
          (880, 940, "Infectados", "Todos miran a cámara y ladean la cabeza"),
          (940, 1040, "Cartel roto", "El cartel partido y comido por el coral"),
          (1040, 1100, "Destellos", "Coral · ojo · agua · fuego · mar"),
          (1100, 1160, "Silencio", "Negro... 2 ticks: una silueta enorme en el mar"),
          (1160, 1300, "Logo", "Logo del teaser 1 → coralosis → PRONTO..."),
          (1300, 1420, "Post", "Nico solo en la playa, de noche")]
COLOR = [(232, 170, 120), (150, 190, 120), (150, 190, 120), (150, 190, 120), (150, 190, 120), (40, 120, 150), (110, 120, 110),
         (190, 170, 90), (220, 120, 70), (120, 80, 90), (30, 30, 60), (30, 30, 60), (30, 30, 60), (30, 30, 60), (30, 30, 60),
         (60, 20, 40), (0, 0, 0), (10, 50, 64), (10, 14, 30)]


def suave(a): a = max(0, min(1, a)); return a * a * (3 - 2 * a)


def alfa(t, t0, t1, i, o, mx=1.0):
    if t < t0 or t > t1: return 0.0
    a = 1.0
    if i > 0 and t < t0 + i: a = (t - t0) / i
    if o > 0 and t > t1 - o: a = min(a, (t1 - t) / o)
    return suave(a) * mx


def load(n, s=1.0):
    im = Image.open(f'{A}/textures/gui/{n}.png').convert('RGBA')
    return im.resize((max(1, int(im.width * s * W / 1920)), max(1, int(im.height * s * W / 1920))), Image.LANCZOS)


IMG = {
    't_hogar': (load('t_hogar'), 960, 905, 236, 278, 12, 12, 10),
    't_desperto': (load('t_desperto'), 960, 905, 560, 618, 12, 14, 10),
    't_detener': (load('t_detener'), 960, 905, 952, 1034, 14, 16, 10),
    'logo_limpio': (load('logo_limpio', 0.82), 945, 455, 1161, 1250, 5, 22, 0),
    'logo_coral': (load('logo_coral', 0.82), 959, 458, 1214, 1300, 34, 0, 0),
    'pronto': (load('pronto'), 960, 790, 1236, 1300, 18, 0, 8),
}
NEGROS = [(0, 26, 0, 24), (1051, 1052, 0, 0), (1063, 1064, 0, 0), (1075, 1076, 0, 0), (1087, 1088, 0, 0),
          (1100, 1148, 0, 0), (1150, 1163, 0, 0), (1284, 1318, 14, 16), (1380, 1420, 24, 0)]
COLORES = [((255, 255, 255), 0.45, 1040, 1042, 2), ((255, 95, 168), 0.18, 1148, 1150, 1), ((255, 255, 255), 0.35, 1160, 1162, 8)]
f_big = ImageFont.truetype(FONT, 30); f_small = ImageFont.truetype(FONT, 18)
try:
    f_big.set_variation_by_name('Bold'); f_small.set_variation_by_name('Regular')
except Exception:
    pass

# ------------------------------------------------------------------ audio
def dec(n):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f'{A}/sounds/{n}.ogg', '-f', 's16le', '-ac', '2', '-ar', str(SR), '-'], capture_output=True).stdout
    return np.frombuffer(raw, '<i2').reshape(-1, 2).astype(np.float32) / 32768


mix = np.zeros((int(DUR_T / 20 * SR) + SR, 2), np.float32)
def put(n, tick, vol, pitch=1.0, fade_at=None):
    x = dec(n) * vol
    if pitch != 1.0:
        idx = np.arange(0, len(x) - 1, pitch); x = np.stack([np.interp(idx, np.arange(len(x)), x[:, c]) for c in range(2)], 1)
    i = int(tick / 20 * SR); j = min(len(mix), i + len(x)); mix[i:j] += x[:j - i]
put('banda', 0, 1.0)
p = dec('pueblo') * 0.7
fa = int(336 / 20 * SR); p[fa:fa + int(1.2 * SR)] *= np.linspace(1, 0, min(len(p) - fa, int(1.2 * SR)))[:, None]; p[fa + int(1.2 * SR):] = 0
mix[:len(p)] += p
for tick, n, v, pt in [(362, 'burbujas', 0.55, 1), (426, 'coral', 0.7, 1), (446, 'coral', 0.8, 0.9), (464, 'coral', 0.9, 0.8),
                       (490, 'coral', 0.6, 1.1), (512, 'coral', 0.7, 0.9), (556, 'zumbido', 0.55, 1), (662, 'susurros', 0.7, 1),
                       (705, 'coral', 0.5, 0.7), (730, 'coral', 0.6, 0.6), (884, 'susurros', 0.7, 1), (914, 'susurros', 0.85, 0.85),
                       (1040, 'burbujas', 0.5, 1.3), (1112, 'gota', 0.8, 1), (1160, 'burbujas', 0.4, 0.8), (1332, 'raro', 0.9, 1)]:
    put(n, tick, v, pt)
mix = np.clip(mix, -1, 1)
raw = (mix * 32767).astype('<i2').tobytes()
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ar', str(SR), '-ac', '2', '-i', '-',
                '/tmp/claude-0/-home-claude/90b65aca-2285-52da-ac07-01637e558a63/scratchpad/animatic_audio.wav'], input=raw, check=True)

# ------------------------------------------------------------------ vídeo
proc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                         '-i', '/tmp/claude-0/-home-claude/90b65aca-2285-52da-ac07-01637e558a63/scratchpad/animatic_audio.wav',
                         '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-shortest', OUT],
                        stdin=subprocess.PIPE)

n = int(DUR_T / 20 * FPS)
for fr in range(n):
    t = fr / FPS * 20
    k = next(i for i, pl in enumerate(PLANOS) if pl[0] <= t < pl[1]) if t < 1420 else len(PLANOS) - 1
    pl = PLANOS[k]
    im = Image.new('RGB', (W, H), tuple(int(c * 0.55) for c in COLOR[k]))
    d = ImageDraw.Draw(im)
    # degradado suave
    top = Image.new('RGB', (W, H), tuple(int(c * 0.9) for c in COLOR[k]))
    m = Image.linear_gradient('L').resize((W, H))
    im = Image.composite(im, top, m)
    d = ImageDraw.Draw(im)
    if k != 16:
        d.text((40, 90), f"{k + 1} · {pl[2]}", font=f_big, fill=(240, 236, 228))
        d.text((40, 132), pl[3], font=f_small, fill=(220, 214, 206))
        s0 = pl[0] / 20; s1 = pl[1] / 20
        d.text((40, 160), f"{int(s0 // 60)}:{s0 % 60:04.1f} – {int(s1 // 60)}:{s1 % 60:04.1f}", font=f_small, fill=(200, 196, 190))
        prog = (t - pl[0]) / (pl[1] - pl[0])
        d.rectangle((40, 186, 40 + int(300 * prog), 189), fill=(255, 95, 168))
    im = im.convert('RGBA')
    if k == 16 and 1148 <= t < 1150:
        sil = Image.new('RGBA', (W, H), (232, 120, 70, 255))
        ds = ImageDraw.Draw(sil); ds.ellipse((330, 150, 630, 520), fill=(0, 0, 0, 255)); ds.rectangle((0, 400, W, H), fill=(20, 20, 30, 255))
        im = sil
    if 1160 <= t < 1300:
        ov = Image.new('RGBA', (W, H), (2, 14, 20, int(255 * alfa(t, 1160, 1300, 6, 0, 0.62))))
        im.alpha_composite(ov)
    for name, (img, cx, cy, t0, t1, i, o, sub) in IMG.items():
        a = alfa(t, t0, t1, i, o)
        if a <= 0.003: continue
        pe = 1 if i <= 0 else max(0, min(1, (t - t0) / i))
        layer = img.copy(); layer.putalpha(layer.split()[3].point(lambda v: int(v * a)))
        x = int(cx * W / 1920 - layer.width / 2); y = int((cy + sub * (1 - pe)) * H / 1080 - layer.height / 2)
        im.alpha_composite(layer, (x, y))
    for col, mx, t0, t1, o in COLORES:
        a = alfa(t, t0, t1, 0, o, mx)
        if a > 0: im.alpha_composite(Image.new('RGBA', (W, H), (*col, int(255 * a))))
    for t0, t1, i, o in NEGROS:
        a = alfa(t, t0, t1, i, o)
        if a > 0: im.alpha_composite(Image.new('RGBA', (W, H), (0, 0, 0, int(255 * a))))
    hb = int(H * 0.125)
    d = ImageDraw.Draw(im); d.rectangle((0, 0, W, hb), fill=(0, 0, 0)); d.rectangle((0, H - hb, W, H), fill=(0, 0, 0))
    proc.stdin.write(im.convert('RGB').tobytes())
proc.stdin.close(); proc.wait()
print('animatic', n, 'frames')
