"""Skins originales del pueblo de Derivaland (64x64, formato de jugador, brazos anchos).
Cada personaje tiene versión sana y versión infectada por la coralosis.
Uso: python3 skins.py <carpeta_salida> [<carpeta_preview>]
"""
import random, sys, os
from PIL import Image

# ------------------------------------------------------------------ geometría de la skin
# (u, v, w, h, d) de cada caja, capa base y capa exterior
BOX = {
    'head': ((0, 0), (32, 0), 8, 8, 8),
    'body': ((16, 16), (16, 32), 8, 12, 4),
    'rarm': ((40, 16), (40, 32), 4, 12, 4),
    'larm': ((32, 48), (48, 48), 4, 12, 4),
    'rleg': ((0, 16), (0, 32), 4, 12, 4),
    'lleg': ((16, 48), (0, 48), 4, 12, 4),
}


def faces(u, v, w, h, d):
    return {
        'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d),
        'right': (u, v + d, d, h), 'front': (u + d, v + d, w, h),
        'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h),
    }


class Skin:
    def __init__(self, seed):
        self.im = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        self.px = self.im.load()
        self.r = random.Random(seed)

    def face(self, part, side, layer=0):
        base, over, w, h, d = BOX[part]
        u, v = base if layer == 0 else over
        return faces(u, v, w, h, d)[side]

    def put(self, part, side, x, y, c, layer=0):
        fx, fy, fw, fh = self.face(part, side, layer)
        if 0 <= x < fw and 0 <= y < fh:
            self.px[fx + x, fy + y] = c if len(c) == 4 else (*c, 255)

    def fill(self, part, color, layer=0, sides=None, noise=6, rows=None):
        """Rellena la caja con un color con algo de grano (como las texturas de Minecraft)."""
        for side in (sides or ['top', 'bottom', 'right', 'front', 'left', 'back']):
            fx, fy, fw, fh = self.face(part, side, layer)
            for y in range(fh):
                if rows and not (rows[0] <= y < rows[1]) and side not in ('top', 'bottom'):
                    continue
                for x in range(fw):
                    n = self.r.randint(-noise, noise)
                    shade = -10 if side in ('bottom',) else (6 if side == 'top' else 0)
                    self.px[fx + x, fy + y] = tuple(max(0, min(255, ch + n + shade)) for ch in color) + (255,)

    def band(self, part, color, y0, y1, layer=0, noise=5):
        """Franja horizontal (por filas) en los cuatro lados."""
        for side in ['right', 'front', 'left', 'back']:
            fx, fy, fw, fh = self.face(part, side, layer)
            for y in range(max(0, y0), min(fh, y1)):
                for x in range(fw):
                    n = self.r.randint(-noise, noise)
                    self.px[fx + x, fy + y] = tuple(max(0, min(255, ch + n)) for ch in color) + (255,)
        if y0 <= 0 and layer == 0:
            self.fill(part, color, layer, ['top'], noise)
        if y1 >= 12 and part != 'head':
            self.fill(part, color, layer, ['bottom'], noise)


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def dark(c, k=0.75):
    return tuple(int(ch * k) for ch in c)


# ------------------------------------------------------------------ personaje
def persona(p):
    s = Skin(p['seed'])
    piel, pelo = p['piel'], p['pelo']
    camisa, pantalon, zapato = p['camisa'], p['pantalon'], p['zapato']
    # cabeza
    s.fill('head', piel)
    # pelo: arriba, detrás y laterales altos
    s.fill('head', pelo, sides=['top'])
    s.band('head', pelo, 0, p.get('flequillo', 2))
    fx, fy, fw, fh = s.face('head', 'back')
    for y in range(fh):
        for x in range(fw):
            if y < p.get('nuca', 6):
                s.put('head', 'back', x, y, pelo)
    for side in ('right', 'left'):
        for y in range(p.get('patilla', 4)):
            for x in range(8):
                if side == 'right' and x < 6 or side == 'left' and x > 1:
                    s.put('head', side, x, y, pelo)
    if p.get('melena'):
        # pelo largo por detrás y los lados (capa exterior, cae hasta el cuello)
        for side in ('back', 'right', 'left'):
            for y in range(8):
                for x in range(8):
                    if side == 'back' or (side == 'right' and x < 3) or (side == 'left' and x > 4):
                        s.put('head', side, x, y, dark(pelo, 0.92 if (x + y) % 3 else 0.8), layer=1)
        for y in range(0, 4):
            for x in range(8):
                s.put('body', 'back', x, y, dark(pelo, 0.9), layer=1)
    if p.get('coletas'):
        for side, xs in (('right', (1, 2)), ('left', (5, 6))):
            for y in range(3, 8):
                for x in xs:
                    s.put('head', side, x, y, dark(pelo, 0.9), layer=1)
        for y in range(3, 8):
            s.put('head', 'front', 0, y, dark(pelo, 0.9), layer=1)
            s.put('head', 'front', 7, y, dark(pelo, 0.9), layer=1)
    # cara
    ojo = p.get('ojo', (60, 90, 140))
    blanco = (238, 236, 230)
    oy = p.get('ojos_y', 4)
    for x0 in (1, 5):
        s.put('head', 'front', x0, oy, blanco)
        s.put('head', 'front', x0 + 1, oy, ojo)
    if p.get('cejas', True):
        for x in (1, 2, 5, 6):
            s.put('head', 'front', x, oy - 1, dark(pelo, 0.85))
    s.put('head', 'front', 3, oy + 1, dark(piel, 0.88))
    s.put('head', 'front', 4, oy + 1, dark(piel, 0.88))
    boca = p.get('boca', dark(piel, 0.7))
    for x in (3, 4):
        s.put('head', 'front', x, oy + 2, boca)
    if p.get('mejillas'):
        s.put('head', 'front', 1, oy + 2, mix(piel, (230, 120, 120), 0.4))
        s.put('head', 'front', 6, oy + 2, mix(piel, (230, 120, 120), 0.4))
    if p.get('barba'):
        b = p['barba']
        for y in range(oy + 1, 8):
            for x in range(8):
                if y == oy + 2 and x in (3, 4):
                    s.put('head', 'front', x, y, dark(piel, 0.6))
                elif y > oy + 1 or x in (0, 1, 6, 7):
                    s.put('head', 'front', x, y, b if (x + y) % 4 else dark(b, 0.88))
        for side in ('right', 'left'):
            for y in range(oy + 1, 8):
                for x in range(8):
                    if (side == 'right' and x > 4) or (side == 'left' and x < 3):
                        s.put('head', side, x, y, b)
    # cuerpo y brazos
    s.fill('body', camisa)
    manga = p.get('manga', 4)
    for arm in ('rarm', 'larm'):
        s.fill(arm, piel)
        s.band(arm, camisa, 0, manga)
        s.fill(arm, camisa, sides=['top'])
    # cuello
    for x in (3, 4):
        s.put('body', 'front', x, 0, dark(piel, 0.95))
    # piernas
    for leg in ('rleg', 'lleg'):
        s.fill(leg, pantalon)
        s.band(leg, zapato, 10, 12)
        s.fill(leg, zapato, sides=['bottom'])
    if p.get('cinturon'):
        s.band('body', p['cinturon'], 8, 9)
    if p.get('vestido'):
        vc = p['vestido']
        s.band('body', vc, 0, 12)
        for leg in ('rleg', 'lleg'):
            s.band(leg, vc, 0, p.get('falda', 6))
            s.band(leg, piel, p.get('falda', 6), 10)
    if p.get('delantal'):
        dc = p['delantal']
        for y in range(3, 12):
            for x in range(1, 7):
                s.put('body', 'front', x, y, dc if (x + y) % 5 else dark(dc, 0.92))
        for leg, xs in (('rleg', range(1, 4)), ('lleg', range(0, 3))):
            for y in range(0, 5):
                for x in xs:
                    s.put(leg, 'front', x, y, dc)
    if p.get('tirantes'):
        tc = p['tirantes']
        s.band('body', tc, 7, 12)
        for x in (1, 2, 5, 6):
            for y in range(0, 7):
                s.put('body', 'front', x, y, tc)
                s.put('body', 'back', x, y, tc)
    if p.get('rayas'):
        rc = p['rayas']
        for y in range(1, 12, 3):
            s.band('body', rc, y, y + 1)
            for arm in ('rarm', 'larm'):
                if y < manga:
                    s.band(arm, rc, y, y + 1)
    if p.get('chaqueta'):
        cc = p['chaqueta']
        s.fill('body', cc, layer=1, sides=['right', 'left', 'back', 'top'])
        for y in range(12):
            for x in (0, 1, 6, 7):
                s.put('body', 'front', x, y, cc, layer=1)
        for arm in ('rarm', 'larm'):
            s.fill(arm, cc, layer=1)
            for side in ('right', 'front', 'left', 'back'):
                for x in range(4):
                    s.put(arm, side, x, 11, (0, 0, 0, 0), layer=1)
    if p.get('sombrero'):
        hc = p['sombrero']
        s.fill('head', hc, layer=1, sides=['top'])
        s.band('head', hc, 0, 2, layer=1)
        s.band('head', dark(hc, 0.7), 2, 3, layer=1)
    if p.get('panuelo'):
        pc = p['panuelo']
        s.fill('head', pc, layer=1, sides=['top'])
        s.band('head', pc, 0, 2, layer=1)
        for y in range(2, 6):
            for x in range(8):
                s.put('head', 'back', x, y, pc, layer=1)
    if p.get('gafas'):
        g = p['gafas']
        for x in (0, 1, 2, 3, 4, 5, 6, 7):
            s.put('head', 'front', x, oy - 1 if False else oy, g if x in (0, 3, 4, 7) else (0, 0, 0, 0), layer=1)
    return s.im


# ------------------------------------------------------------------ coralosis
CORAL = [(255, 92, 170), (255, 128, 190), (232, 64, 150), (255, 160, 205), (255, 110, 120)]
PIEL_INF = (150, 156, 150)


def infectar(im, seed, fuerza=1.0):
    """Piel grisácea, manchas de coral rosa, ojos rosas que brillan y ramas de coral en la cabeza (capa exterior)."""
    r = random.Random(seed)
    out = im.copy()
    px = out.load()
    src = im.load()
    s = Skin(0)
    s.im, s.px = out, px
    # 1. la piel y la ropa pierden color
    for y in range(64):
        for x in range(64):
            c = src[x, y]
            if c[3] == 0:
                continue
            g = (c[0] * 30 + c[1] * 59 + c[2] * 11) // 100
            k = 0.55 * fuerza
            nc = (int(c[0] * (1 - k) + (g * 0.95) * k), int(c[1] * (1 - k) + (g * 1.02) * k), int(c[2] * (1 - k) + (g * 1.0) * k))
            nc = tuple(int(ch * (1 - 0.18 * fuerza)) for ch in nc)
            px[x, y] = (*nc, c[3])
    # 2. manchas de coral (base): racimos que crecen desde unos cuantos focos
    focos = [('head', 'right'), ('head', 'back'), ('head', 'top'), ('rarm', 'front'), ('body', 'front'),
             ('larm', 'back'), ('body', 'back'), ('head', 'front'), ('rleg', 'left')]
    for part, side in focos[:int(4 + 5 * fuerza)]:
        fx, fy, fw, fh = s.face(part, side)
        cx, cy = r.randrange(fw), r.randrange(fh)
        for _ in range(int(10 + 14 * fuerza)):
            x, y = cx + r.randint(-2, 2), cy + r.randint(-2, 2)
            if 0 <= x < fw and 0 <= y < fh:
                if part == 'head' and side == 'front' and y in (3, 4, 5) and 1 <= x <= 6:
                    continue  # que la cara se siga leyendo
                px[fx + x, fy + y] = (*r.choice(CORAL), 255)
    # 3. ojos rosas
    fx, fy, fw, fh = s.face('head', 'front')
    for y in range(8):
        for x in range(8):
            c = px[fx + x, fy + y]
            if c[3] and c[0] > 200 and c[1] > 200 and c[2] > 200:  # blanco del ojo
                px[fx + x, fy + y] = (255, 120, 200, 255)
    for x in (2, 6):
        for y in range(2, 7):
            c = px[fx + x, fy + y]
            if c[3] and c[2] > c[0] + 20:  # iris
                px[fx + x, fy + y] = (255, 40, 150, 255)
    # 4. ramas de coral en la capa exterior de la cabeza (sobresalen al girarse)
    for side in ('top', 'right', 'back', 'left'):
        fx, fy, fw, fh = s.face('head', side, layer=1)
        for _ in range(int(2 + 3 * fuerza)):
            x = r.randrange(fw)
            y = r.randrange(fh) if side == 'top' else r.randrange(0, 4)
            col = r.choice(CORAL)
            for k in range(r.randint(2, 4)):
                if 0 <= x < fw and 0 <= y + k < fh:
                    px[fx + x, fy + y + k] = (*col, 255)
                x += r.choice((-1, 0, 1))
    # en los brazos también
    for arm in ('rarm', 'larm'):
        fx, fy, fw, fh = s.face(arm, 'right' if arm == 'rarm' else 'left', layer=1)
        for _ in range(int(1 + 2 * fuerza)):
            x, y = r.randrange(fw), r.randrange(fh)
            for k in range(3):
                if 0 <= y - k < fh:
                    px[fx + x, fy + y - k] = (*r.choice(CORAL), 255)
    return out


# ------------------------------------------------------------------ el reparto
REPARTO = {
    # adultos
    'marta': dict(seed=1, piel=(214, 168, 132), pelo=(92, 54, 32), melena=True, nuca=8, camisa=(176, 52, 48),
                  pantalon=(120, 40, 36), zapato=(60, 40, 30), vestido=(176, 52, 48), falda=8, delantal=(236, 230, 214),
                  mejillas=True, manga=3, ojo=(70, 110, 60)),
    'tomas': dict(seed=2, piel=(200, 150, 110), pelo=(70, 48, 30), camisa=(96, 140, 72), pantalon=(98, 76, 52),
                  zapato=(50, 36, 26), barba=(70, 48, 30), tirantes=(110, 86, 58), sombrero=(220, 190, 110), manga=3),
    'elias': dict(seed=3, piel=(222, 184, 150), pelo=(214, 214, 210), camisa=(128, 120, 112), pantalon=(80, 74, 70),
                  zapato=(44, 36, 32), barba=(226, 226, 222), chaqueta=(108, 84, 64), manga=12, nuca=7, ojo=(80, 110, 150)),
    'lucia': dict(seed=4, piel=(138, 92, 62), pelo=(30, 22, 18), panuelo=(230, 196, 60), camisa=(238, 238, 236),
                  rayas=(40, 70, 140), pantalon=(46, 60, 96), zapato=(36, 30, 28), manga=6, ojo=(60, 40, 30), mejillas=True),
    'iker': dict(seed=5, piel=(232, 196, 160), pelo=(226, 190, 96), camisa=(214, 128, 52), pantalon=(70, 82, 110),
                 zapato=(70, 52, 40), cinturon=(80, 56, 36), manga=5, ojo=(70, 120, 170)),
    'rosa': dict(seed=6, piel=(176, 124, 90), pelo=(120, 40, 34), melena=True, nuca=8, camisa=(90, 120, 170),
                 pantalon=(90, 120, 170), zapato=(70, 50, 40), vestido=(90, 120, 170), falda=9, manga=3, ojo=(50, 80, 60)),
    # niños
    'nico': dict(seed=11, piel=(226, 182, 144), pelo=(110, 70, 40), camisa=(210, 56, 50), pantalon=(60, 80, 130),
                 zapato=(240, 240, 240), manga=2, mejillas=True, ojo=(60, 100, 160), nuca=5),
    'vega': dict(seed=12, piel=(200, 150, 112), pelo=(40, 28, 22), coletas=True, camisa=(240, 200, 60),
                 vestido=(240, 200, 60), falda=6, pantalon=(240, 200, 60), zapato=(200, 70, 90), manga=2, mejillas=True),
    'pablo': dict(seed=13, piel=(150, 104, 74), pelo=(26, 20, 16), camisa=(60, 150, 200), pantalon=(150, 120, 80),
                  zapato=(90, 60, 40), manga=3, mejillas=True, ojo=(50, 36, 26)),
}


def vista(im, escala=8):
    """Preview plano de frente (cabeza + cuerpo + brazos + piernas) para revisar a ojo."""
    def cut(part, side, layer=0):
        base, over, w, h, d = BOX[part]
        u, v = base if layer == 0 else over
        fx, fy, fw, fh = faces(u, v, w, h, d)[side]
        return im.crop((fx, fy, fx + fw, fy + fh))
    out = Image.new('RGBA', (16 * 2 + 4, 32), (0, 0, 0, 0))
    for k, side, arm_side in ((0, 'front', 'front'), (1, 'back', 'back')):
        ox = k * 20
        def paste(part, x, y):
            out.alpha_composite(cut(part, side), (ox + x, y))
            out.alpha_composite(cut(part, side, 1), (ox + x, y))
        paste('head', 4, 0); paste('body', 4, 8)
        paste('rarm' if k == 0 else 'larm', 0, 8); paste('larm' if k == 0 else 'rarm', 12, 8)
        paste('rleg' if k == 0 else 'lleg', 4, 20); paste('lleg' if k == 0 else 'rleg', 8, 20)
    return out.resize((out.width * escala, out.height * escala), Image.NEAREST)


if __name__ == '__main__':
    dst = sys.argv[1]
    os.makedirs(dst, exist_ok=True)
    previews = []
    for nombre, p in REPARTO.items():
        sano = persona(p)
        sano.save(f'{dst}/{nombre}.png')
        inf = infectar(sano, p['seed'] * 7 + 1)
        inf.save(f'{dst}/{nombre}_infectado.png')
        previews += [(nombre, vista(sano)), (nombre + '_inf', vista(inf))]
    if len(sys.argv) > 2:
        cols = 6
        w, h = previews[0][1].size
        hoja = Image.new('RGBA', (cols * (w + 16), ((len(previews) + cols - 1) // cols) * (h + 16)), (60, 70, 80, 255))
        for i, (n, v) in enumerate(previews):
            hoja.alpha_composite(v, ((i % cols) * (w + 16) + 8, (i // cols) * (h + 16) + 8))
        hoja.save(sys.argv[2])
    print('skins:', len(REPARTO) * 2)
